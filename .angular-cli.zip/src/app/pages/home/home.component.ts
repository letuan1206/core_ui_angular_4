import { DueActivitiesComponent } from './../../components/subs/due-activities/due-activities.component';
import { HelperService } from './../../services/helper.service';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {
  @ViewChild('dueActivitiesModal') dueActivitiesModal: DueActivitiesComponent;

  constructor(
    private helperService: HelperService
  ) { }

  ngOnInit() {
    // this.helperService.setThemeDefault();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
    this.dueActivitiesModal.show();
  }

}
