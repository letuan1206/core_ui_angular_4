import { NgModule, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';

// Components
import { HomeComponent } from './pages/home/home.component';

// Rostering
import { RosterTemplateComponent } from './components/rostering/roster-template/roster-template.component';
import { RosteringComponent } from './components/rostering/rostering.component';
import { ConfigurationComponent } from './components/configuration/configuration.component';
import { OrganisationAddComponent } from './components/organisation/organisation-add/organisation-add.component';
import { OrganisationComponent, OrganisationListComponent } from './components/organisation/organisation.component';
import { OrganisationDetailComponent } from './components/organisation/organisation-detail/organisation-detail.component';
import { UserInformationComponent } from './components/user-information/user-information.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

// Clients
import { ClientsComponent } from './components/clients/clients.component';
import { ClientsDetailComponent } from './components/clients/clients-detail/clients-detail.component';

// Contacts
import { ContactComponent } from './components/contact/contact.component';
import { ContactDetailComponent } from './components/contact/contact-detail/contact-detail.component';

// Sites
import { SitesComponent } from './components/sites/sites.component';
import { SitesDetailComponent } from './components/sites/sites-detail/sites-detail.component';
import { SearchReportComponent } from './components/sites/search-report/search-report.component';
import { ReportNotificationComponent } from './components/sites/report-notification/report-notification.component';
import { ReportDetailComponent } from './components/sites/report-detail/report-detail.component';
import { CheckPointComponent } from './components/sites/check-point/check-point.component';
import { PatrolScheduleComponent } from './components/sites/patrol-schedule/patrol-schedule.component';
import { SiteMapComponent } from './components/sites/site-map/site-map.component';

// Modules
import { ClientsModule } from './components/clients/clients.module';
import { SitesModule } from './components/sites/sites.module';
import { EmployeesComponent } from './components/employees/employees.component';
import { EmployeeDetailComponent } from './components/employees/employee-detail/employee-detail.component';
import { SubmittedReportsComponent } from './components/dashboard/submitted-reports/submitted-reports.component';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {
    path: '', component: HomeComponent, children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard', component: DashboardComponent, children: [
          { path: '', component: DashboardComponent, },
        ]
        
      },
      { path: 'submitted-reports', component: SubmittedReportsComponent },
      {
        path: 'organisation', component: OrganisationComponent, children: [
          { path: '', component: OrganisationListComponent },
          { path: 'add', component: OrganisationAddComponent },
          { path: 'detail/:id', component: OrganisationDetailComponent },
        ]
      },
      {
        path: 'configuration/:idAnchor', component: ConfigurationComponent
      },
      {
        path: 'personal-setting/:idAnchor', component: UserInformationComponent
      },
      {
        path: 'rostering', component: RosteringComponent
      },
      {
        path: 'roster-template', component: RosterTemplateComponent
      },
      {
        path: 'clients', children: [
          { path: '', component: ClientsComponent },
          { path: 'detail/:id', component: ClientsDetailComponent },
          { path: 'add', component: ClientsDetailComponent },
        ]
      },
      {
        path: 'contact', children: [
          { path: '', component: ContactComponent },
          { path: ':id', component: ContactDetailComponent },
          { path: 'add', component: ContactDetailComponent },
        ]
      },
      {
        path: 'sites', children: [
          { path: '', component: SitesComponent },
          // { path: ':id', component: SitesDetailComponent },
          { path: 'detail/:id', component: SitesDetailComponent },
          { path: 'add/:clientId', component: SitesDetailComponent },
          { path: 'add', component: SitesDetailComponent },
          { path: 'search-report/:siteId', component: SearchReportComponent },
          { path: 'report-notification/:siteId', component: ReportNotificationComponent },
          { path: 'check-point/:siteId', component: CheckPointComponent },
          { path: 'patrol-schedule/:siteId', component: PatrolScheduleComponent },
          { path: 'site-map/:id', component: SiteMapComponent }
        ]
      },
      {
        path: 'employees', children: [
          { path: '', component: EmployeesComponent },
          { path: 'detail/:id', component: EmployeeDetailComponent },
          // { path: ':id', component: EmployeeDetailComponent },
          { path: 'add', component: EmployeeDetailComponent },
        ]
      }, {
        path: 'report-detail/:id', component: ReportDetailComponent
      }
    ]
  },
  { path: '**', redirectTo: '', pathMatch: "full" }
];

const Routing: ModuleWithProviders = RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules });

@NgModule({
  imports: [
    Routing
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
