import { FormGroup, AbstractControl, ValidationErrors } from '@angular/forms';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { LOCALSTORE_KEY } from '../components/common/constants';
import { NgRedux } from 'ng2-redux';
import get = require('lodash/get');
import find = require('lodash/find');
import * as moment from 'moment';
// Interfaces
import { DataOfTableClient, ClientsTransformParam } from '../interfaces/clients-interface';
import { DataOfTableSite, SitesTransformParam } from '../interfaces/sites-interface';
import { EmployeesTransformParam, DataOfTableEmployees } from '../interfaces/employees-interface';

// Services
import { CommonService } from './common.service';
import { ConfigService } from './config.service';


declare var jquery: any;
declare var $: any;

@Injectable()
export class HelperService {

  public loading = new BehaviorSubject<boolean>(false);

  constructor(
    private commonService: CommonService,
    private configService: ConfigService,
    private ngRedux: NgRedux<any>
  ) {

  }

  /**
   * Function transform data
   */
  transformData(params: ClientsTransformParam | SitesTransformParam | EmployeesTransformParam) {
    if (params instanceof ClientsTransformParam) {
      return this.transformDataClient(params.dataClient, params.dataDivision, params.dataService, params.stateOptions, params.serviceOptions, params.divisionOptions);
    } else if (params instanceof SitesTransformParam) {
      return this.transformDataSite(params.dataSite, params.dataDivision, params.dataService, params.stateOptions, params.serviceOptions, params.divisionOptions);
    } else if (params instanceof EmployeesTransformParam) {
      return this.transformDataEmployee(params.dataEmployee, params.stateOptions, params.positionOptions, params.divisionOptions);
    }
  }

  /**
   * Function transform data client
   */
  transformDataClient(dataClient, dataDivision, dataService, stateOptions, serviceOptions, divisionOptions) {

    let datas = [];

    let resultOfClients = this.getReferenceDataByObjId(dataClient.results, dataClient.references);

    stateOptions = this.transformArray(this.filterByType(dataClient.references, 'prosek.orm.CountryState'), stateOptions);
    divisionOptions = this.transformArray(this.filterByType(dataClient.references, 'prosek.orm.types.Division'), divisionOptions);

    if (resultOfClients.length > 0) {
      for (let i = 0; i < resultOfClients.length; i++) {

        let dataOfTable: DataOfTableClient = {
          clientName: resultOfClients[i].TradingName,
          address: '',
          state: '',
          division: '',
          services: [],
          servicesName: '',
          phone: '',
          email: '',
          objectID: resultOfClients[i].ObjectID
        }

        // Get information
        let dataOfInformation = get(dataClient.references, resultOfClients[i].Information);

        dataOfTable.phone = dataOfInformation.Phone !== null ? dataOfInformation.Phone : '';
        dataOfTable.email = dataOfInformation.Email !== null ? dataOfInformation.Email : '';
        dataOfTable.state = (dataOfInformation.State !== null && get(dataClient.references, dataOfInformation.State).Name !== null) ? get(dataClient.references, dataOfInformation.State).Name : '';
        dataOfTable.address = (dataOfInformation.Address !== null && get(dataClient.references, dataOfInformation.Address).Street !== null) ? get(dataClient.references, dataOfInformation.Address).Street : '';
        dataOfTable.division = (dataOfInformation.Division !== null && get(dataDivision.references, dataOfInformation.Division).Description !== null) ? get(dataDivision.references, dataOfInformation.Division).Description : '';

        if (dataOfInformation.Services && dataOfInformation.Services.length > 0) {
          for (let j = 0; j < dataOfInformation.Services.length; j++) {
            let serviceId = get(dataClient.references, dataOfInformation.Services[j]).Service;
            let serviceData = get(dataService.references, serviceId);
            dataOfTable.services.push(serviceData);
            dataOfTable.servicesName = this.createServicesName(dataOfTable.servicesName, serviceData.Description);
            if (serviceData && find(serviceOptions, serviceData) == null) {
              serviceOptions.push(serviceData);
            }
          }
        }

        datas.push(dataOfTable);

      }
    }

    return {
      datas: datas,
      stateOptions: stateOptions,
      serviceOptions: serviceOptions,
      divisionOptions: divisionOptions
    }

  }

  /**
   * Function transform data site
   */
  transformDataSite(dataSite, dataDivision, dataService, stateOptions, serviceOptions, divisionOptions) {

    let datas = [];

    let resultOfSites = this.getReferenceDataByObjId(dataSite.results, dataSite.references);

    stateOptions = this.transformArray(this.filterByType(dataSite.references, 'prosek.orm.CountryState'), stateOptions);
    divisionOptions = this.transformArray(this.filterByType(dataSite.references, 'prosek.orm.types.Division'), divisionOptions);

    if (resultOfSites.length > 0) {
      for (let i = 0; i < resultOfSites.length; i++) {

        let dataOfTable: DataOfTableSite = {
          siteName: resultOfSites[i].SiteName,
          objectID: resultOfSites[i].ObjectID,
          address: '',
          state: '',
          division: '',
          services: [],
          servicesName: '',
          phone: '',
          email: ''
        }

        // Get information
        let dataOfInformation = get(dataSite.references, resultOfSites[i].Information);

        dataOfTable.phone = dataOfInformation.Phone !== null ? dataOfInformation.Phone : '';
        dataOfTable.email = dataOfInformation.Email !== null ? dataOfInformation.Email : '';
        dataOfTable.state = (dataOfInformation.State !== null && get(dataSite.references, dataOfInformation.State).Name !== null) ? get(dataSite.references, dataOfInformation.State).Name : '';
        dataOfTable.address = (dataOfInformation.Address !== null && get(dataSite.references, dataOfInformation.Address).Street !== null) ? get(dataSite.references, dataOfInformation.Address).Street : '';
        dataOfTable.division = (dataOfInformation.Division !== null && get(dataDivision.references, dataOfInformation.Division).Description !== null) ? get(dataDivision.references, dataOfInformation.Division).Description : '';

        if (dataOfInformation.Services && dataOfInformation.Services.length > 0) {
          for (let j = 0; j < dataOfInformation.Services.length; j++) {
            let serviceId = get(dataSite.references, dataOfInformation.Services[j]).Service;
            let serviceData = get(dataService.references, serviceId);
            dataOfTable.services.push(serviceData);
            dataOfTable.servicesName = this.createServicesName(dataOfTable.servicesName, serviceData.Description);
            if (serviceData && find(serviceOptions, serviceData) == null) {
              serviceOptions.push(serviceData);
            }
          }
        }

        datas.push(dataOfTable);

      }
    }

    return {
      datas: datas,
      stateOptions: stateOptions,
      serviceOptions: serviceOptions,
      divisionOptions: divisionOptions
    }

  }

  /**
  * Function transform data site
  */
  transformDataEmployee(dataEmployee, stateOptions, positionOptions, divisionOptions) {
    let datas = [];
    let userInformation = []

    let resultOfEmployees = this.getReferenceDataByObjId(dataEmployee.results, dataEmployee.references);

    positionOptions = this.transformArray(this.filterByType(dataEmployee.references, 'prosek.orm.types.Position'), positionOptions);
    stateOptions = this.transformArray(this.filterByType(dataEmployee.references, 'prosek.orm.CountryState'), stateOptions);
    divisionOptions = this.transformArray(this.filterByType(dataEmployee.references, 'prosek.orm.types.Division'), divisionOptions);

    userInformation = this.filterByType(dataEmployee.references, 'oneit.security.SecUser');
    if (resultOfEmployees.length > 0) {
      for (let i = 0; i < resultOfEmployees.length; i++) {
        let dataOfTable: DataOfTableEmployees = {
          employeeName: '',
          objectID: resultOfEmployees[i].ObjectID,
          state: '',
          position: '',
          division: '',
          phone: resultOfEmployees[i].Phone,
          email: resultOfEmployees[i].UserName
        }
        dataOfTable.employeeName = resultOfEmployees[i].User ? `${get(dataEmployee.references, resultOfEmployees[i].User).FirstName} ${get(dataEmployee.references, resultOfEmployees[i].User).LastName}` : '';
        // dataOfTable.email = resultOfEmployees[i].User ? get(dataEmployee.references, resultOfEmployees[i].User).Email : '';
        dataOfTable.state = (resultOfEmployees[i].State && get(dataEmployee.references, resultOfEmployees[i].State).Name) ? get(dataEmployee.references, resultOfEmployees[i].State).Name : '';
        dataOfTable.position = (resultOfEmployees[i].Position && get(dataEmployee.references, resultOfEmployees[i].Position)) ? get(dataEmployee.references, resultOfEmployees[i].Position).Description : '';
        dataOfTable.division = (resultOfEmployees[i].Division && get(dataEmployee.references, resultOfEmployees[i].Division)) ? get(dataEmployee.references, resultOfEmployees[i].Division).Description : '';
        datas.push(dataOfTable);
      }
    }
    return {
      datas: datas,
      stateOptions: stateOptions,
      positionOptions: positionOptions,
      divisionOptions: divisionOptions
    }

  }

  /**
   * Function transform to new array
   */
  transformArray(sourceArr, desArr) {
    if (sourceArr.length > 0) {
      for (let i = 0; i < sourceArr.length; i++) {
        desArr.push(sourceArr[i]);
      }
      return desArr;
    }
    return desArr;
  }

  /**
   * Function dispatch to redux
   */
  dispatchToRedux(actionName, data) {
    this.ngRedux.dispatch({
      type: actionName,
      payload: data
    })
  }

  /**
   * Function filter by type
   */
  filterByType(clientRef, objClass) {
    let stateOptions = [];
    for (let key in clientRef) {
      if (clientRef[key].ObjectClass !== undefined && clientRef[key].ObjectClass === objClass) {
        stateOptions.push(clientRef[key]);
      }
    }
    return stateOptions;
  }

  /**
   * Function get reference data by object id
   */
  getReferenceDataByObjId(objectId, dataRef) {
    let arrDataRef = [];
    for (let key in dataRef) {
      if (objectId.indexOf(key) > -1) {
        arrDataRef.push(dataRef[key]);
      }
    }
    return arrDataRef;
  }

  /**
   * Function create servicesName
   */
  createServicesName(serviceName, description) {
    return serviceName === '' ? description : `${serviceName}, ${description}`;
  }

  /**
   * Function convert query params
   */
  convertQueryParams(params) {
    for (let key in params) {
      if (params[key] === null) {
        delete params[key];
      }
    }
    return params;
  }

  /**
   * Function get position by object ID
   */
  async getPositionDetailById(objectId): Promise<any> {

    try {

      let positionData = await this.commonService.queryAllData(`/Positions`);

      if (positionData.result === this.configService.successStatus) {
        return get(positionData.references, objectId);
      } else {
        throw Error('error');
      }

    } catch (e) {
      this.handleError(e);
    }

  }

  markFormGroupTouched(formGroup: FormGroup) {
    return (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        control.controls.forEach(c => this.markFormGroupTouched(c));
      }
    });
  }

  removeAllSpace(formGroup: FormGroup) {
    return (<any>Object).values(formGroup.controls).forEach(control => {
      if (control.value && typeof control.value === 'string') {
        control.setValue(control.value.trim());
      }
    });
  }

  setThemeDefault() {
    var themeSetting = JSON.parse(localStorage.getItem(LOCALSTORE_KEY.THEME_SETTING));

    if (!themeSetting) {
      themeSetting = {
        menuBar: null,
        menuText: null,
        headingBar: null,
        headingText: null
      };
    }

    $('.app-header.navbar').css('background-color', themeSetting.menuBar || '');
    $('.app-header.navbar .nav-item .nav-link').css('color', themeSetting.menuText || '');

    $('.card-header').css('background-color', themeSetting.headingBar || '');
    $('.card-header').css('color', themeSetting.headingText || '');
    $('.sheet-right-edit .fake-link').css('color', themeSetting.headingText || '');
  }

  showLoading() {
    this.loading.next(true);
  }

  hideLoading() {
    this.loading.next(false);
  }

  handleError(e) {
    console.warn(e);
  }

  generatorRandomString() {
    let number = Math.floor(1000 + Math.random() * 9000);
    //return status.indexOf("Create") != -1 ? `NEW:${number}` : `UPDATE:${number}`;
    return `NEW:${number}`;
  }

  getKeysOfValue(data) {
    let arrKeys = [];
    for (let key in data) {
      arrKeys.push(key);
    }
    return arrKeys;
  }

  convertDate(date, formatDate?) {
    return moment.utc(date).format(formatDate);
  }

  listSelectItem(data, separate = '', ...args: any[]) {
    let listSelectItem = [];
    for (let i in data) {
      let text = [];
      if (args != null && args.length > 0) {
        for (let j in args) {
          if (data[i][args[j]] !== null) {
            text.push(data[i][args[j]]);
          }
        }

        listSelectItem.push({
          Description: this.createNewField(separate, text),
          Value: this.createNewField(separate, data[i].ObjectID != undefined ? data[i].ObjectID : data[i].Value),
        });
      } else {
        listSelectItem.push({
          Description: this.createNewField(separate, data[i]),
          Value: this.createNewField(separate, data[i].ObjectID != undefined ? data[i].ObjectID : data[i].Value),
        });
      }
    }
    return listSelectItem;
  }

  createNewField(separate = '', ...args: any[]) {
    if (args[0] != null && args[0] instanceof Array && args[0].length === 3) {
      return args[0].join(separate);
    } else {
      return args.join(separate);
    }

  }

  /**
   * Validate email field in formControl
   */

  customEmailValidator(control: AbstractControl): ValidationErrors {
    if (!control.value) {
      return null;
    }
    let regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (regex.test(control.value)) {
      return null
    } else {
      return { error: 'Not valid email' }
    }
  }

}
