import { Injectable } from '@angular/core';
import { ISubscription } from "rxjs/Subscription";

// Services
import { ApiService } from './api.service';
import { ConfigService } from './config.service';

// Interfaces
import { Params } from '../interfaces/common-interface';
import { GEOLOCATION_TYPE } from '../components/common/constants';
import * as _ from 'lodash';

@Injectable()
export class CommonService {

  queryByIdSub: ISubscription;
  queryAllDataSub: ISubscription;

  constructor(
    private apiService: ApiService,
    private configService: ConfigService
  ) {

  }

  /**
   * Function query by id
   */
  queryById(url, objectId): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'ByID',
        queryParams: {
          id: objectId
        }
      };
      this.queryByIdSub = this.apiService.post(url, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  query(url, queryParams, assocs: any = [], type: string = 'All'): Promise<any> {
    return new Promise((resolve, reject) => {
      let params = {
        queryType: type,
        environment: this.configService.get('environment'),
        queryParams: queryParams,
        assocs: assocs && assocs.length ? assocs : null
      };

      this.queryByIdSub = this.apiService.post(url, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  /**
   * Function query all
   */
  queryAllData(url): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All'
      };
      this.queryAllDataSub = this.apiService.post(url, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    })
  }

  getAddressDetail(addressComponent) {
    return {
      Country: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.COUNTRY) !== -1) {
          return s;
        }
      }),
      ZipCode: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.ZIP_CODE) !== -1) {
          return s;
        }
      }),
      City: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.CITY) !== -1) {
          return s;
        }
      }),
      StreetNumber: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_NUMBER) !== -1) {
          return s;
        }
      }),
      StreetAddress: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_ADDRESS) !== -1) {
          return s;
        }
      }),
      State: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STATE) !== -1) {
          return s;
        }
      })
    }
  }

  createGoogleAddress(model) {

  }

  createAddress(model) {

  }

}
