import { tassign } from 'tassign';
import { combineReducers } from 'redux';
import { OrganisationState, ORGANISATION_INITAL_STATE, organisationReducer } from './components/organisation/store';
import { ConfigurationState, CONFIGURATION_INITAL_STATE, configurationReducer } from './components/configuration/store';
import { RosteringState, ROSTERING_INITAL_STATE, rosteringReducer } from './components/rostering/store';
import { ClientsState, CLIENTS_INITAL_STATE, clientsReducer } from './components/clients/clients-store';
import { CommonState, COMMON_INITAL_STATE, commonReducer } from './components/common/common-store';

export interface IAppState {
    organisation: OrganisationState;
    configuration: ConfigurationState;
    rostering: RosteringState;
    clients: ClientsState;
    common: CommonState;
}

export const INITIAL_STATE: IAppState = {
    organisation: ORGANISATION_INITAL_STATE,
    configuration: CONFIGURATION_INITAL_STATE,
    rostering: ROSTERING_INITAL_STATE,
    clients: CLIENTS_INITAL_STATE,
    common: COMMON_INITAL_STATE
};

export const rootReducer = combineReducers<IAppState>({
    organisation: organisationReducer,
    configuration: configurationReducer,
    rostering: rosteringReducer,
    clients: clientsReducer,
    common: commonReducer
});
