import { SitesService } from './components/sites/sites.service';
import { DueActivitiesComponent } from './components/subs/due-activities/due-activities.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Http, HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { LocationStrategy, HashLocationStrategy, PathLocationStrategy } from '@angular/common';
import { FileUploadModule } from 'ng2-file-upload';
import { TextMaskModule } from 'angular2-text-mask';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { LoadingModule } from 'ngx-loading';

// Module
import { ConfigurationModule } from './components/configuration/configuration.module';
import { OrganisationModule } from './components/organisation/organisation.module';
import { UserInformationModule } from './components/user-information/user-information.module';
import { RosteringModule } from './components/rostering/rostering.module';
import { ClientsModule } from './components/clients/clients.module';
import { DashboardModule } from './components/dashboard/dashboard.module';
import { SharedProsekModule } from './shared/shared.module';
import { FilterModule } from './components/filter/filter.module';
import { ContactModule } from './components/contact/contact.module';
import { SitesModule } from './components/sites/sites.module';
import { AttachmentsModule } from './components/subs/attachments/attachments.module';
import { BannedEmployeesModule } from './components/subs/banned-employees/banned-employees.module';
import { ClientLoginAccessModule } from './components/subs/client-login-access/client-login-access.module';
import { ClientLoginDetailModule } from './components/subs/client-login-detail/client-login-detail.module';
import { ContactsModule } from './components/subs/contacts/contacts.module';
import { ContractDetailsModule } from './components/subs/contract-details/contract-details.module';
import { EmailsModule } from './components/subs/emails/emails.module';
import { NotesModule } from './components/subs/notes/notes.module';
import { OtherContactsModule } from './components/subs/other-contacts/other-contacts.module';
import { OtherServicesModule } from './components/subs/other-services/other-services.module';
import { SiteRosterModule } from './components/subs/site-roster/site-roster.module';
import { SitesSubModule } from './components/subs/sites/sites.module';
import { TaskActivitiesModule } from './components/subs/task-activities/task-activities.module';
import { ModalModule } from 'ngx-bootstrap';
import { DataTableModule } from 'primeng/datatable';
import { MomentModule } from 'angular2-moment';
import { AgmCoreModule } from '@agm/core';
import { CustomBrowserXhr } from './services/xhr.services';
import { TimePickerModule } from './components/time-picker/time-picker.module';

// Redux
import { NgRedux, NgReduxModule } from 'ng2-redux';
import { IAppState, rootReducer, INITIAL_STATE } from './store';

// Interceptors
import { CommonInterceptor } from './interceptors/common.interceptor';

// Component
import { AppComponent } from './app.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './pages/home/home.component';
import { BreadcrumbsComponent } from './shared/breadcrumb.component';

// Service
import { ConfigService } from './services/config.service';
import { ApiService } from './services/api.service';
import { HelperService } from './services/helper.service';
import { CommonService } from './services/common.service';

// Directive
import { AsideToggleDirective } from './shared/aside.directive';
import { NAV_DROPDOWN_DIRECTIVES } from './shared/nav-dropdown.directive';
import { SIDEBAR_TOGGLE_DIRECTIVES } from './shared/sidebar.directive';

// DatePipe
import { DataPipe } from './pipes/data.pipe';

// Routing Module
import { AppRoutingModule } from './app.routing';

// Guard
import { AuthAccountGuard } from './guards/auth-account.guard';
import { EmployeesModule } from './components/employees/employees.module';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDt-Juyn_jsjHciDSALWz158B3l8sbHeQE'
    }),
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    FileUploadModule,
    TextMaskModule,
    OrganisationModule,
    ConfigurationModule,
    UserInformationModule,
    RosteringModule,
    NgReduxModule,
    LoadingModule,
    HttpClientModule,
    DashboardModule,
    ClientsModule,
    ContactModule,
    SharedProsekModule,
    FilterModule,
    SitesModule,
    AttachmentsModule,
    BannedEmployeesModule,
    ClientLoginAccessModule,
    ClientLoginDetailModule,
    ContactsModule,
    EmailsModule,
    NotesModule,
    OtherContactsModule,
    OtherServicesModule,
    SiteRosterModule,
    SitesSubModule,
    EmployeesModule,
    TaskActivitiesModule,
    DataTableModule,
    MomentModule,
    TimePickerModule,
    // DueActivitiesModule
  ],
  declarations: [
    HeaderComponent,
    SidebarComponent,
    HomeComponent,
    AppComponent,
    BreadcrumbsComponent,
    NAV_DROPDOWN_DIRECTIVES,
    SIDEBAR_TOGGLE_DIRECTIVES,
    AsideToggleDirective,
    DataPipe,
    DueActivitiesComponent,
  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy,
  },
    ConfigService,
    ApiService,
    HelperService,
    CommonService,
    AuthAccountGuard,
    SitesService,
  {
    provide: CustomBrowserXhr,
    useClass: CustomBrowserXhr
  },
  {
    provide: APP_INITIALIZER,
    useFactory: appConfigFactory,
    deps: [ConfigService],
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: CommonInterceptor,
    multi: true
  }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(ngRedux: NgRedux<IAppState>) {
    ngRedux.configureStore(rootReducer, INITIAL_STATE);
  }
}

export function appConfigFactory(config: ConfigService) {
  return () => config.load();
}

