export class BannedEmployee {
    Site: string;
    SiteDetail: any;
    ActionsTakingDetails: null;
    ObjectClass = 'prosek.orm.BannedEmployee';
    ObjectID: string;
    BannedPeriod: any;
    BannedBy: string;
    BannedByDetail: any;
    NotificationTime: number;
    ObjectCreated: string;
    ObjectLastModified: string;
    BannedDate: string;
    BannedFromAllClientSites: any;
    Contact: string;
    ContactDetail: any;
    ClosedTime: string;
    BannedEmployee: string;
    BannedEmployeeDetail: any;
    ActionedBy: string;
    ActionedByDetail: any;
    NotificationType: any;
    ReasonForBanning: any;
    ClosedDate: any;
    ReminderType: any;
    BannedByOther: string;
}
