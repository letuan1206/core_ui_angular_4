export class User {
  ResetPassword: string;
  ObjectClass = 'oneit.security.SecUser';
  UserName: string;
  Email: string;
  ObjectID: string;
  FirstName: string;
  SupportUser: string;
  PrivsOverrides: string;
  Enabled: boolean;
  RolesOverrides: string;
  SupportKey: string;
  PasswordExpiryDate: string;
  UserDescription: string;
  GroupsOverrides: string;
  LastName: string;
  NewPassword: string;
}

export class UserInformation {
  ObjectClass = 'prosek.orm.ProsekAdminUserExtension';
  HeadingBarColour: string;
  GoogleAuthCode: string;
  GoogleRefreshToken: string;
  ObjectID: string;
  Position: string;
  MenuTextColour: string;
  GoogleAccessToken: string;
  GoogleTokenRequestedDate: string;
  Mobile: string;
  GmailAddress: string;
  EnforcePassword: string;
  Role: string;
  TimeZone: any;
  Language: any;
  MenuBarColour: string;
  Phone: string;
  HeadingTextColour: string;
  GoogleExpiresInSeconds: null;
  Divisions: any;
  TimeFormat: any;
  User: string;
  EmailSignature: string;
  Country: string;
  TimeFormatValue: string;
  TimeZoneValue: string;
  LanguageValue: string;
}

export class ClientInformation {
  Address: string;
  ContractExpiry: string;
  ContractExtended: any;
  ContractOption: any;
  ContractTerm: any;
  Description: string;
  Division: string;
  Email: string;
  Fax: string;
  Industry: string;
  ObjectClass = 'prosek.orm.Information'
  ObjectCreated: string;
  ObjectID: string;
  ObjectLastModified: string;
  OptionExpiry: string;
  Phone: string;
  PostalAddress: string;
  Rating: string;
  Recipients: string;
  ReportsByEmail: boolean;
  Services: any;
  StartDate: string;
  State: string;
  TerminationDate: string;
  TerminationReason: string;
  Website: string;
}

export class ProsekAdminUserDivisionLink {
  ObjectClass = 'prosek.orm.ProsekAdminUserDivisionLink';
  ObjectID: string;
  Division: string;
  AdminUser: string;
}

export class Role {
  ObjectClass = 'oneit.security.Role';
  Description: string;
  ObjectID: string;
  GrantPrivName: string;
  Name: string;
}
