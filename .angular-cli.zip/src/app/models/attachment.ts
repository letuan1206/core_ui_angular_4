export class Attachment {
    ObjectClass = 'prosek.orm.Attachment';
    FileName: string;
    Attachment: any;
    AttachedByStr: string;
    Site: string;
    Employee: string;
    ObjectID: string;
    Client: string;
    AttachedBy: string;
    Contact: string;
    ObjectLastModified: string;
    ObjectCreated: string;
}
