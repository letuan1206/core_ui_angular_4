import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivationEnd } from '@angular/router';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { ChipsModule } from 'primeng/chips';
import { FileUploader } from 'ng2-file-upload';
import { ConfigService } from './../../../services/config.service';
import { tassign } from 'tassign';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/first';
import { Observable } from 'rxjs/Observable';
import * as _ from 'lodash';
declare var $: any;

// Services
import { ClientsService } from '../clients.service';
import { HelperService } from './../../../services/helper.service';
import { ApiService } from './../../../services/api.service';

// Interface
import { ObjectAddress, ObjectClient, ObjectGoogleAddress, ObjectInformation } from '../../../interfaces/clients-interface';
import { AddOrEditTimelineComponent } from '../../subs/modals/add-or-edit-timeline/add-or-edit-timeline.component';
import { AddNoteModalComponent } from '../../subs/modals/add-note-modal/add-note-modal.component';
import { TimelineComponent } from '../../subs/timeline/timeline.component';

interface ClientDetailOverview {
  tradingName: string | null,
  companyName: string | null,
  phone: string,
  fax: string,
  email: string,
  emailAddress: string,
  website: string,
  // address: string,
  // portalAddress: string,
  rating: string,
  services: any[],
  state: string,
  division: string,
  industry: string,
  ABNnum: string | null,
  ACNnum: string | null,
  addToSite: boolean,
}

enum AddressAction {
  Add = 1,
  Update,
  Delete
}

enum Action {
  Edit = 1,
  Add
}

enum SectionData {
  Rating,
  State,
  Division,
  Industry,
  Service
}

@Component({
  selector: 'app-clients-detail',
  templateUrl: './clients-detail.component.html',
  styleUrls: ['./clients-detail.component.scss']
})
export class ClientsDetailComponent implements OnInit {
  @ViewChild('addOrEditTimelineModal') addOrEditTimelineModal: AddOrEditTimelineComponent;
  @ViewChild('addNotesModal') public addNotesModal: AddNoteModalComponent;
  @ViewChild('timelineTable') public timelineTable: TimelineComponent;

  // Variable for action (edit/add) client
  private action: Action = null;

  private clientId: string;
  // Client data for overview
  private clientDetailForm: FormGroup;
  private formDisabled: boolean = null;

  private listRatingOption: any[];
  private listServiceOption: any[];
  private listStateOption: any[];
  private listIndustryOption: any[];
  private listDivisionOption: any[];

  // Auto complete
  private filteredServiceMultiple: any[];
  private addressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };
  private googleAddressText: string;
  private postalAddressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };

  private enableBtnEdit: boolean;
  private oldDataTable: any;
  private oldAddress = {
    objectAddress: null,
    objectGoogleAddress: null
  };
  private oldPostalAddress = {
    objectAddress: null,
    objectGoogleAddress: null
  };

  private uploader: FileUploader;
  private logoImg: any;
  private oldLogo: string;

  // Object data from API
  private objectClient: ObjectClient;
  private listRefClient: any[];
  private objectClientInformation: ObjectInformation;
  private objectClientAddress: ObjectAddress;
  private objectClientPostalAddress: ObjectAddress;
  private objectClientGoogleAddress: ObjectGoogleAddress;
  private objectClientGooglePostalAddress: ObjectGoogleAddress;

  // Variable for address
  private objectClientNewAddress: ObjectAddress;
  private objectClientNewGoogleAddress: ObjectGoogleAddress;
  private objectClientNewPostalAddress: ObjectAddress;
  private objectClientNewGooglePostalAddress: ObjectGoogleAddress;

  // Variable for summary error
  private enableErrorSummary: boolean;
  private msgErrorSummary: string;

  constructor(
    private clientsService: ClientsService,
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService
  ) {
    this.route.params.subscribe(param => {
      this.clientId = param['id'];
    });
  }

  async ngOnInit() {
    window.scrollTo(0, 0);

    function onScrollClientDetails(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-5 ul li').each(function () {
        if ($('#section-client-detail').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr("href-anchor"));
          if (refElement.position() && refElement.position().top <= (scrollPos + 110)) {
            $('.ancho-5 ul li a').removeClass("active-menu");
            currLink.addClass("active-menu");
          } else {
            currLink.removeClass("active-menu");
          }
        }
      });
    }
    if ($('#section-client-detail').length) {
      $(document).on("scroll", onScrollClientDetails);
    }
    $('.ancho-5 ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-5 ul li a').removeClass("active-menu");
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });

    this.helperService.showLoading();
    this.formDisabled = true;

    this.objectClientNewAddress = null;
    this.objectClientNewGoogleAddress = null;
    this.objectClientNewPostalAddress = null;
    this.objectClientNewGooglePostalAddress = null;

    this.setDataForm(null);
    this.hideSummaryError();

    // Init file upload
    this.uploader = new FileUploader({ url: this.configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };

    // Set action (edit/add)
    await this.setAction();

    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      actionObs = this.initAddAction();
    }

    this.initDataRef()
      .flatMap(() => actionObs)
      .subscribe(res => {
        this.helperService.hideLoading();
      }, err => {
        this.helperService.hideLoading();
      })

  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  // Set action of this request
  private async setAction() {
    let params = await this.route.params.first().toPromise();
    let mapUrl = await this.route.url.first().toPromise();
    this.action = mapUrl.length > 0 && mapUrl[0].path !== 'add' ? Action.Edit : Action.Add;
    // if (this.action == Action.Add) {
    //   this.preClientId = params.clientId ? params.clientId : null;
    // }
    this.clientId = params.id && params.id !== 'add' ? params.id : null;
  }

  private updateClient() {
    if (!this.clientDetailForm.valid) {
      this.clientDetailForm.get('tradingName').markAsTouched();
      this.clientDetailForm.get('companyName').markAsTouched();
      this.clientDetailForm.get('email').markAsTouched();
      this.clientDetailForm.get('emailAddress').markAsTouched();

      this.clientDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    Observable.forkJoin([
      this.updateAddress(this.objectClientAddress, this.objectClientGoogleAddress, this.objectClientNewAddress, this.objectClientNewGoogleAddress),
      this.updateAddress(this.objectClientPostalAddress, this.objectClientGooglePostalAddress, this.objectClientNewPostalAddress, this.objectClientNewGooglePostalAddress),
      this.uploadLogo()
    ])
      .flatMap(resp => this.updateObjectClient(resp))
      .flatMap(() => this.reloadData())
      .subscribe(res => {
        this.uploader.clearQueue();
        this.helperService.hideLoading();
        this.hideSummaryError();

      }, err => {
        this.helperService.hideLoading();
      });
  }

  private addClient() {
    if (!this.clientDetailForm.valid) {
      this.clientDetailForm.get('tradingName').markAsTouched();
      this.clientDetailForm.get('companyName').markAsTouched();
      this.clientDetailForm.get('email').markAsTouched();
      this.clientDetailForm.get('emailAddress').markAsTouched();

      this.clientDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    let createObjectInformation = (address, logo) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.clientDetailForm.value;

        let objInfo: ObjectInformation = {
          ObjectID: null,
          ObjectClass: 'prosek.orm.Information',
          ObjectCreated: null,
          ObjectLastModified: null,
          Phone: valueOfForm.phone,
          Fax: valueOfForm.fax,
          Email: valueOfForm.email,
          Recipients: valueOfForm.emailAddress,
          Website: valueOfForm.website,
          Rating: valueOfForm.rating ? valueOfForm.rating.ObjectID : null,
          State: valueOfForm.state ? valueOfForm.state.ObjectID : null,
          Division: valueOfForm.division ? valueOfForm.division.ObjectID : null,
          Industry: valueOfForm.industry ? valueOfForm.industry.ObjectID : null,
          Address: address.length > 0 && address[0] ? address[0] : null,
          PostalAddress: address.length > 0 && address[1] ? address[1] : null,
          ContractExpiry: null,
          ContractExtended: null,
          ContractOption: null,
          ContractTerm: null,
          Description: null,
          OptionExpiry: null,
          ReportsByEmail: null,
          Services: [],
          StartDate: null,
          TerminationDate: null
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next([res.created[0], logo])
            } else {
              obs.error('Create object Information fail');
            }
          }, err => {
            obs.error(err);
          }
          )
      })

      return objObs;
    }

    let createObjectClient = (res) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.clientDetailForm.value;

        let objInfo: ObjectClient = {
          ObjectID: null,
          ObjectClass: 'prosek.orm.Client',
          ObjectCreated: null,
          ObjectLastModified: null,
          Active: true,
          TradingName: valueOfForm.tradingName !== '' ? valueOfForm.tradingName : null,
          CompanyName: valueOfForm.companyName !== '' ? valueOfForm.companyName : null,
          ABN: valueOfForm.ABNnum !== '' ? valueOfForm.ABNnum : null,
          ACN: valueOfForm.ACNnum !== '' ? valueOfForm.ACNnum : null,
          CopyInfoToSite: valueOfForm.addToSite,
          Information: res[0],
          Logo: res[1],
          InformationServices: valueOfForm.services.map(x => x.ObjectID),
          "Activity.CallAttempt": null,
          "Activity.LetterSent": null,
          "Activity.Email": null,
          "Activity.Meeting": null,
          "ActivityC.allReach": null
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next(res.created[0])
            } else {
              obs.error('Create object Site fail');
            }
          }, err => {
            obs.error(err);
          }
          )
      })

      return objObs;
    }

    Observable.forkJoin(
      this.updateAddress(this.objectClientAddress, this.objectClientGoogleAddress, this.objectClientNewAddress, this.objectClientNewGoogleAddress),
      this.updateAddress(this.objectClientPostalAddress, this.objectClientGooglePostalAddress, this.objectClientNewPostalAddress, this.objectClientNewGooglePostalAddress),
      this.uploadLogo()
    )
      .flatMap((resp: any) => {
        let logo = null;
        if (resp && resp.length > 0 && resp[2] && resp[2].token) {
          logo = { FileToken: resp[2].token }
        }
        return createObjectInformation(resp, logo);
      })
      .flatMap(res => createObjectClient(res))
      .subscribe(res => {
        this.helperService.hideLoading();
        let ObjectIDSite = res;

        // Navigate to new site
        this.router.navigate(['/clients/detail/', ObjectIDSite]);
        this.hideSummaryError();
      }, err => {
        this.helperService.hideLoading();

      });
  }

  private updateAddress(oAddress: ObjectAddress, oGAddress: ObjectGoogleAddress, nAddress: ObjectAddress, nGAddress: ObjectGoogleAddress) {
    let objObs = new Observable(obs => {
      let action = null;

      // Choose action for change of address
      if (!oAddress.ObjectID) {
        action = AddressAction.Add;
      } else {
        action = AddressAction.Update;
      }

      // Make
      switch (action) {
        case AddressAction.Add: {

          this.accessObject([nGAddress], [], [])
            .flatMap((listObj) => {
              // Assign object GoogleAddress to Address
              let nReturnGoogleAddress = listObj.created.length > 0 ? listObj.created[0] : null;
              if (!nReturnGoogleAddress) {
                return Observable.throw(new Error('Object Google Address wrong!'));
              }

              nAddress.GoogleAddress = nReturnGoogleAddress;
              return this.accessObject([nAddress], [], []);
            })
            .subscribe(res => {
              obs.next(res.created[0])
              obs.complete();;
            }, err => {
              obs.error(err);;
            })
          break;
        }

        case AddressAction.Update: {
          if (nGAddress.ObjectID) {
            this.accessObject([], [nAddress, nGAddress], [])
              .subscribe(res => {
                obs.next(res.updated.length > 0 ? res.updated[0] : null);
                obs.complete();
              }, err => {
                obs.error(err);
              })
          } else {
            this.accessObject([nGAddress], [], [])
              .flatMap((listObj: any) => {
                // Assign object GoogleAddress to Address
                nAddress.GoogleAddress = listObj.created.length > 0 ? listObj.created[0] : null;
                return this.accessObject([], [nAddress], [])
              })
              .subscribe(res => {
                obs.next(res.updated[0])
                obs.complete();
              }, err => {
                obs.error(err);
              })
          }
          break;
        }
      }
    })

    return objObs;
  }

  private accessObject(paramCreate: any[], paramUpdate: any[], paramDelete: any[]): Observable<any> {
    let params = {
      create: {},
      update: {},
      delete: {}
    }

    for (var i = 0; i < paramCreate.length; ++i) {
      params.create[`NEW:${i}`] = paramCreate[i];
    }

    for (var i = 0; i < paramUpdate.length; ++i) {
      params.update[paramUpdate[i].ObjectID] = paramUpdate[i];
    }

    for (var i = 0; i < paramDelete.length; ++i) {
      params.delete[paramDelete[i].ObjectID] = paramDelete[i];
    }

    let returnObject = {
      created: [],
      updated: [],
      deleted: []
    }

    let obsObj = new Observable(obs => {
      this.apiService.saveService(params)
        .subscribe(res => {
          if (res.result) {
            // Push created object
            Object.keys(res.created).map(function (key, index) {
              returnObject.created.push(res.created[key]);
            });

            // Push updated object
            paramUpdate.map(o => o.ObjectID).forEach(item => {
              if (res.updated.indexOf(item) != -1) {
                returnObject.updated.push(_.get(res.references, item))
              }
            });

            // Push deleted object
            returnObject.deleted = res.deleted;

            obs.next(returnObject);
            obs.complete();
          } else {
            obs.error("Create object Address fail")
          }
        }, err => {
          obs.error(err);
        })

    })

    return obsObj;
  }

  private showSummaryError(msg: string) {
    this.enableErrorSummary = true;
    this.msgErrorSummary = msg;
  }

  private hideSummaryError() {
    this.enableErrorSummary = false;
    this.msgErrorSummary = '';
  }

  private setDataForm(data: ClientDetailOverview) {
    if (!data) {
      // reset data
      data = {
        tradingName: null,
        companyName: null,
        phone: null,
        fax: null,
        email: null,
        emailAddress: null,
        website: null,
        // address: null,
        // portalAddress: null,
        rating: null,
        services: [],
        state: null,
        division: null,
        industry: null,
        ABNnum: null,
        ACNnum: null,
        addToSite: false,
      }
    }

    if (this.clientDetailForm) {
      this.clientDetailForm.setValue(data);
    } else {
      this.clientDetailForm = new FormGroup({
        tradingName: new FormControl(data.tradingName, Validators.required),
        companyName: new FormControl(data.companyName, Validators.required),
        phone: new FormControl(data.phone, this.customNumberValidator),
        fax: new FormControl(data.fax),
        email: new FormControl(data.email, this.helperService.customEmailValidator),
        emailAddress: new FormControl(data.emailAddress, this.helperService.customEmailValidator),
        website: new FormControl(data.website),
        // address: new FormControl(data.address),
        // portalAddress: new FormControl(data.portalAddress),
        rating: new FormControl(data.rating),
        services: new FormControl(data.services),
        state: new FormControl(data.state),
        division: new FormControl(data.division),
        industry: new FormControl(data.industry),
        ABNnum: new FormControl(data.ABNnum, this.customNumberValidator),
        ACNnum: new FormControl(data.ACNnum, this.customNumberValidator),
        addToSite: new FormControl(data.addToSite),
      })

      this.clientDetailForm.get('phone').valueChanges.subscribe((val: string) => this.resetIfNotANumber('phone', val));
      this.clientDetailForm.get('fax').valueChanges.subscribe((val: string) => this.resetIfNotANumber('fax', val));
    }
  }

  private initDataRef() {
    let obsObj = new Observable(obs => {
      Promise.all([
        this.getDataSection(SectionData.Rating).toPromise(),
        this.getDataSection(SectionData.State).toPromise(),
        this.getDataSection(SectionData.Division).toPromise(),
        this.getDataSection(SectionData.Industry).toPromise(),
        this.getDataSection(SectionData.Service).toPromise(),
      ]).then(res => {
        // Assign autoComplete
        let [dataRating, dataState, dataDivision, dataIndustry, dataService] = res;

        this.listRatingOption = _.filter(dataRating.references, x => dataRating.results.indexOf(x.ObjectID) !== -1);
        this.listServiceOption = _.filter(dataService.references, x => dataService.results.indexOf(x.ObjectID) !== -1);
        this.listStateOption = _.filter(dataState.references, x => dataState.results.indexOf(x.ObjectID) !== -1);
        this.listIndustryOption = _.filter(dataIndustry.references, x => dataIndustry.results.indexOf(x.ObjectID) !== -1);
        this.listDivisionOption = _.filter(dataDivision.references, x => dataDivision.results.indexOf(x.ObjectID) !== -1);

        obs.next();
        // obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private getDataSection(section: SectionData): Observable<any> {
    let obsObj = new Observable(obs => {
      let o = null;
      switch (section) {
        case SectionData.Rating: {
          o = this.clientsService.getAllRating();
          break;
        }
        case SectionData.State: {
          o = this.clientsService.getAllStates();
          break;
        }
        case SectionData.Division: {
          o = this.clientsService.getAllDivision();
          break;
        }
        case SectionData.Industry: {
          o = this.clientsService.getAllIndustry();
          break;
        }
        case SectionData.Service: {
          o = this.clientsService.getAllServices();
          break;
        }
      }

      o.then(res => {
        obs.next(res);
        obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private reloadData(): Observable<any> {
    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      // actionObs = this.initAddAction();
    }

    return actionObs;
  }

  private enableEditForm() {
    this.formDisabled = false;
    this.clientDetailForm.enable();
  }

  private disableEditForm() {
    this.formDisabled = true;
    this.clientDetailForm.disable();
  }

  // Get client data
  private getClientDetail() {
    let obsObj = new Observable(obs => {
      this.route.params.first()
        .subscribe(params => {
          this.clientsService.getDetailClient(params.id)
            .then(res => {
              obs.next(res);
              obs.complete();
            }, err => {
              obs.error(err);
            })
        }, err => {
          obs.error('Get client id fail!')
        })
    })

    return obsObj;
  }

  private initEditAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.disableEditForm();
      this.getClientDetail().toPromise()
        .then((res: any) => {
          // Assign Object Client
          this.listRefClient = res.references;

          this.objectClient = _.get(this.listRefClient, res.results[0]);
          this.objectClientInformation = this.objectClient.Information ? _.get<any, string>(this.listRefClient, this.objectClient.Information) : null;
          this.objectClientAddress = this.objectClientInformation && this.objectClientInformation.Address ? _.get<any, string>(this.listRefClient, this.objectClientInformation.Address) : null;
          this.objectClientGoogleAddress = this.objectClientAddress && this.objectClientAddress.GoogleAddress ? _.get<any, string>(this.listRefClient, this.objectClientAddress.GoogleAddress) : null;
          this.objectClientPostalAddress = this.objectClientInformation && this.objectClientInformation.PostalAddress ? _.get<any, string>(this.listRefClient, this.objectClientInformation.PostalAddress) : null;
          this.objectClientGooglePostalAddress = this.objectClientPostalAddress && this.objectClientPostalAddress.GoogleAddress ? _.get<any, string>(this.listRefClient, this.objectClientPostalAddress.GoogleAddress) : null;

          // Clone object address. CANT BE NULL
          let objectEmptyGoogleAddress: ObjectGoogleAddress = {
            ObjectClass: 'prosek.orm.GoogleAddress',
            ObjectCreated: null,
            ObjectID: null,
            ObjectLastModified: null,
            City: null,
            Country: null,
            GoogleAddressText: null,
            Latitude: null,
            Longitude: null,
            State: null,
            StreetAddress: null,
            StreetNumber: null,
            ZipCode: null
          };

          let objectEmptyAddress: ObjectAddress = {
            ObjectClass: 'prosek.orm.Address',
            GoogleAddress: null,
            ObjectCreated: null,
            ObjectID: null,
            ObjectLastModified: null,
            PostcodeSuburb: null,
            Street: null
          }

          this.objectClientNewAddress = this.objectClientAddress ? Object.assign({}, this.objectClientAddress) : Object.assign({}, objectEmptyAddress);
          this.objectClientNewGoogleAddress = this.objectClientGoogleAddress ? Object.assign({}, this.objectClientGoogleAddress) : Object.assign({}, objectEmptyGoogleAddress);
          this.objectClientNewPostalAddress = this.objectClientPostalAddress ? Object.assign({}, this.objectClientPostalAddress) : Object.assign({}, objectEmptyAddress);
          this.objectClientNewGooglePostalAddress = this.objectClientGooglePostalAddress ? Object.assign({}, this.objectClientGooglePostalAddress) : Object.assign({}, objectEmptyGoogleAddress);

          this.addressGeolocationSetting = Object.assign({}, this.addressGeolocationSetting, { inputString: this.objectClientAddress ? this.objectClientAddress.Street : '' });
          this.postalAddressGeolocationSetting = Object.assign({}, this.postalAddressGeolocationSetting, { inputString: this.objectClientPostalAddress ? this.objectClientPostalAddress.Street : '' });

          this.logoImg = this.objectClient && this.objectClient.Logo ? `${this.configService.get('webRoot')}/${this.objectClient.Logo.URI}` : null;
          this.oldLogo = this.logoImg;

          let objState = this.objectClientInformation && this.objectClientInformation.State ? _.get<any, string>(this.listRefClient, this.objectClientInformation.State) : null;
          let objRating = this.objectClientInformation && this.objectClientInformation.Rating ? _.get<any, string>(this.listRefClient, this.objectClientInformation.Rating) : null;
          let objIndustry = this.objectClientInformation && this.objectClientInformation.Industry ? _.get<any, string>(this.listRefClient, this.objectClientInformation.Industry) : null;
          let objDivision = this.objectClientInformation && this.objectClientInformation.Division ? _.get<any, string>(this.listRefClient, this.objectClientInformation.Division) : null;

          let objServiceArr = _.filter(this.listServiceOption, x => {
            return this.objectClient.InformationServices.indexOf(x.ObjectID) !== -1
          });

          let clientDetail: ClientDetailOverview = {
            tradingName: this.objectClient !== null ? this.objectClient.TradingName : null,
            companyName: this.objectClient !== null ? this.objectClient.CompanyName : null,
            phone: this.objectClientInformation !== null ? this.objectClientInformation.Phone : null,
            fax: this.objectClientInformation !== null ? this.objectClientInformation.Fax : null,
            email: this.objectClientInformation !== null ? this.objectClientInformation.Email : null,
            emailAddress: this.objectClientInformation ? this.objectClientInformation.Recipients : null,
            website: this.objectClientInformation !== null ? this.objectClientInformation.Website : null,
            // address: this.objectClientAddress !== null ? this.objectClientAddress.Street : null,
            // portalAddress: objAddressPostal !== null ? objAddressPostal.Street : null,
            rating: objRating !== null ? objRating : null,
            services: objServiceArr,
            state: objState !== null ? objState : null,
            division: objDivision !== null ? objDivision : null,
            industry: objIndustry !== null ? objIndustry : null,
            ABNnum: this.objectClient !== null ? this.objectClient.ABN : null,
            ACNnum: this.objectClient && this.objectClient.ACN !== undefined ? this.objectClient.ACN : null,
            addToSite: this.objectClient && this.objectClient.CopyInfoToSite !== undefined ? this.objectClient.CopyInfoToSite : false
          }

          this.setDataForm(clientDetail);

          // Complete init
          obs.next(null)
          obs.complete();
        }, err => {
          obs.error(err);
        })
    })

    return obsObj;
  }

  private initAddAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.enableEditForm();

      // Clone object address. CANT BE NULL
      let objectEmptyGoogleAddress: ObjectGoogleAddress = {
        ObjectClass: 'prosek.orm.GoogleAddress',
        ObjectCreated: null,
        ObjectID: null,
        ObjectLastModified: null,
        City: null,
        Country: null,
        GoogleAddressText: null,
        Latitude: null,
        Longitude: null,
        State: null,
        StreetAddress: null,
        StreetNumber: null,
        ZipCode: null
      };

      let objectEmptyAddress: ObjectAddress = {
        ObjectClass: 'prosek.orm.Address',
        GoogleAddress: null,
        ObjectCreated: null,
        ObjectID: null,
        ObjectLastModified: null,
        PostcodeSuburb: null,
        Street: null
      }

      this.objectClientAddress = Object.assign({}, objectEmptyAddress);
      this.objectClientGoogleAddress = Object.assign({}, objectEmptyGoogleAddress);
      this.objectClientPostalAddress = Object.assign({}, objectEmptyAddress);
      this.objectClientGooglePostalAddress = Object.assign({}, objectEmptyGoogleAddress);

      this.objectClientNewAddress = Object.assign({}, objectEmptyAddress);
      this.objectClientNewGoogleAddress = Object.assign({}, objectEmptyGoogleAddress);
      this.objectClientNewPostalAddress = Object.assign({}, objectEmptyAddress);
      this.objectClientNewGooglePostalAddress = Object.assign({}, objectEmptyGoogleAddress);

      obs.next();
      obs.complete();
    })

    return obsObj;
  }

  private autoCompleteAddressCallback(selectedData: any, type) {
    // Init Object GoogleAddress and Address
    let objectGoogleAddress: ObjectGoogleAddress = {
      ObjectClass: 'prosek.orm.GoogleAddress',
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      City: null,
      Country: null,
      GoogleAddressText: null,
      Latitude: null,
      Longitude: null,
      State: null,
      StreetAddress: null,
      StreetNumber: null,
      ZipCode: null
    };

    let objectAddress: ObjectAddress = {
      ObjectClass: 'prosek.orm.Address',
      GoogleAddress: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      PostcodeSuburb: null,
      Street: null
    }

    if (selectedData.response) {
      // Parse address
      let addressDetail = this.clientsService.getAddressDetail(selectedData.data.address_components);

      objectGoogleAddress.City = addressDetail.City ? addressDetail.City.long_name : null;
      objectGoogleAddress.Country = addressDetail.Country ? addressDetail.Country.long_name : null;
      objectGoogleAddress.State = addressDetail.State ? addressDetail.State.long_name : null;
      objectGoogleAddress.StreetAddress = addressDetail.StreetAddress ? addressDetail.StreetAddress.long_name : null;
      objectGoogleAddress.StreetNumber = addressDetail.StreetNumber ? addressDetail.StreetNumber.long_name : null;
      objectGoogleAddress.ZipCode = addressDetail.ZipCode ? addressDetail.ZipCode.long_name : null;
      objectGoogleAddress.GoogleAddressText = selectedData.data.description;
      objectGoogleAddress.Latitude = selectedData.data.geometry.location.lat;
      objectGoogleAddress.Longitude = selectedData.data.geometry.location.lng;
    }

    /**
    /* Update object
    */
    if (type === 'Address') {
      /**
      /* Update for input Address
      */

      // Object GoogleAddress
      if (this.objectClientGoogleAddress && this.objectClientGoogleAddress.ObjectID) {
        this.objectClientNewGoogleAddress = Object.assign({}, objectGoogleAddress, {
          ObjectID: this.objectClientGoogleAddress.ObjectID,
          ObjectCreated: this.objectClientGoogleAddress.ObjectCreated
        })
      } else {
        this.objectClientNewGoogleAddress = Object.assign({}, objectGoogleAddress);
      }

      // Object Address
      if (this.objectClientAddress && this.objectClientAddress.ObjectID) {
        this.objectClientNewAddress = Object.assign({}, objectAddress, {
          ObjectID: this.objectClientAddress.ObjectID,
          ObjectCreated: this.objectClientAddress.ObjectCreated,
          GoogleAddress: this.objectClientAddress.GoogleAddress
        })
      } else {
        this.objectClientNewAddress = Object.assign({}, objectAddress);
      }

      if (selectedData.response) {
        this.objectClientNewAddress.Street = selectedData.data.description;
      }

    } else if (type === 'PostalAddress') {
      /**
      /* Update for input PostalAddress
      */

      // Object GoogleAddress
      if (this.objectClientGooglePostalAddress && this.objectClientGooglePostalAddress.ObjectID) {
        this.objectClientNewGooglePostalAddress = Object.assign({}, objectGoogleAddress, {
          ObjectID: this.objectClientGooglePostalAddress.ObjectID,
          ObjectCreated: this.objectClientGooglePostalAddress.ObjectCreated
        })
      } else {
        this.objectClientNewGooglePostalAddress = Object.assign({}, objectGoogleAddress);
      }

      // Object Address
      if (this.objectClientPostalAddress && this.objectClientPostalAddress.ObjectID) {
        this.objectClientNewPostalAddress = Object.assign({}, objectAddress, {
          ObjectID: this.objectClientPostalAddress.ObjectID,
          ObjectCreated: this.objectClientPostalAddress.ObjectCreated,
          GoogleAddress: this.objectClientPostalAddress.GoogleAddress
        })
      } else {
        this.objectClientNewPostalAddress = Object.assign({}, objectAddress);
      }

      if (selectedData.response) {
        this.objectClientNewPostalAddress.Street = selectedData.data.description;
      }
    }

  }

  /**
   * Custom Validator Begin
   */
  private customNumberValidator(control: AbstractControl): ValidationErrors {
    if (!control.value) {
      return null;
    }

    const message = {
      'message': 'Must be number'
    };
    let retVal = /^[0-9]*$/.test(control.value);
    return retVal ? null : message;
  }

  private resetIfNotANumber(controlName: string, val: string) {
    if (val == null) {
      return;
    }

    let isValid = /^[0-9]*$/.test(val);
    if (!isValid) {
      this.clientDetailForm.get(controlName).setValue(val.slice(0, val.length - 1))
    }
  }

  /**
   * Custom Validator End
   */

  private loadLogo(event: any): any {
    var reader = new FileReader();
    reader.onload = () => {
      var dataURL = reader.result;
      this.logoImg = dataURL;
    };
    reader.readAsDataURL(event[0]);
  }

  private uploadLogo() {
    let objObs = new Observable(obs => {
      if (this.uploader.queue.length == 0) {
        obs.next(null);
        obs.complete();
      } else {
        this.uploader.queue.forEach(item => {
          item.upload();
        });
      }

      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          let resp = JSON.parse(response);
          if (resp.files && resp.files.length > 0) {
            obs.next(resp.files[0]);
            obs.complete();
          } else {
            obs.error('Upload photo fail');
          }
        } else {
          obs.error('Upload photo fail');
        }
      };

    })

    return objObs;
  }

  private clearLogoSelected() {
    this.uploader.clearQueue();
    this.logoImg = this.oldLogo;
  }

  private removeLogo() {
    this.logoImg = null;
    this.oldLogo = null;
  }

  private updateObjectClient(resp): Observable<any> {
    let valueOfForm = this.clientDetailForm.value;

    if (!this.logoImg) {
      this.objectClient.Logo = null;
    } else {
      if (resp.length > 0 && resp[2]) {
        this.objectClient.Logo = { FileToken: resp[2].token }
      }
    }

    this.objectClient.TradingName = valueOfForm.tradingName !== '' ? valueOfForm.tradingName : null;
    this.objectClient.CompanyName = valueOfForm.companyName !== '' ? valueOfForm.companyName : null;
    this.objectClient.ABN = valueOfForm.ABNnum !== '' ? valueOfForm.ABNnum : null;
    this.objectClient.ACN = valueOfForm.ACNnum !== '' ? valueOfForm.ACNnum : null;
    this.objectClient.CopyInfoToSite = valueOfForm.addToSite;
    this.objectClient.InformationServices = valueOfForm.services.map(x => x.ObjectID);

    this.objectClientInformation.Phone = valueOfForm.phone;
    this.objectClientInformation.Fax = valueOfForm.fax;
    this.objectClientInformation.Email = valueOfForm.email;
    this.objectClientInformation.Recipients = valueOfForm.emailAddress;
    this.objectClientInformation.Website = valueOfForm.website;
    this.objectClientInformation.Division = valueOfForm.division;
    this.objectClientInformation.Rating = valueOfForm.rating !== null ? valueOfForm.rating.ObjectID : null;
    this.objectClientInformation.State = valueOfForm.state !== null ? valueOfForm.state.ObjectID : null;
    this.objectClientInformation.Division = valueOfForm.division !== null ? valueOfForm.division.ObjectID : null;
    this.objectClientInformation.Industry = valueOfForm.industry !== null ? valueOfForm.industry.ObjectID : null;
    this.objectClientInformation.Address = resp.length > 0 && resp[0] ? resp[0] : this.objectClientInformation.Address;
    this.objectClientInformation.PostalAddress = resp.length > 0 && resp[1] ? resp[1] : this.objectClientInformation.PostalAddress;

    return this.accessObject([], [this.objectClientInformation, this.objectClient], []);
  }

  private autoComplete(event, listSuggest: any[]) {
    let inputText = event.query;
    let filtered: any[] = [];

    for (let i = 0; i < listSuggest.length; i++) {
      let item = listSuggest[i];
      if (item.Description.toLowerCase().indexOf(inputText.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }

    this.filteredServiceMultiple = filtered;
  }

  private resetDataForm() {
    if (this.action == Action.Edit) {
      this.helperService.showLoading();
      this.reloadData()
        .subscribe(res => {
          this.helperService.hideLoading();
        }, err => {
          this.helperService.hideLoading();
        });
    } else {
      this.router.navigate(['clients/'])
    }

  }

  private async setActiveClient(value: boolean) {
    let obj = {
      ObjectClass: 'prosek.orm.Client',
      ObjectID: this.objectClient.ObjectID,
      Active: value
    }

    this.accessObject([], [obj], [])
      .subscribe(res => {
        this.objectClient.Active = value;
      }, err => {
        console.log(err);
      })
  }

  validateService(event) {
    if (!this.filteredServiceMultiple || (this.filteredServiceMultiple && this.filteredServiceMultiple.length == 0)) {
      event.target.value = "";
    }
  }
  
  private checkAutoComplete(event, listSuggest: any[]) {
    let inputText = event.query;
    let filtered: any[] = [];

    for (let i = 0; i < listSuggest.length; i++) {
      let item = listSuggest[i];
      if (item.Description.toLowerCase().indexOf(inputText.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }

    // if (type === 'Rating') {
    //   this.filteredRatingMultiple = filtered;
    // } else if (type === 'Service') {
    //   this.filteredServiceMultiple = filtered;
    // } else if (type === 'State') {
    //   this.filteredStateMultiple = filtered;
    // } else if (type === 'Industry') {
    //   this.filteredIndustryMultiple = filtered;
    // } else if (type === 'Division') {
    //   this.filteredDivisionMultiple = filtered;
    // }

    this.filteredServiceMultiple = filtered;
  }

  saveTimelineSuccessed(event) {
    this.timelineTable.saveTimelineSuccessed(event);
  }

  saveNoteSuccessed(event) {
    this.timelineTable.saveNoteSuccessed(event);
  }

  showAddNotesModal() {
    this.addNotesModal.initParams(this.clientId);
    this.addNotesModal.show();
  }

  showAddOrEditTimelineModal(type) {
    this.addOrEditTimelineModal.initParams(this.clientId, type);
    this.addOrEditTimelineModal.show();
  }
}
