import { tassign } from 'tassign';
import * as actions from './clients-actions';

export interface ClientsState {
  clientRef: any;
  clientResult: any;
}

export const CLIENTS_INITAL_STATE: ClientsState = {
  clientRef: [],
  clientResult: []
};

function storeClientRef(state, action) {
  return tassign(state, { 
    clientRef: action.payload
  });
}

function storeClientResult(state, action) {
  return tassign(state, {
    clientResult: action.payload
  });
}

export function clientsReducer(state = CLIENTS_INITAL_STATE, action): ClientsState {
  switch (action.type) {
    case actions.STORE_CLIENT_REFERENCE: return storeClientRef(state, action);
    case actions.STORE_CLIENT_RESULT: return storeClientResult(state, action);
  }

  return state;
}
