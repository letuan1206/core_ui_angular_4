import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from "rxjs/Subscription";
import * as _ from 'lodash';
import { GEOLOCATION_TYPE } from '../common/constants';

// Services
import { HelperService } from './../../services/helper.service';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';

// Interfaces
import { Params } from '../../interfaces/common-interface';
import { ClientsTransformParam } from '../../interfaces/clients-interface';

// Redux 
import {
  STORE_FILTER_STATE,
  STORE_FILTER_STATUS,
  STORE_FILTER_SERVICE,
  STORE_FILTER_DIVISION,
  STORE_CLIENTS_DATA
} from '../common/common-actions';

@Injectable()
export class ClientsService {

  getAllClientsSub: ISubscription;
  getAllServicesSub: ISubscription;
  getAllStatesSub: ISubscription;
  getAllDivisionByStateSub: ISubscription;
  getAllDivisionSub: ISubscription;
  getAllIndustrySub: ISubscription;

  constructor(
    public configService: ConfigService,
    private apiService: ApiService,
    private helperService: HelperService
  ) {

  }

  getAllClients(clientParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: clientParams,
        assocs: ['Information', 'Information.Address', 'Information.Services', 'Information.State', 'Information.Division']
      };
      this.getAllClientsSub = this.apiService.post(`/Clients`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getDetailClient(Id: string): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: Id
        },
        assocs: ['Information', 'Information.Address', 'Information.Services', 'Information.State', 'Information.PostalAddress', 'Information.Industry', 'Information.Rating', 'Information.Division', 'Information.Address.GoogleAddress', 'Information.PostalAddress.GoogleAddress']
      };
      this.getAllClientsSub = this.apiService.post(`/Clients`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllServices(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All',
        assocs: []
      };
      this.getAllServicesSub = this.apiService.post(`/Services`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllRating(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All',
        assocs: []
      };
      this.getAllServicesSub = this.apiService.post(`/Ratings`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllStates(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_COUNTRY',
        queryParams: {},
        assocs: []
      };
      this.getAllStatesSub = this.apiService.post(`/CountryState`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllDivision(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_DETAILS',
        queryParams: {},
        assocs: []
      };
      this.getAllDivisionSub = this.apiService.post(`/Division`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllIndustry(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.getAllIndustrySub = this.apiService.post(`/Industries`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getContractPeriods(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.apiService.post(`/ContractPeriods`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getContractExtendedTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.apiService.post(`/ContractExtendedTypes`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllDivisionByState(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_DETAILS',
        queryParams: {},
        assocs: ['State']
      };
      this.getAllDivisionByStateSub = this.apiService.post(`/Division`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAddressDetail(addressComponent) {
    return {
      Country: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.COUNTRY) !== -1) {
          return s;
        }
      }),
      ZipCode: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.ZIP_CODE) !== -1) {
          return s;
        }
      }),
      City: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.CITY) !== -1) {
          return s;
        }
      }),
      StreetNumber: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_NUMBER) !== -1) {
          return s;
        }
      }),
      StreetAddress: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_ADDRESS) !== -1) {
          return s;
        }
      }),
      State: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STATE) !== -1) {
          return s;
        }
      })
    }
  }
  /**
   * Function load data of clients
   */
  async loadDataClients(type, queryParams, stateOptions, serviceOptions, divisionOptions, statusOptions) {

    this.helperService.showLoading();

    try {

      let asyncDataClient = this.getAllClients(queryParams);
      let asyncDataService = this.getAllServices();
      let asyncDataDivision = this.getAllDivisionByState();
      let dataClient = await asyncDataClient;
      let dataService = await asyncDataService;
      let dataDivision = await asyncDataDivision;
      if (dataClient.result === this.configService.successStatus && dataService.result === this.configService.successStatus && dataDivision.result === this.configService.successStatus) {
        let transformParam: ClientsTransformParam = new ClientsTransformParam();
        transformParam.dataClient = dataClient;
        transformParam.dataDivision = dataDivision;
        transformParam.dataService = dataService;
        transformParam.stateOptions = stateOptions;
        transformParam.serviceOptions = serviceOptions;
        transformParam.divisionOptions = divisionOptions;
        let resultOfClients: any = this.helperService.transformData(transformParam);

        let datas = resultOfClients.datas;
        stateOptions = resultOfClients.stateOptions;
        serviceOptions = resultOfClients.serviceOptions;
        divisionOptions = resultOfClients.divisionOptions;

        this.helperService.dispatchToRedux(STORE_CLIENTS_DATA, datas);

        if (type && type === this.configService.get('typeLoad')) {
          this.helperService.dispatchToRedux(STORE_FILTER_STATE, stateOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_STATUS, statusOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_SERVICE, serviceOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_DIVISION, divisionOptions);
        }

      } else {
        throw Error('error');
      }
      this.helperService.hideLoading();
    } catch (e) {
      this.helperService.hideLoading();
      this.helperService.handleError(e);
    }
  }

}
