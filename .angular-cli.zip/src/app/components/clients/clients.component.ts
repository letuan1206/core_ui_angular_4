import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from 'angular-2-dropdown-multiselect';

// Redux
import { NgRedux, select } from 'ng2-redux';

// Services
import { ClientsService } from './clients.service';
import { ConfigService } from './../../services/config.service';
import { HelperService } from './../../services/helper.service';

// Interfaces
import { ClientsParam, DataOfTableClient } from '../../interfaces/clients-interface';
import { StatusOptions, ServiceOptions, StateOptions, DivisionOptions } from '../../interfaces/common-interface';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.scss']
})

export class ClientsComponent implements OnInit, OnDestroy {

  typeFilter: string;

  clientsArr: any = [];

  statusOptions: StatusOptions[] = [
    {
      Description: "Active Only",
      Value: "ACTIVE"
    }, 
    {
      Description: "Include Inactive",
      Value: "INACTIVE"
    }
  ];
  serviceOptions: ServiceOptions[] = [
    {
      Active: null,
      Description: 'Choose Service',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  stateOptions: StateOptions[] = [
    {
      Active: null,
      Country: null,
      Name: 'Choose State',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  divisionOptions: DivisionOptions[] = [
    {
      Active: null,
      Description: 'Choose Division',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      State: null
    }
  ];
  
  queryClientParams: ClientsParam = {
    ActiveStatus: null,
    Service: null,
    Division: null,
    Rating: null,
    State: null
  }

  @select(s => s.common.clientsData) clientsData;

  constructor(
    private clientsService: ClientsService,
    private configService: ConfigService,
    private helperService: HelperService,
    private router: Router,
    private ngRedux: NgRedux<any>
  ) { 
    this.clientsData.subscribe(data => {
      this.clientsArr = data;
    });
  }

  ngOnInit() {
    this.typeFilter = this.configService.get('menuType')['clients'];
    this.queryClientParams.ActiveStatus = this.statusOptions[0];
    this.clientsService.loadDataClients(this.configService.get('typeLoad'), this.queryClientParams, this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  handleRowClick(event) {
    this.router.navigate(['/clients/detail', event.data.objectID]);
  }

  ngOnDestroy() {
    this.clientsService.getAllClientsSub.unsubscribe();
    this.clientsService.getAllServicesSub.unsubscribe();
    this.clientsService.getAllDivisionByStateSub.unsubscribe();
  }

}
