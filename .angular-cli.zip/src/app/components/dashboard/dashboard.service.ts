import { Report } from './../../models/report';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { ConfigService } from '../../services/config.service';
import { ApiService } from '../../services/api.service';
import { HelperService } from '../../services/helper.service';
import * as _ from 'lodash';
import { STORE_FILTER_TYPE, STORE_FILTER_REPORT_STATUSES, STORE_REPORT_DATA, STORE_FILTER_CATEGORY, STORE_FILTER_SITE } from '../common/common-actions';
import { SitesService } from '../sites/sites.service';

@Injectable()
export class DashboardService {

  constructor(
    private http: Http,
    public configService: ConfigService,
    private api: ApiService,
    private helperService: HelperService,
    private siteService: SitesService
  ) { }

  async loadReport(queryParams, loadFilter = false) {
    try {
      this.helperService.showLoading();
      let reportStatuses = this.getReportStatuses();
      let report = this.getReport(queryParams);

      if (loadFilter) {
        let reportType = this.getReportType()
        let sites = this.siteService.getAllSites("", false);
        let categories = this.getCategory();

        let filterReportType = await reportType;
        let filterSite = await sites;
        let filterCategory = await categories;

        this.helperService.dispatchToRedux(STORE_FILTER_CATEGORY, this.helperService.listSelectItem(filterCategory.references, ',', "Name"));
        this.helperService.dispatchToRedux(STORE_FILTER_SITE, this.helperService.listSelectItem(filterSite.references, ',', "SiteName"));
        this.helperService.dispatchToRedux(STORE_FILTER_TYPE, _.values(filterReportType.references));
      }

      let filterReportStatuses = await reportStatuses;
      let data = await report;

      this.helperService.dispatchToRedux(STORE_FILTER_REPORT_STATUSES, filterReportStatuses.results);

      if (data.result === this.configService.settings.status.success) {
        let reports: Report[] = [];
        for (let i in data.results) {
          let object: Report = null;
          object = data.references[data.results[i]];

          let dataTmp = [];
          if (object.FieldValues) {
            object.FieldValues.forEach(element => {
              let item = data.references[element];
              item.ReportFieldDetail = data.references[item.ReportField];
              dataTmp.push(item);
            });
            object.FieldValuesDetail = dataTmp;
          }

          object.ReportPhotosDetail = [];
          if (object.ReportPhotos) {
            object.ReportPhotos.forEach(element => {
              object.ReportPhotosDetail.push(data.references[element]);
            });
          }

          if (object.ReportSubCategory) {
            object.ReportSubCategoryDetail = data.references[object.ReportSubCategory];
          }

          if (object.ReportCategory) {
            object.ReportCategoryDetail = data.references[object.ReportCategory];
          }

          if (object.GuardUser) {
            object.GuardUserDetail = data.references[object.GuardUser];
          }

          if (object.Site) {
            object.SiteDetail = data.references[object.Site];
          }

          reports.push(object);
        }

        this.helperService.dispatchToRedux(STORE_REPORT_DATA, reports);
      }

      this.helperService.hideLoading();

    } catch (e) {
      console.error(e);
    }
  }

  createObjectForUpdateReport(report) {
    let data: any = {};
    data[report.ObjectID] = {
      ObjectClass: report.ObjectClass,
      ObjectID: report.ObjectID,
      ReportStatus: report.ReportStatus
    }
    return data;
  }

  updateReport(report): Promise<any> {
    let objectCompany: any = this.createObjectForUpdateReport(report);
    let param = {
      environment: this.configService.settings.environment,
      create: {
      },
      update: {
      }
    }
    return new Promise((resolve, reject) => {
      param.update = objectCompany
      param.create = null;
      this.api.post('/Save', param).subscribe(res => {
        resolve(res);
      }, err => {
        reject(this.configService.settings.MESSAGE.SERVER_NOT_RESPONSE);
      });

    });
  }

  getReportType(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
      }

      this.api.post(`/ReportTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, err => {
          reject(err);
        });
    });
  }

  getCategory(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
      }

      this.api.post(`/ReportCategories`, params)
        .subscribe(res => {
          resolve(res);
        }, err => {
          reject(err);
        });
    });
  }

  getReportStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
      }

      this.api.post(`/ReportStatuses`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getReport(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        queryParams: data,
        assocs: ['Site', 'GuardUser', 'ReportForm', 'ReportForm.Type', 'ReportForm.ReportFormCategories', 'ReportCategory', 'ReportSubCategory', 'FieldValues.ReportField', 'FieldValues', 'ReportPhotos']
      }

      this.api.post(`/Reports`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }
}
