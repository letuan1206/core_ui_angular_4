import { HelperService } from './../../services/helper.service';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, AfterViewInit {
  id_country: string;
  id_state: string;
  id_division: string;
  id_ratings: string;
  id_services: string;
  id_industry: string;
  id_position: string;

  constructor(private router: Router,
    private helperService: HelperService
  ) {
    this.id_country = 'section-5';
    this.id_state = 'section-6';
    this.id_division = 'section-7';
    this.id_ratings = 'section-8';
    this.id_services = 'section-9';
    this.id_industry = 'section-10';
    this.id_position = 'section-11';
  }
  ngOnInit() {
    const routerURL = this.router.url;

    $('body').addClass('sidebar-minimized brand-minimized');

  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

}