import { Component, OnInit, ViewChild } from '@angular/core';
import { ReportStatus, Report } from '../../../models/configuration';
import { Router } from '@angular/router';
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { DashboardService } from '../dashboard.service';
import { select } from 'ng2-redux';
import { ModalDirective } from 'ngx-bootstrap';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';
import * as _ from 'lodash';
@Component({
  selector: 'app-submitted-reports',
  templateUrl: './submitted-reports.component.html',
  styleUrls: ['./submitted-reports.component.scss']
})
export class SubmittedReportsComponent implements OnInit {
  @ViewChild('viewMapModal') viewMapModal: ModalDirective;
  @ViewChild('modalReport') modal: ModalDirective;
  @ViewChild('modalViewReportDetail') modalViewReportDetail: ModalDirective;

  @ViewChild(SignaturePad) signaturePad: SignaturePad;

  private signaturePadOptions: Object = {
    'minWidth': 5,
    'canvasWidth': 500,
    'canvasHeight': 300
  };

  @ViewChild('gmap') gmapElement: any;
  public map: google.maps.Map;

  id_country: string;
  id_state: string;
  id_division: string;
  id_ratings: string;
  id_services: string;
  id_industry: string;
  id_position: string;

  filterData: any = {};

  typeFilter: string;
  reports = [];
  reportStatusesChoose: any = null;
  filterRepostStatusesData: any = null;
  selectedObject: any = null;
  oldObject: any = null;
  report: any = null;
  reportDetail: Report;
  imageUrl: string;

  @select(s => s.common.reportsData) reportsData;
  @select(s => s.common.filterReportStatuses) filterRepostStatuses;
  constructor(private router: Router,
    private helperService: HelperService,
    private configService: ConfigService,
    private dashboardService: DashboardService
  ) {
    this.id_country = 'section-5';
    this.id_state = 'section-6';
    this.id_division = 'section-7';
    this.id_ratings = 'section-8';
    this.id_services = 'section-9';
    this.id_industry = 'section-10';
    this.id_position = 'section-11';

    this.reportsData.subscribe(data => {
      this.reports = data;
    });

    this.filterRepostStatuses.subscribe(data => {
      this.filterRepostStatusesData = data;
    });
    this.imageUrl = configService.get('webRoot');
  }
  ngOnInit() {
    this.typeFilter = this.configService.get('menuType')['report'];
    this.dashboardService.loadReport({}, true);
  }


  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  viewReportDetail(event) {
    console.log(event);
    this.reportDetail = event;
    this.signaturePad.fromDataURL(this.reportDetail.Signature);
    this.signaturePad.off();
    this.modalViewReportDetail.show();
  }

  confirmStatus(report) {
    this.modal.show();
    this.report = report;
  }

  getOldValue(object) {
    this.oldObject = object.ReportStatus;
    this.report = object;
  }

  customCompare(o1: ReportStatus, o2: ReportStatus) {
    return o1.Value == (o2 && o2.Value ? o2.Value : null);
  }

  hide(isYes) {
    try {
      if (isYes) {
        this.UpdateStatus();
      } else {
        this.report.ReportStatus = _.find(this.filterRepostStatusesData, s => {
          if (s.Value == this.oldObject.Value) {
            return s;
          }
        });
      }
      this.modal.hide();
    } catch (e) {
      console.log(e);
    }
  }

  async UpdateStatus() {
    try {
      let data = await this.dashboardService.updateReport(this.report);
      if (data.result === this.configService.settings.status.success) {

      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }

  // init Map
  openModalViewMap(reportData) {
    this.viewMapModal.show();
    let locationData = {
      lat: reportData.Latitude,
      lng: reportData.Longitude
    }
    this.initMap(locationData);
  }

  closeMapModal() {
    this.viewMapModal.hide();
  }

  initMap(locationData) {
    let mapProp = {
      center: new google.maps.LatLng(locationData.lat, locationData.lng),
      zoom: 19,
      mapTypeId: google.maps.MapTypeId.SATELLITE
    };
    this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);
    var marker = new google.maps.Marker({
      position: locationData,
      map: this.map,
      title: 'Hello World!'
    });
  }

}
