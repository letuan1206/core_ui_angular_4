import { ErrorMessageComponent } from './../error-message/error-message.component';
import { TextMaskModule } from 'angular2-text-mask';
import { FileUploadModule } from 'ng2-file-upload';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './../../app.routing';
import { BrowserModule } from '@angular/platform-browser';
import { ConfigurationCountryComponent } from './configuration-country/configuration-country.component';
import { ConfigurationService } from './configuration.service';
import { ConfigurationModalServiceComponent } from './modals/configuration-modal-service/configuration-modal-service.component';
import { ConfigurationModalRatingComponent } from './modals/configuration-modal-rating/configuration-modal-rating.component';
import { ConfigurationModalPositionComponent } from './modals/configuration-modal-position/configuration-modal-position.component';
import { ConfigurationModalIndustryComponent } from './modals/configuration-modal-industry/configuration-modal-industry.component';
import { ConfigurationModalDivisionComponent } from './modals/configuration-modal-division/configuration-modal-division.component';
import { ConfigurationServiceComponent } from './configuration-service/configuration-service.component';
import { ConfigurationRatingComponent } from './configuration-rating/configuration-rating.component';
import { ConfigurationPositionComponent } from './configuration-position/configuration-position.component';
import { ConfigurationIndustryComponent } from './configuration-industry/configuration-industry.component';
import { ConfigurationDivisionsComponent } from './configuration-divisions/configuration-divisions.component';
import { ConfigurationStatesComponent } from './configuration-states/configuration-states.component';
import { ConfigurationComponent } from './configuration.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { ModalModule } from 'ngx-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    FileUploadModule,
    TextMaskModule,
    MultiselectDropdownModule,
    ModalModule.forRoot()
  ],
  declarations: [
    ConfigurationComponent,
    ConfigurationCountryComponent,
    ConfigurationStatesComponent,
    ConfigurationDivisionsComponent,
    ConfigurationIndustryComponent,
    ConfigurationPositionComponent,
    ConfigurationRatingComponent,
    ConfigurationServiceComponent,
    ConfigurationModalIndustryComponent,
    ConfigurationModalPositionComponent,
    ConfigurationModalRatingComponent,
    ConfigurationModalDivisionComponent,
    ConfigurationModalServiceComponent,
    ErrorMessageComponent
  ],
  providers: [
    ConfigurationService
  ]
})
export class ConfigurationModule { }
