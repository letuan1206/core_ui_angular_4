import { ConfigurationModalServiceComponent } from './../modals/configuration-modal-service/configuration-modal-service.component';
import { CONFIGURATION_ADD_SERVICE, CONFIGURATION_NEW_SERVICE, CONFIGURATION_CURRENT_SERVICE } from './../actions';
import { ApiService } from './../../../services/api.service';
import { select, NgRedux } from 'ng2-redux';
import { Service, Client } from './../../../models/configuration';
import { ConfigurationService } from './../configuration.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';

@Component({
  selector: 'app-configuration-service',
  templateUrl: './configuration-service.component.html',
  styleUrls: ['./configuration-service.component.scss']
})
export class ConfigurationServiceComponent implements OnInit {
  @ViewChild('childModal') childModal: ConfigurationModalServiceComponent;
  configurationServiceList: Service[] = [];
  configurationServiceView: Service[] = [];

  enableBtnEdit: boolean;
  btnEditService = false;
  service: Service;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.service) rdService;
  @select(s => s.configuration.serviceView) rdServiceView;
  @select(s => s.configuration.clientList) clientList;
  @select(s => s.configuration.siteList) siteList;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) { 
      this.responseStatus = this.configService.get('status');
    }

  ngOnInit() {
    this.getStoreData();
  }

  changeStatusButton() {
    this.btnEditService = !this.btnEditService;
  }

  cancelSaveService() {
    this.errorMessages = null;
    this.resetStoreServiceNew();

    this.configurationService.setStoreService();
    this.changeStatusButton();
  }

  resetStoreServiceNew() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_ADD_SERVICE,
      payload: []
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_NEW_SERVICE,
      payload: []
    });
  }

  openModalAddService(type, index, data) {
    if (!this.btnEditService) {
      return;
    }
    this.helperSerivce.showLoading();
    return new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getClientByQueryParams({ NoService: true })
      ]).then(
        ([clients]) => {
          if (type === 'addNew') {
            this.service = new Service();
            this.service.Active = true;
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_SERVICE,
              payload: this.service
            });

          } else if (type === 'editNew') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_SERVICE,
              payload: data
            });

          } else if (type === 'edit') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_SERVICE,
              payload: data
            });
          }
          this.helperSerivce.hideLoading();
          this.childModal.show();
          resolve();
        }, () => {
          this.helperSerivce.hideLoading();
          reject
        }
        );
    });
  }

  saveService() {
    var serviceAddList = Object.assign({}, this.configurationServiceView);
    var serviceUPdate = _.fromPairs(_.map(this.configurationServiceList, i => [i.ObjectID, i]));

    var params = {
      create: serviceAddList,
      update: serviceUPdate,
      delete: {},
    }
    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if(res.status === this.responseStatus.error) {
        this.errorMessages =  res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;
      
      this.configurationService.setStoreService();
      this.changeStatusButton();
      this.resetStoreServiceNew();
      this.helperSerivce.hideLoading();
    });
  }

  getStoreData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.rdService.subscribe(data => {
      if (data) {
        this.configurationServiceList = _.clone(data);
      }
    });

    this.rdServiceView.subscribe(data => {
      if (data) {
        this.configurationServiceView = data;
      }
    });
  }

}
