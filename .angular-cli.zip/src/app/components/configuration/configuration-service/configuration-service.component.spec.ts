import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationServiceComponent } from './configuration-service.component';

describe('ConfigurationServiceComponent', () => {
  let component: ConfigurationServiceComponent;
  let fixture: ComponentFixture<ConfigurationServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
