import { ApiService } from './../../../services/api.service';
import { HelperService } from './../../../services/helper.service';
import { CONFIGURATION_SAVE_STATES, CONFIGURATION_ACTION, CONFIGURATION_SAVE_STATES_ORIGIN, CONFIGURATION_SAVE_CLIENT, CONFIGURATION_SAVE_COUNTRY } from './../actions';
import { Country, Division, CountryState } from './../../../models/configuration';
import { ConfigurationService } from './../configuration.service';
import { ConfigService } from './../../../services/config.service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import * as _ from 'lodash';
import { LOCALSTORE_KEY } from '../../common/constants';

@Component({
  selector: 'app-configuration-country',
  templateUrl: './configuration-country.component.html',
  styleUrls: ['./configuration-country.component.scss']
})
export class ConfigurationCountryComponent implements OnInit {
  countryList: Country[] = [];
  btnEditCountry = false;
  countryId = '';

  countryName: string;
  enableBtnEdit;
  countryStateList: CountryState[] = [];
  divisionList: CountryState[] = [];
  countryStateData: any;
  public loading = false;

  @select(s => s.configuration.countryName) rdCountryName;

  constructor(
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>
  ) {

  }

  ngOnInit() {
    setTimeout(() => this.loadAllCountry());
    this.loadStore();
    ///this.getCountryIdSession();
  }

  loadAllCountry() {
    this.helperSerivce.showLoading();
    this.configurationService.getAllCountry().subscribe(res => {
      if (res.results) {
        res.results.forEach(element => {
          let country = _.clone(_.get(res.references, element));
          if (country.Selected) {
            this.countryId = country.ObjectID;
          }
          this.countryList.push(_.clone(_.get(res.references, element)));

        });

        if (this.countryId) {
          this.saveSelectCountry();
        } else {
          this.helperSerivce.hideLoading();
        }

      } else {
        this.helperSerivce.hideLoading();
      }
    });


  }

  changeStatusEditCountry() {
    this.btnEditCountry = !this.btnEditCountry;
  }

  selectCountry(countryId) {
    this.countryId = countryId;
  }

  cancelSaveCountry() {
    this.rdCountryName.subscribe(data => {
      this.countryId = data[0].ObjectID;
    });
    this.changeStatusEditCountry();
  }

  saveSelectCountry() {
    this.helperSerivce.showLoading();

    let countryName = this.countryList.filter(element => this.countryId === element.ObjectID);

    this.countryList.forEach(element => {
      if (element.ObjectID !== this.countryId) {
        element.Selected = false;
      } else {
        element.Selected = true;
      }
    });

    const countrUpdate = _.fromPairs(_.map(this.countryList, i => [i.ObjectID, i]));

    const params = {
      create: {},
      update: countrUpdate,
      delete: {},
    };

    this.apiService.saveService(params).subscribe(res => {

    });

    this.configurationService.getAllStateByCountry(countryName[0].Name).subscribe(res => {

      this.countryStateList = [];

      res.results.forEach(element => {
        this.countryStateList.push(_.get(res.references, element));
      });

      this.configurationService.getAllDivisionByState().subscribe(result => {
        _.map(this.countryStateList, state => {

          var data: Division[];

          data = _.filter(result.references, obj => {
            return obj.State === state.ObjectID;
          });

          state.Collapse = false;
          state.Divisions = _.orderBy(data, [function (division) {
            return division.Description.toLowerCase();
          }], ['asc']);;

        });

        this.ngRedux.dispatch({
          type: CONFIGURATION_SAVE_STATES,
          payload: {
            countryStateList: _.cloneDeep(this.countryStateList)
          }
        });

        this.ngRedux.dispatch({
          type: CONFIGURATION_SAVE_STATES_ORIGIN,
          payload: _.cloneDeep(this.countryStateList)
        });

        this.ngRedux.dispatch({
          type: CONFIGURATION_SAVE_COUNTRY,
          payload: countryName
        });

        localStorage.setItem(LOCALSTORE_KEY.COUNTRY_ID, this.countryId);
        this.changeStatusButtonEdit(true);
        this.changeStatusEditCountry();
        if (this.btnEditCountry) {
          this.changeStatusEditCountry();
        }
        this.helperSerivce.hideLoading();
      });
    })
  }

  getCountryIdSession() {
    var countryId = localStorage.getItem(LOCALSTORE_KEY.COUNTRY_ID);
    if (countryId) {
      this.countryId = countryId;
      this.saveSelectCountry();
    }
  }

  changeStatusButtonEdit(type: boolean) {
    this.ngRedux.dispatch({
      type: CONFIGURATION_ACTION,
      payload: type
    });
  }

  loadStore() {
    this.rdCountryName.subscribe(data => {
      if (data) {
        this.countryId = data[0].ObjectID;
      }
    });
  }
}
