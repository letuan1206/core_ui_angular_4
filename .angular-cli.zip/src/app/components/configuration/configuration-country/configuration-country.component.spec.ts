import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationCountryComponent } from './configuration-country.component';

describe('ConfigurationCountryComponent', () => {
  let component: ConfigurationCountryComponent;
  let fixture: ComponentFixture<ConfigurationCountryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationCountryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationCountryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
