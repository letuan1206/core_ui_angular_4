import { ConfigService } from './../../../services/config.service';
import { ConfigurationService } from './../configuration.service';
import { ApiService } from './../../../services/api.service';
import { ConfigurationModalDivisionComponent } from './../modals/configuration-modal-division/configuration-modal-division.component';
import { CONFIGURATION_ACTION, CONFIGURATION_SAVE_STATES, CONFIGURATION_CURRENT_DIVISION, CONFIGURATION_NEW_DIVISION, CONFIGURATION_SAVE_STATES_ORIGIN } from './../actions';
import { CountryState, Division, Country } from './../../../models/configuration';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'app-configuration-divisions',
  templateUrl: './configuration-divisions.component.html',
  styleUrls: ['./configuration-divisions.component.scss']
})
export class ConfigurationDivisionsComponent implements OnInit {
  @ViewChild('childModal') childModal: ConfigurationModalDivisionComponent;

  enableBtnEdit: boolean;
  countryStates: CountryState[] = [];
  countryStatesOrigin: CountryState[] = [];
  btnEditDivision = false;
  editbox = false;
  countryStateData: any;
  divisionAddNew = [];
  division: Division;
  countryName: any;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.countryStateList) rdcountryStateList;
  @select(s => s.configuration.countryStateOriginal) rdcountryStateOriginal;
  @select(s => s.configuration.countryStateData) rdCountryStateData;
  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.divisionNew) rdDivisionNew;
  @select(s => s.configuration.countryName) rdCountryName;

  @select(s => s.configuration.countryStateOriginal) rdCountryStateOriginal;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private apiService: ApiService,
    private configurationService: ConfigurationService,
    private ngRedux: NgRedux<any>
  ) {
    this.responseStatus = this.configService.get('status');
  }

  ngOnInit() {
    this.division = new Division();
    this.loadData();
  }

  openModalAddDivision(type, stateId, division, index) {
    if (!this.btnEditDivision) {
      return;
    }

    this.helperSerivce.showLoading();
    return new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getProsekEmployeeByParams({ NoDivision: true })
      ]).then(
        ([clients]) => {
          this.division = new Division();
          this.division.Active = true;

          if (type === 'addNew') {
            const aIndex = _.findIndex(this.countryStates, obj => {
              return obj.Active === true;
            });

            if (aIndex !== -1) {
              this.division.State = this.countryStates[aIndex].ObjectID;
            }

            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_DIVISION,
              payload: this.division
            });

          } else if (type === 'editDivision') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_DIVISION,
              payload: division
            });

          } else if (type === 'editDivisionState') {
            this.division.State = stateId;

            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_DIVISION,
              payload: this.division
            });
          }

          this.helperSerivce.hideLoading();
          this.childModal.show();
          resolve();
        }, () => {
          this.helperSerivce.hideLoading();
          reject;
        }
        );
    });
  }

  saveDivision() {
    const divisionAdd = Object.assign({}, this.divisionAddNew);

    let divisionArr = [];
    _.map(this.countryStates, state => {
      divisionArr = _.concat(divisionArr, state.Divisions);
    });

    _.remove(divisionArr, division => {
      return division.ObjectID === undefined;
    });

    const divisionUpdate = _.fromPairs(_.map(divisionArr, i => [i.ObjectID, i]));

    const params = {
      create: divisionAdd,
      update: divisionUpdate,
      delete: {},
    };

    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;

      this.configurationService.getAllStateByCountry(this.countryName[0].Name).subscribe(res => {
        this.countryStates = [];

        res.results.forEach(element => {
          this.countryStates.push(_.get(res.references, element));
        });

        this.configurationService.getAllDivisionByState().subscribe(result => {
          _.map(this.countryStates, state => {

            let data: Division[];

            data = _.filter(result.references, obj => {
              return obj.State === state.ObjectID;
            });

            state.Collapse = false;
            state.Divisions = _.orderBy(data, [function (division) {
              return division.Description.toLowerCase();
            }], ['asc']);;

          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_STATES,
            payload: {
              countryStateList: _.cloneDeep(this.countryStates)
            }
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_STATES_ORIGIN,
            payload: _.cloneDeep(this.countryStates)
          });

          this.resetStoreDivisionNew();

          this.changeStatusButton();
          this.helperSerivce.hideLoading();
        });
      });
    });
  }

  resetStoreDivisionNew() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_NEW_DIVISION,
      payload: []
    });
  }

  collapseAll(data) {
    if (data) {
      _.map(this.countryStates, state => {
        state.Collapse = true;
      });
    } else {
      _.map(this.countryStates, state => {
        state.Collapse = false;
      });
    }
  }

  loadData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.rdcountryStateList.subscribe(data => {
      this.countryStates = _.cloneDeep(data);
    });

    this.rdcountryStateOriginal.subscribe(data => {
      this.countryStatesOrigin = data;
    });

    this.rdCountryStateData.subscribe(data => {
      this.countryStateData = _.cloneDeep(data);
    });

    this.rdDivisionNew.subscribe(data => {
      if (data) {
        this.divisionAddNew = data;
      }
    });

    this.rdCountryName.subscribe(data => {
      if (data) {
        this.countryName = data;
      }
    });
  }

  changeStatusButton() {
    this.btnEditDivision = !this.btnEditDivision;
    this.editbox = !this.editbox;
  }

  cancelSaveDivision() {
    this.errorMessages = null;
    this.rdCountryStateOriginal.subscribe(data => {
      this.countryStates = _.cloneDeep(data);
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_SAVE_STATES,
      payload: {
        countryStateList: _.cloneDeep(this.countryStates)
      }
    });

    this.resetStoreDivisionNew();
    this.changeStatusButton();
  }
}
