import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationDivisionsComponent } from './configuration-divisions.component';

describe('ConfigurationDivisionsComponent', () => {
  let component: ConfigurationDivisionsComponent;
  let fixture: ComponentFixture<ConfigurationDivisionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationDivisionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationDivisionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
