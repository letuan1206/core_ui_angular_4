import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationStatesComponent } from './configuration-states.component';

describe('ConfigurationStatesComponent', () => {
  let component: ConfigurationStatesComponent;
  let fixture: ComponentFixture<ConfigurationStatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationStatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationStatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
