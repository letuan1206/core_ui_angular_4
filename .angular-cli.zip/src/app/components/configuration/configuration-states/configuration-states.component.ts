import { ConfigService } from './../../../services/config.service';
import { CONFIGURATION_SAVE_STATES, CONFIGURATION_SAVE_STATES_ORIGIN } from './../actions';
import { select, NgRedux } from 'ng2-redux';
import { ApiService } from './../../../services/api.service';
import { ConfigurationService } from './../configuration.service';
import { CountryState } from './../../../models/configuration';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';

@Component({
  selector: 'app-configuration-states',
  templateUrl: './configuration-states.component.html',
  styleUrls: ['./configuration-states.component.scss']
})
export class ConfigurationStatesComponent implements OnInit {
  enableBtnEdit: boolean;
  countryStates: CountryState[] = [];
  countryStatesOrigin: CountryState[] = [];
  countryStateData: any;

  btnEditState = false;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.countryStateList) countryStateList;
  @select(s => s.configuration.countryStateData) rdCountryStateData;
  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.countryStateOriginal) rdCountryStateOriginal;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) {
    this.responseStatus = this.configService.get('status');
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.countryStateList.subscribe(data => {
      this.countryStates = _.cloneDeep(data);
    });

    this.rdCountryStateOriginal.subscribe(data => {
      this.countryStatesOrigin = _.cloneDeep(data);
    });

  }

  changeStatusButton() {
    this.btnEditState = !this.btnEditState;
  }

  cancelSaveCountryState() {
    this.errorMessages = null;
    this.rdCountryStateOriginal.subscribe(data => {
      this.countryStates = _.cloneDeep(data);
    });

    this.changeStatusButton();
  }

  changeCountryState(index) {
    this.countryStates[index].Active = !this.countryStates[index].Active;
  }

  saveCountryState() {
    const stateArr = _.cloneDeep(this.countryStates);
    _.map(stateArr, state => {
      delete state.Divisions;
    });
    const stateUpdate = Object.assign({}, stateArr);

    const params = {
      create: {},
      update: stateUpdate,
      delete: {}
    };

    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_STATES,
        payload: {
          countryStateList: _.cloneDeep(this.countryStates)
        }
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_STATES_ORIGIN,
        payload: _.cloneDeep(this.countryStates)
      });

      this.changeStatusButton();
      this.helperSerivce.hideLoading();
    });
  }
}
