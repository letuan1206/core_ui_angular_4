import { ConfigService } from './../../../services/config.service';
import { ConfigurationModalIndustryComponent } from './../modals/configuration-modal-industry/configuration-modal-industry.component';
import { CONFIGURATION_ADD_INDUSTRY, CONFIGURATION_NEW_INDUSTRY, CONFIGURATION_CURRENT_INDUSTRY } from './../actions';
import { ApiService } from './../../../services/api.service';
import { ConfigurationService } from './../configuration.service';
import { select, NgRedux } from 'ng2-redux';
import { Industry } from './../../../models/configuration';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';

@Component({
  selector: 'app-configuration-industry',
  templateUrl: './configuration-industry.component.html',
  styleUrls: ['./configuration-industry.component.scss']
})
export class ConfigurationIndustryComponent implements OnInit {
  @ViewChild('childModal') childModal: ConfigurationModalIndustryComponent;
  configurationIndustries: Industry[] = [];
  configurationIndustriesView: Industry[] = [];

  enableBtnEdit: boolean;
  btnEditIndustry = false;
  industry: Industry;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.industries) rdIndustries;
  @select(s => s.configuration.industriesView) rdIndustriesView;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) { 
      this.responseStatus = this.configService.get('status');
    }

  ngOnInit() {
    this.getStoreData();
  }

  changeStatusButton() {
    this.btnEditIndustry = !this.btnEditIndustry;
  }

  cancelSaveIndustry() {
    this.errorMessages = null;
    this.resetStoreIndustryNew();

    this.configurationService.setStoreIndustry();
    this.changeStatusButton();
  }

  resetStoreIndustryNew() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_ADD_INDUSTRY,
      payload: []
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_NEW_INDUSTRY,
      payload: []
    });

  }

  openModalAddIndustry(type, index, data) {
    if (!this.btnEditIndustry) {
      return;
    }

    this.helperSerivce.showLoading();
    return new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getClientByQueryParams({ NoIndustry: true })
      ]).then(
        ([clients]) => {
          if (type === 'addNew') {
            this.industry = new Industry();
            this.industry.Active = true;
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_INDUSTRY,
              payload: this.industry
            });

          } else if (type === 'editNew') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_INDUSTRY,
              payload: data
            });

          } else if (type === 'edit') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_INDUSTRY,
              payload: data
            });
          }

          this.helperSerivce.hideLoading();
          this.childModal.show();
          resolve();
        }, () => {
          this.helperSerivce.hideLoading();
          reject;
        }
        );
    });
  }

  saveIndustry() {
    var industryAdd = Object.assign({}, this.configurationIndustriesView);
    var industryUpdate = _.fromPairs(_.map(this.configurationIndustries, i => [i.ObjectID, i]));

    var params = {
      create: industryAdd,
      update: industryUpdate,
      delete: {},
    }

    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if(res.status === this.responseStatus.error) {
        this.errorMessages =  res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;

      this.configurationService.setStoreIndustry();
      this.changeStatusButton();
      this.resetStoreIndustryNew();
      this.helperSerivce.hideLoading();
    });
  }

  getStoreData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.rdIndustries.subscribe(data => {
      if (data) {
        this.configurationIndustries = _.clone(data);
      }
    });

    this.rdIndustriesView.subscribe(data => {
      if (data) {
        this.configurationIndustriesView = data;
      }
    });
  }
}
