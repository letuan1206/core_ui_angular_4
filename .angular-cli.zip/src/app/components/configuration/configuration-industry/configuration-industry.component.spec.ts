import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationIndustryComponent } from './configuration-industry.component';

describe('ConfigurationIndustryComponent', () => {
  let component: ConfigurationIndustryComponent;
  let fixture: ComponentFixture<ConfigurationIndustryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationIndustryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationIndustryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
