import { HelperService } from './../../services/helper.service';
import {
  CONFIGURATION_SAVE_STATES,
  CONFIGURATION_ACTION,
  CONFIGURATION_SAVE_CLIENT,
  CONFIGURATION_SAVE_SITE,
  CONFIGURATION_SAVE_RATING
} from './actions';
import { CountryState, Division } from './../../models/configuration';
import { ConfigurationService } from './configuration.service';
import { Component, OnInit, Output, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgRedux, select } from 'ng2-redux';
import * as _ from 'lodash';
import { AppComponent } from '../../app.component';

declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-configuration',
  templateUrl: './configuration.component.html',
  styleUrls: ['./configuration.component.scss']
})
export class ConfigurationComponent implements OnInit, OnDestroy, AfterViewInit {
  private idAnchor: any;

  constructor(
    private helperService: HelperService,
    private configurationService: ConfigurationService,
    private ngRedux: NgRedux<any>,
    private router: Router,
    private _activatedRoute: ActivatedRoute) {

  }

  ngOnDestroy() {
    //this.configurationService.clearStoreConfiguration();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  ngOnInit() {
    $('body').removeClass('sidebar-minimized brand-minimized');
    setTimeout(() => {
      this.helperService.showLoading();
      new Promise((resolve, reject) => {
        Promise.all([
          this.configurationService.setStoreRating(),
          this.configurationService.setStoreService(),
          this.configurationService.setStoreIndustry(),
          this.configurationService.setStorePosition(),
        ]).then(
          () => {
            this.helperService.hideLoading();
            this._activatedRoute.params.subscribe(params => {
              this.idAnchor = params.idAnchor;

            });

            var anchoTemp = this.idAnchor;
            var scollToPos = $('#' + anchoTemp).offset().top;
            if (scollToPos != null) {
              setTimeout(() => {
                $('html, body').stop().animate({
                  'scrollTop': scollToPos - 121
                });
              }, 1500);
            }
            resolve();
          }, () => {
            reject();
          });
      });
    });

    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-2 ul li').each(function () {
        if ($('#section-6').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr('href-anchor'));
          if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-2 ul li a').removeClass('active-menu');
            currLink.addClass('active-menu');
          } else {
            currLink.removeClass('active-menu');
          }
        }
      });
    }

    if ($('#section-6').length) {
      $(document).on('scroll', onScroll);
    }


    $('.ancho-2 ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-2 ul li a').removeClass('active-menu');
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });

    // this.router.params.subscribe(param => {
    //  this.idAnchor = param['idConfiguration'];
    // });


  }

}
