import { element } from 'protractor';
import {
  CONFIGURATION_SAVE_CLIENT,
  CONFIGURATION_SAVE_SITE,
  CONFIGURATION_SAVE_RATING,
  CONFIGURATION_SAVE_SERVICE,
  CONFIGURATION_SAVE_INDUSTRY,
  CONFIGURATION_SAVE_POSITION,
  CONFIGURATION_SAVE_EMPLOYEES,
  CONFIGURATION_SAVE_STATES,
  CONFIGURATION_SAVE_STATES_ORIGIN,
  CONFIGURATION_SAVE_COUNTRY,
  CONFIGURATION_ACTION,
  CONFIGURATION_SAVE_CONTACT
} from './actions';
import { NgRedux } from 'ng2-redux';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Service, Division, Position, Industry, Rating } from './../../models/configuration';
import { Observable } from 'rxjs/Observable';
import { HelperService } from './../../services/helper.service';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';
import * as _ from 'lodash';
import { log } from 'util';

@Injectable()
export class ConfigurationService {

  constructor(
    private http: Http,
    private fb: FormBuilder,
    public configService: ConfigService,
    private api: ApiService,
    private helperService: HelperService,
    private ngRedux: NgRedux<any>
  ) {

  }

  clearStoreConfiguration() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_SAVE_STATES,
      payload: {
        countryStateList: null
      }
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_SAVE_STATES_ORIGIN,
      payload: null
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_SAVE_COUNTRY,
      payload: null
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_ACTION,
      payload: false
    });
  }

  setStoreClient() {
    this.getAllClient().subscribe(res => {
      let clients = [];
      res.results.forEach(element => {
        clients.push(_.get(res.references, element));
      });

      clients.forEach((element, index) => {
        element.id = index;
        element.name = element.TradingName;
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_CLIENT,
        payload: clients
      });
    });
  }

  setStoreSite() {
    this.getAllSite().subscribe(res => {
      let sites = [];
      res.results.forEach(element => {
        sites.push(_.get(res.references, element));
      });

      sites.forEach((element, index) => {
        element.id = index;
        element.name = element.SiteName;
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_SITE,
        payload: sites
      });
    });
  }

  setStoreRating() {
    this.getAllRating().subscribe(res => {
      var rates = [];
      res.results.forEach(element => {
        rates.push(_.get(res.references, element));
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_RATING,
        payload: rates
      });
    });
  }

  setStoreService() {
    this.getAllService().subscribe(res => {
      var services = [];
      res.results.forEach(element => {
        services.push(_.get(res.references, element));
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_SERVICE,
        payload: services
      });
    });
  }

  setStoreIndustry() {
    this.getAllIndustry().subscribe(res => {
      var industries = [];
      res.results.forEach(element => {
        industries.push(_.get(res.references, element));
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_INDUSTRY,
        payload: industries
      });
    });
  }

  setStorePosition() {
    this.getAllPosition().subscribe(res => {
      var positions = [];
      res.results.forEach(element => {
        positions.push(_.get(res.references, element));
      });

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_POSITION,
        payload: positions
      });
    });
  }

  // setStoreProsekEmployee() {
  //   this.getAllProsekEmployee().subscribe(res => {
  //     this.ngRedux.dispatch({
  //       type: CONFIGURATION_SAVE_EMPLOYEES,
  //       payload: res
  //     });
  //   });
  // }

  renderFormAddDivision(division: Division) {
    return this.fb.group({
      State: [division.State],
      Active: [division.Active],
      Description: [division.Description, [Validators.required]],
    });
  }

  renderFormAddRating(rating: Rating) {
    return this.fb.group({
      RatingName: [rating.Description, [Validators.required]]
    });
  }

  renderFormAddService(service: Service) {
    return this.fb.group({
      ServiceName: [service.Description, [Validators.required]],
      Active: [service.Active]
    });
  }

  renderFormAddIndustry(industry: Industry) {
    return this.fb.group({
      IndustryName: [industry.Description, [Validators.required]],
      Active: [industry.Active],
    });
  }

  renderFormAddPosition(position: Position) {
    return this.fb.group({
      PositionName: [position.Description, [Validators.required]],
      Active: [position.Active],
    });
  }

  getAllCountry(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Country`, params)
      .map(res => res);
  }

  getAllState(): Observable<any> {
    const params = {
      queryType: 'BY_COUNTRY',
      queryParams: {},
      assocs: []
    };

    return this.api.post(`/CountryState`, params)
      .map(res => res);
  }

  getAllStateByCountry(countryName): Observable<any> {
    const params = {
      queryType: 'BY_COUNTRY',
      queryParams: { 'Country': countryName },
      assocs: []
    };

    return this.api.post(`/CountryState`, params)
      .map(res => res);
  }

  getAllDivisionByState(): Observable<any> {
    const params = {
      queryType: 'BY_DETAILS',
      queryParams: {},
      assocs: ['State']
    };

    return this.api.post(`/Division`, params)
      .map(res => res);
  }

  getAllPosition(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Positions`, params)
      .map(res => res);
  }

  getAllService(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Services`, params)
      .map(res => res);
  }

  getAllRating(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Ratings`, params)
      .map(res => res);
  }

  getAllIndustry(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Industries`, params)
      .map(res => res);
  }

  getProsekEmployeeByParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: [],
        queryParams: data
      };

      this.api.post(`/ProsekEmployees`, params)
        .subscribe(res => {

          const employees = _.toArray(res.references);

          employees.forEach((element, index) => {
            element.id = index;
            element.name = element.UserName;
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_EMPLOYEES,
            payload: employees
          });
          resolve();
        }, reject);
    });
  }

  getAllProsekEmployee(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: ['User', 'Rating'],
      queryParams: {}
    };

    return this.api.post(`/ProsekEmployees`, params)
      .map(res => res);
  }

  getAllProsekEmployee3(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: [],
        queryParams: {}
      };

      this.api.post(`/ProsekEmployees`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getAllClient(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: []
    };

    return this.api.post(`/Clients`, params)
      .map(res => res);
  }

  getAllClientByParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: [],
        queryParams: data
      };

      this.api.post(`/Clients`, params)
        .subscribe(res => {
          let clients = [];
          res.results.forEach(element => {
            clients.push(_.get(res.references, element));
          });

          resolve(clients);
        }, reject);
    });
  }

  getAllContactByParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: [],
        queryParams: data
      };

      this.api.post(`/Contact`, params)
        .subscribe(res => {
          let contacts = [];
          res.results.forEach(element => {
            contacts.push(_.get(res.references, element));
          });

          resolve(contacts);
        }, err => {
          reject(err);
        }, () => {

        });
    });
  }

  getAllSiteByParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: ['Contacts'],
        queryParams: data
      };

      this.api.post(`/Sites`, params)
        .subscribe(res => {
          let sites = [];
          res.results.forEach(element => {
            sites.push(_.get(res.references, element));
          });

          resolve(sites);
        }, reject);
    });
  }

  getContactByQueryParams(queryParams): Observable<any> | Promise<any> | any {
    return new Promise((resolve, reject) => {
      Promise.all([
        this.getAllContactByParams(queryParams),
      ]).then(
        ([contacts]) => {
          contacts.forEach((element, index) => {
            element.id = index;
            element.name = element.FirstName + ' ' + element.LastName;
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_CONTACT,
            payload: contacts
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_SITE,
            payload: contacts
          });

          resolve();
        },
        reject
      );
    });
  }

  getClientByQueryParams(queryParams): Observable<any> | Promise<any> | any {
    return new Promise((resolve, reject) => {
      Promise.all([
        this.getAllClientByParams(queryParams),
        this.getAllSiteByParams(queryParams)
      ]).then(
        ([clients, sites]) => {
          clients.forEach((element, index) => {
            element.id = index;
            element.name = element.TradingName;
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_CLIENT,
            payload: clients
          });

          sites.forEach((element, index) => {
            element.id = index;
            element.name = element.SiteName;
          });

          this.ngRedux.dispatch({
            type: CONFIGURATION_SAVE_SITE,
            payload: sites
          });

          resolve();
        },
        reject
      );
    });
  }

  getAllSite(): Observable<any> {
    const params = {
      queryType: 'All',
      assocs: ['Information']
    };

    return this.api.post(`/Sites`, params)
      .map(res => res);
  }

  getAllSiteByQueryParams(queryParams): Observable<any> {
    const params = {
      queryType: 'All',
      queryParams: queryParams,
      assocs: ['Contacts']
    };

    return this.api.post(`/Sites`, params)
      .map(res => res);
  }
}
