import { ConfigService } from './../../../services/config.service';
import { ConfigurationModalPositionComponent } from './../modals/configuration-modal-position/configuration-modal-position.component';
import { CONFIGURATION_ADD_POSITION, CONFIGURATION_CURRENT_POSITION, CONFIGURATION_NEW_POSITION } from './../actions';
import { ApiService } from './../../../services/api.service';
import { ConfigurationService } from './../configuration.service';
import { select, NgRedux } from 'ng2-redux';
import { Position } from './../../../models/configuration';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';

@Component({
  selector: 'app-configuration-position',
  templateUrl: './configuration-position.component.html',
  styleUrls: ['./configuration-position.component.scss']
})
export class ConfigurationPositionComponent implements OnInit {
  @ViewChild('childModal') childModal: ConfigurationModalPositionComponent;
  configurationPositions: Position[] = [];
  configurationPositionsView: Position[] = [];

  enableBtnEdit: boolean;
  btnEditPosition = false;
  position: Position;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.positions) rdPositions;
  @select(s => s.configuration.positionsView) rdPositionsView;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) { 
      this.responseStatus = this.configService.get('status');
    }

  ngOnInit() {
    this.getStoreData();
  }

  changeStatusButton() {
    this.btnEditPosition = !this.btnEditPosition;
  }

  cancelSavePosition() {
    this.errorMessages = null;
    this.resetStorePositionNew();

    this.configurationService.setStorePosition();
    this.changeStatusButton();
  }

  resetStorePositionNew() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_ADD_POSITION,
      payload: []
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_NEW_POSITION,
      payload: []
    });
  }

  openModalAddPosition(type, index, data) {
    if (!this.btnEditPosition) {
      return;
    }

    this.helperSerivce.showLoading();
    return new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getContactByQueryParams({ NoPosition: true })
      ]).then(
        ([clients]) => {
          if (type === 'addNew') {
            this.position = new Position();
            this.position.Active = true;
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_POSITION,
              payload: this.position
            });

          } else if (type === 'editNew') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_POSITION,
              payload: data
            });

          } else if (type === 'edit') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_POSITION,
              payload: data
            });
          }

          this.helperSerivce.hideLoading();
          this.childModal.show();
          resolve();
        }, () => {
          this.helperSerivce.hideLoading();
          reject;
        }
        );
    });
  }

  savePosition() {
    var positionAdd = Object.assign({}, this.configurationPositionsView);
    var positionUpdate = _.fromPairs(_.map(this.configurationPositions, i => [i.ObjectID, i]));

    var params = {
      create: positionAdd,
      update: positionUpdate,
      delete: {},
    };

    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if(res.status === this.responseStatus.error) {
        this.errorMessages =  res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;

      this.configurationService.setStorePosition();
      this.changeStatusButton();
      this.resetStorePositionNew();
      this.helperSerivce.hideLoading();
    });
  }

  getStoreData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.rdPositions.subscribe(data => {
      if (data) {
        this.configurationPositions = _.clone(data);
      }
    });

    this.rdPositionsView.subscribe(data => {
      if (data) {
        this.configurationPositionsView = data;
      }
    });
  }
}
