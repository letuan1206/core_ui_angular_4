import { HelperService } from './../../../../services/helper.service';
import { ModalDirective } from 'ng2-bootstrap';
import { Industry } from './../../../../models/configuration';
import { CONFIGURATION_ADD_INDUSTRY, CONFIGURATION_SAVE_INDUSTRY } from './../../actions';
import { ApiService } from './../../../../services/api.service';
import { ConfigurationService } from './../../configuration.service';
import { IMultiSelectOption, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import { select, NgRedux } from 'ng2-redux';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as _ from 'lodash';
@Component({
  selector: 'app-configuration-modal-industry',
  templateUrl: './configuration-modal-industry.component.html',
  styleUrls: ['./configuration-modal-industry.component.scss']
})
export class ConfigurationModalIndustryComponent implements OnInit {
  @ViewChild('childModal') public childModal: ModalDirective;
  @ViewChild('closeBtn') closeBtn: ElementRef;

  @select(s => s.configuration.clientList) clientList;
  @select(s => s.configuration.siteList) siteList;
  @select(s => s.configuration.industriesCurrent) rdIndustriesCurrent;
  @select(s => s.configuration.industriesNew) rdIndustriesNew;
  @select(s => s.configuration.industries) rdIndustries;
  @select(s => s.configuration.industriesView) rdIndustriesView;

  formAddIndustry: FormGroup;

  clients: any;
  sites: any;
  industryCurrent: Industry;
  industryNew = [];
  clientChoose: number[];
  siteChoose: number[];
  configurationIndustries: Industry[] = [];
  configurationIndustriesView: Industry[] = [];
  showErrorAddIndustry = false;

  clientOptions: IMultiSelectOption[];
  siteOptions: IMultiSelectOption[];
  mySettings: IMultiSelectSettings = {
    dynamicTitleMaxItems: 1
  };

  constructor(private configurationService: ConfigurationService,
    private helperService: HelperService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) {

  }

  private closeModal(): void {
    this.closeBtn.nativeElement.click();
  }

  ngOnInit() {
    this.industryCurrent = new Industry();
    this.customFormAddIndustry();
    this.getStoreData();
  }

  addIndustry() {
    if (!this.formAddIndustry.valid) {
      this.showErrorAddIndustry = true;
      this.helperService.markFormGroupTouched(this.formAddIndustry);
      return;
    }

    var clientData = [];
    var siteData = [];

    _.map(this.clientChoose, item => {
      clientData.push(this.clientOptions[item]['ObjectID']);
    });

    _.map(this.siteChoose, item => {
      siteData.push(this.siteOptions[item]['ObjectID']);
    });

    if (this.industryCurrent.ObjectID) {
      var industry = _.find(this.configurationIndustries, obj => {
        return obj.ObjectID === this.industryCurrent.ObjectID;
      });

      industry.Active = this.formAddIndustry.value.Active || false;
      industry.Description = this.formAddIndustry.value.IndustryName;
      industry.AddClients = clientData;
      industry.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_INDUSTRY,
        payload: this.configurationIndustries
      });
    } else if (!this.industryCurrent.ObjectID && this.industryCurrent.Description) {
      var industry = _.find(this.configurationIndustriesView, obj => {
        return obj.ObjectID === this.industryCurrent.ObjectID;
      });

      industry.Active = this.formAddIndustry.value.Active || false;
      industry.Description = this.formAddIndustry.value.IndustryName;
      industry.AddClients = clientData;
      industry.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_INDUSTRY,
        payload: this.configurationIndustriesView
      });
    } else {
      this.industryCurrent.Active = this.formAddIndustry.value.Active || false;
      this.industryCurrent.Description = this.formAddIndustry.value.IndustryName;
      this.industryCurrent.AddClients = clientData;
      this.industryCurrent.AddSites = siteData;

      this.industryNew.push(_.cloneDeep(this.industryCurrent));

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_INDUSTRY,
        payload: this.industryNew
      });
    }
    this.resetFormAddIndustry();
  }

  resetFormAddIndustry() {
    this.showErrorAddIndustry = false;
    this.clientChoose = [];
    this.siteChoose = [];
    this.hide();
  }

  customFormAddIndustry() {
    this.showErrorAddIndustry = false;
    this.formAddIndustry = this.configurationService.renderFormAddIndustry(this.industryCurrent);
  }

  getStoreData() {
    this.clientList.subscribe(data => {
      if (data) {
        this.clientOptions = data;
      }
    });

    this.siteList.subscribe(data => {
      if (data) {
        this.siteOptions = data;
      }
    });

    this.rdIndustriesCurrent.subscribe(data => {
      if (data) {
        this.industryCurrent = data;
        this.customFormAddIndustry();
      }
    });

    this.rdIndustriesNew.subscribe(data => {
      if (data) {
        this.industryNew = data;
      }
    });

    this.rdIndustries.subscribe(data => {
      if (data) {
        this.configurationIndustries = _.clone(data);
      }
    });

    this.rdIndustriesView.subscribe(data => {
      if (data) {
        this.configurationIndustriesView = _.clone(data);
      }
    });
  }

  show() {
    this.childModal.show();
  }

  hide() {
    this.childModal.hide();
  }
}
