import { HelperService } from './../../../../services/helper.service';
import { Position } from './../../../../models/configuration';
import { CONFIGURATION_ADD_POSITION, CONFIGURATION_SAVE_POSITION } from './../../actions';
import { ApiService } from './../../../../services/api.service';
import { ConfigurationService } from './../../configuration.service';
import { IMultiSelectOption, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import { select, NgRedux } from 'ng2-redux';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';
import * as _ from 'lodash';

@Component({
  selector: 'app-configuration-modal-position',
  templateUrl: './configuration-modal-position.component.html',
  styleUrls: ['./configuration-modal-position.component.scss']
})
export class ConfigurationModalPositionComponent implements OnInit {
  @ViewChild('childModal') public childModal: ModalDirective;
  @ViewChild('closeBtn') closeBtn: ElementRef;

  @select(s => s.configuration.contactList) contactList;
  @select(s => s.configuration.siteList) siteList;
  @select(s => s.configuration.positionsCurrent) rdPositionsCurrent;
  @select(s => s.configuration.positionsNew) rdPositionsNew;
  @select(s => s.configuration.positions) rdPositions;
  @select(s => s.configuration.positionsView) rdPositionsView;

  formAddPosition: FormGroup;

  clients: any;
  sites: any;
  positionCurrent: Position;
  positionNew = [];
  clientChoose: number[];
  siteChoose: number[];
  configurationPositions: Position[] = [];
  configurationPositionsView: Position[] = [];
  showErrorAddPosition = false;

  clientOptions: IMultiSelectOption[];
  siteOptions: IMultiSelectOption[];
  mySettings: IMultiSelectSettings = {
    dynamicTitleMaxItems: 1
  };

  constructor(private configurationService: ConfigurationService,
    private helperService: HelperService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) {

  }

  private closeModal(): void {
    this.closeBtn.nativeElement.click();
  }

  ngOnInit() {
    this.positionCurrent = new Position();
    this.customFormAddPosition();
    this.getStoreData();
  }

  addPosition() {
    if (!this.formAddPosition.valid) {
      this.showErrorAddPosition = true;
      this.helperService.markFormGroupTouched(this.formAddPosition);
      return;
    }

    var clientData = [];
    var siteData = [];

    _.map(this.clientChoose, item => {
      clientData.push(this.clientOptions[item]['ObjectID']);
    });

    _.map(this.siteChoose, item => {
      clientData.push(this.siteOptions[item]['ObjectID']);
    });

    if (this.positionCurrent.ObjectID) {
      var position = _.find(this.configurationPositions, obj => {
        return obj.ObjectID === this.positionCurrent.ObjectID;
      });

      position.Active = this.formAddPosition.value.Active || false;
      position.Description = this.formAddPosition.value.PositionName;
      position.AddContacts = clientData;
      position.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_POSITION,
        payload: this.configurationPositions
      });
    } else if (!this.positionCurrent.ObjectID && this.positionCurrent.Description) {
      var position = _.find(this.configurationPositionsView, obj => {
        return obj.ObjectID === this.positionCurrent.ObjectID;
      });

      position.Active = this.formAddPosition.value.Active || false;
      position.Description = this.formAddPosition.value.PositionName;
      position.AddContacts = clientData;
      position.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_POSITION,
        payload: this.configurationPositionsView
      });
    } else {
      this.positionCurrent.Active = this.formAddPosition.value.Active || false;
      this.positionCurrent.Description = this.formAddPosition.value.PositionName;
      this.positionCurrent.AddContacts = clientData;
      this.positionCurrent.AddSites = siteData;

      this.positionNew.push(_.cloneDeep(this.positionCurrent));

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_POSITION,
        payload: this.positionNew
      });
    }

    this.resetFormAddPosition();
  }

  resetFormAddPosition() {
    this.showErrorAddPosition = false;
    this.clientChoose = [];
    this.siteChoose = [];
    this.hide();
  }

  customFormAddPosition() {
    this.showErrorAddPosition = false;
    this.formAddPosition = this.configurationService.renderFormAddPosition(this.positionCurrent);
  }

  getStoreData() {
    this.contactList.subscribe(data => {
      if (data) {
        this.clientOptions = data;
      }
    });

    this.siteList.subscribe(data => {
      if (data) {
        this.siteOptions = data;
      }
    });

    this.rdPositionsCurrent.subscribe(data => {
      if (data) {
        this.positionCurrent = data;
        this.customFormAddPosition();
      }
    });

    this.rdPositionsNew.subscribe(data => {
      if (data) {
        this.positionNew = data;
      }
    });

    this.rdPositions.subscribe(data => {
      if (data) {
        this.configurationPositions = _.clone(data);
      }
    });

    this.rdPositionsView.subscribe(data => {
      if (data) {
        this.configurationPositionsView = _.clone(data);
      }
    });
  }

  show() {
    this.childModal.show();
  }

  hide() {
    this.childModal.hide();
  }
}
