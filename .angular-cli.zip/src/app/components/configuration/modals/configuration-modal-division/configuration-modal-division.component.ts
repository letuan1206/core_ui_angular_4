import { HelperService } from './../../../../services/helper.service';
import { ModalDirective } from 'ng2-bootstrap';
import { IMultiSelectOption, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import { CONFIGURATION_SAVE_STATES, CONFIGURATION_SAVE_STATES_ORIGIN } from './../../actions';
import { ApiService } from './../../../../services/api.service';
import { select, NgRedux } from 'ng2-redux';
import { ConfigurationService } from './../../configuration.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CountryState, Division } from './../../../../models/configuration';
import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import * as _ from 'lodash';
import { log } from 'util';

@Component({
  selector: 'app-configuration-modal-division',
  templateUrl: './configuration-modal-division.component.html',
  styleUrls: ['./configuration-modal-division.component.scss']
})
export class ConfigurationModalDivisionComponent implements OnInit {
  @ViewChild('childModal') public childModal: ModalDirective;
  @ViewChild('closeBtn') closeBtn: ElementRef;

  formAddDivision: FormGroup;
  divisionCurrent: Division;
  divisionAddNew = [];
  enableBtnEdit: boolean;
  countryStates: CountryState[] = [];
  btnEditDivision = false;
  countryStateOriginal: any;
  showErrorAddSuperDivision = false;

  @select(s => s.configuration.countryStateList) countryStateList;
  @select(s => s.configuration.countryStateOriginal) rdCountryStateOriginal;
  @select(s => s.configuration.divisionCurrent) rdDivisionCurrent;
  @select(s => s.configuration.divisionNew) rdDivisionNew;

  @select(s => s.configuration.prosekEmployees) rdProsekEmployees;

  employees: any;
  employeesChoose: number[];
  employeesOption: IMultiSelectOption[];
  mySettings: IMultiSelectSettings = {
    dynamicTitleMaxItems: 1
  };

  constructor(private fb: FormBuilder,
    private configurationService: ConfigurationService,
    private helperService: HelperService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>
  ) {
    this.divisionCurrent = new Division();
    this.divisionCurrent.Active = true;
  }

  private closeModal(): void {
    this.closeBtn.nativeElement.click();
  }

  ngOnInit() {
    this.customFormAddDivition();
    this.loadData();
  }

  customFormAddDivition() {
    this.formAddDivision = this.configurationService.renderFormAddDivision(this.divisionCurrent);
  }

  saveAddDivision() {
    if (!this.formAddDivision.valid) {
      this.showErrorAddSuperDivision = true;
      this.helperService.markFormGroupTouched(this.formAddDivision);
      return;
    }

    var employeeData = [];

    _.map(this.employeesChoose, item => {
      employeeData.push(this.employeesOption[item]['ObjectID']);
    });

    if (this.divisionCurrent.ObjectID) {
      var state = _.find(this.countryStates, obj => {
        return obj.ObjectID === this.divisionCurrent.State;
      });

      var division = _.find(state.Divisions, obj => {
        return obj.ObjectID === this.divisionCurrent.ObjectID;
      });

      division.Active = this.formAddDivision.value.Active || false;
      division.Description = this.formAddDivision.value.Description;
      division.State = this.formAddDivision.value.State;
      division.AddEmployees = employeeData;

      _.remove(state.Divisions, obj => obj.ObjectID === this.divisionCurrent.ObjectID);

      var aIndex = _.findIndex(this.countryStates, obj => obj.ObjectID === division.State);

      this.countryStates[aIndex].Divisions.push(division);

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_STATES,
        payload: {
          countryStateList: _.cloneDeep(this.countryStates)
        }
      });

    } else if (!this.divisionCurrent.ObjectID && this.divisionCurrent.Description) {

      var state = _.find(this.countryStates, obj => {
        return obj.ObjectID === this.divisionCurrent.State;
      });

      var division = _.find(state.Divisions, obj => {
        return (obj.Description === this.divisionCurrent.Description && !obj.ObjectID);
      });

      division.Active = this.formAddDivision.value.Active || false;
      division.Description = this.formAddDivision.value.Description;
      division.State = this.formAddDivision.value.State;
      division.AddEmployees = employeeData;

      _.remove(state.Divisions, obj => (!obj.ObjectID && obj.Description === this.divisionCurrent.Description));

      var aIndex = _.findIndex(this.countryStates, obj => obj.ObjectID === division.State);

      this.countryStates[aIndex].Divisions.push(division);

      _.remove(this.divisionAddNew, obj => {
        return (obj.Description === this.divisionCurrent.Description && obj.State === this.divisionCurrent.State);
      })

      this.divisionAddNew.push(division);

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_STATES,
        payload: {
          countryStateList: _.cloneDeep(this.countryStates)
        }
      });

    } else {
      this.divisionCurrent.Active = this.formAddDivision.value.Active || false;
      this.divisionCurrent.Description = this.formAddDivision.value.Description;
      this.divisionCurrent.State = this.formAddDivision.value.State;
      this.divisionCurrent.AddEmployees = employeeData;

      var aIndex = _.findIndex(this.countryStates, obj => {
        return obj.ObjectID === this.divisionCurrent.State;
      });

      this.divisionAddNew.push(this.divisionCurrent);

      this.countryStates[aIndex].Divisions.push(this.divisionCurrent);

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_STATES,
        payload: {
          countryStateList: _.cloneDeep(this.countryStates)
        }
      });
    }

    this.resetFormAddDivision();
  }

  resetFormAddDivision() {
    this.employeesChoose = [];
    this.showErrorAddSuperDivision = false;
    this.hide();
  }

  loadData() {
    this.rdProsekEmployees.subscribe(data => {
      if (data) {
        this.employeesOption = data;
      }
    });

    this.countryStateList.subscribe(data => {
      this.countryStates = _.cloneDeep(data);
    });

    this.rdCountryStateOriginal.subscribe(data => {
      this.countryStateOriginal = _.cloneDeep(data);
    });

    this.rdDivisionCurrent.subscribe(data => {
      if (data) {
        this.divisionCurrent = data;
      } else {
        this.divisionCurrent = new Division();
        this.divisionCurrent.Active = true;
      }
      this.showErrorAddSuperDivision = false;
      this.customFormAddDivition();
    });

    this.rdDivisionNew.subscribe(data => {
      if (data) {
        this.divisionAddNew = data;
      }
    });
  }

  show() {
    this.childModal.show();
  }

  hide() {
    this.childModal.hide();
  }
}
