import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationModalDivisionComponent } from './configuration-modal-division.component';

describe('ConfigurationModalDivisionComponent', () => {
  let component: ConfigurationModalDivisionComponent;
  let fixture: ComponentFixture<ConfigurationModalDivisionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationModalDivisionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationModalDivisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
