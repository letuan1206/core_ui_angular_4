import { HelperService } from './../../../../services/helper.service';
import { ModalDirective } from 'ng2-bootstrap';
import { CONFIGURATION_ADD_RATING, CONFIGURATION_SAVE_RATING } from './../../actions';
import { ApiService } from './../../../../services/api.service';
import { Rating } from './../../../../models/configuration';
import { ConfigurationService } from './../../configuration.service';
import { FormGroup } from '@angular/forms';
import { element } from 'protractor';
import { select, NgRedux } from 'ng2-redux';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { IMultiSelectOption, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import * as _ from 'lodash';

@Component({
  selector: 'app-configuration-modal-rating',
  templateUrl: './configuration-modal-rating.component.html',
  styleUrls: ['./configuration-modal-rating.component.scss']
})
export class ConfigurationModalRatingComponent implements OnInit {
  @ViewChild('childModal') public childModal: ModalDirective;
  @ViewChild('closeBtn') closeBtn: ElementRef;

  @select(s => s.configuration.clientList) clientList;
  @select(s => s.configuration.siteList) siteList;
  @select(s => s.configuration.ratingCurrent) rdRatingCurrent;
  @select(s => s.configuration.ratingNew) rdRatingNew;
  @select(s => s.configuration.rating) rdRating;
  @select(s => s.configuration.ratingView) rdRatingView;

  formAddRating: FormGroup;

  clients: any;
  sites: any;
  ratingCurrent: Rating;
  ratingNew = [];
  clientChoose: number[];
  siteChoose: number[];
  configurationRatingList: Rating[] = [];
  configurationRatingView: Rating[] = [];
  showErrorAddRating = false;

  clientOptions: IMultiSelectOption[];
  siteOptions: IMultiSelectOption[];
  mySettings: IMultiSelectSettings = {
    dynamicTitleMaxItems: 1
  };

  constructor(private configurationService: ConfigurationService,
    private helperService: HelperService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) {

  }

  ngOnInit() {
    this.ratingCurrent = new Rating();
    this.customFormAddRating();
    this.getStoreData();
  }

  private closeModal(): void {
    this.closeBtn.nativeElement.click();
  }

  addRating() {
    if (!this.formAddRating.valid) {
      this.showErrorAddRating = true;
      this.helperService.markFormGroupTouched(this.formAddRating);
      return;
    }

    var clientData = [];
    var siteData = [];

    _.map(this.clientChoose, item => {
      clientData.push(this.clientOptions[item]['ObjectID']);
    });

    _.map(this.siteChoose, item => {
      siteData.push(this.siteOptions[item]['ObjectID']);
    });

    if (this.ratingCurrent.ObjectID) {
      var rating = _.find(this.configurationRatingList, obj => {
        return obj.ObjectID === this.ratingCurrent.ObjectID;
      });

      rating.Active = this.formAddRating.value.Active || true;
      rating.Description = this.formAddRating.value.RatingName;
      rating.AddClients = clientData;
      rating.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_RATING,
        payload: this.configurationRatingList
      });
    } else if (!this.ratingCurrent.ObjectID && this.ratingCurrent.Description) {
      var rating = _.find(this.configurationRatingView, obj => {
        return obj.ObjectID === this.ratingCurrent.ObjectID;
      });

      rating.Active = this.formAddRating.value.Active || true;
      rating.Description = this.formAddRating.value.RatingName;
      rating.AddClients = clientData;
      rating.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_RATING,
        payload: this.configurationRatingView
      });
    } else {
      this.ratingCurrent.Active = this.formAddRating.value.Active || true;
      this.ratingCurrent.Description = this.formAddRating.value.RatingName;
      this.ratingCurrent.AddClients = clientData;
      this.ratingCurrent.AddSites = siteData;

      this.ratingNew.push(_.cloneDeep(this.ratingCurrent));

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_RATING,
        payload: this.ratingNew
      });
    }

    this.resetFormAddRating();
  }

  resetFormAddRating() {
    this.showErrorAddRating = false;
    this.clientChoose = [];
    this.siteChoose = [];
    this.hide();
  }

  customFormAddRating() {
    this.showErrorAddRating = false;
    this.formAddRating = this.configurationService.renderFormAddRating(this.ratingCurrent);
  }

  getStoreData() {
    this.clientList.subscribe(data => {
      if (data) {
        this.clientOptions = data
      }
    });

    this.siteList.subscribe(data => {
      if (data) {
        this.siteOptions = data;
      }
    });

    this.rdRatingCurrent.subscribe(data => {
      if (data) {
        this.ratingCurrent = data;
        this.customFormAddRating();
      }
    });

    this.rdRatingNew.subscribe(data => {
      if (data) {
        this.ratingNew = data;
      }
    });

    this.rdRating.subscribe(data => {
      if (data) {
        this.configurationRatingList = _.clone(data);
      }
    });

    this.rdRatingView.subscribe(data => {
      if (data) {
        this.configurationRatingView = _.clone(data);
      }
    });
  }

  show() {
    this.childModal.show();
  }

  hide() {
    this.childModal.hide();
  }
}
