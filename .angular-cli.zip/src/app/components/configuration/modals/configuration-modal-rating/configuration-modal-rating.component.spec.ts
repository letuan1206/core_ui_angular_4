import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationModalRatingComponent } from './configuration-modal-rating.component';

describe('ConfigurationModalRatingComponent', () => {
  let component: ConfigurationModalRatingComponent;
  let fixture: ComponentFixture<ConfigurationModalRatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationModalRatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationModalRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
