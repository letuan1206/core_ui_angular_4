import { HelperService } from './../../../../services/helper.service';
import { ModalDirective } from 'ng2-bootstrap';
import { CONFIGURATION_ADD_SERVICE, CONFIGURATION_SAVE_SERVICE } from './../../actions';
import { Service } from './../../../../models/configuration';
import { ApiService } from './../../../../services/api.service';
import { ConfigurationService } from './../../configuration.service';
import { IMultiSelectOption, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import { select, NgRedux } from 'ng2-redux';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-configuration-modal-service',
  templateUrl: './configuration-modal-service.component.html',
  styleUrls: ['./configuration-modal-service.component.scss']
})
export class ConfigurationModalServiceComponent implements OnInit {
  @ViewChild('childModal') public childModal: ModalDirective;
  @ViewChild('closeBtn') closeBtn: ElementRef;

  @select(s => s.configuration.clientList) clientList;
  @select(s => s.configuration.siteList) siteList;
  @select(s => s.configuration.serviceCurrent) rdServiceCurrent;
  @select(s => s.configuration.serviceNew) rdServiceNew;
  @select(s => s.configuration.service) rdService;
  @select(s => s.configuration.serviceView) rdServiceView;

  formAddService: FormGroup;

  clients: any;
  sites: any;
  serviceCurrent: Service;
  serviceNew = [];
  clientChoose: number[];
  siteChoose: number[];
  configurationServiceList: Service[] = [];
  configurationServiceView: Service[] = [];
  showErrorAddService = false;

  // Settings configuration
  mySettings: IMultiSelectSettings = {
    dynamicTitleMaxItems: 1
  };

  clientOptions: IMultiSelectOption[];
  siteOptions: IMultiSelectOption[];

  constructor(private configurationService: ConfigurationService,
    private helperService: HelperService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) {

  }

  private closeModal(): void {
    this.closeBtn.nativeElement.click();
  }

  ngOnInit() {
    this.serviceCurrent = new Service();
    this.customFormAddService();
    this.getStoreData();
  }

  addService() {
    if (!this.formAddService.valid) {
      this.showErrorAddService = true;
      this.helperService.markFormGroupTouched(this.formAddService);
      return;
    }

    var clientData = [];
    var siteData = [];

    _.map(this.clientChoose, item => {
      clientData.push(this.clientOptions[item]['ObjectID']);
    });

    _.map(this.siteChoose, item => {
      siteData.push(this.siteOptions[item]['ObjectID']);
    });

    if (this.serviceCurrent.ObjectID) {
      var service = _.find(this.configurationServiceList, obj => {
        return obj.ObjectID === this.serviceCurrent.ObjectID;
      });

      service.Active = this.formAddService.value.Active || false;
      service.Description = this.formAddService.value.ServiceName;
      service.AddClients = clientData;
      service.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_SAVE_SERVICE,
        payload: this.configurationServiceList
      });
    } else if (!this.serviceCurrent.ObjectID && this.serviceCurrent.Description) {
      var service = _.find(this.configurationServiceView, obj => {
        return obj.ObjectID === this.serviceCurrent.ObjectID;
      });

      service.Active = this.formAddService.value.Active || false;
      service.Description = this.formAddService.value.ServiceName;
      service.AddClients = clientData;
      service.AddSites = siteData;

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_SERVICE,
        payload: this.configurationServiceView
      });
    } else {
      this.serviceCurrent.Active = this.formAddService.value.Active || false;
      this.serviceCurrent.Description = this.formAddService.value.ServiceName;
      this.serviceCurrent.AddClients = clientData;
      this.serviceCurrent.AddSites = siteData;

      this.serviceNew.push(_.cloneDeep(this.serviceCurrent));

      this.ngRedux.dispatch({
        type: CONFIGURATION_ADD_SERVICE,
        payload: this.serviceNew
      });
    }

    this.resetFormAddService();
  }

  resetFormAddService() {
    this.showErrorAddService = false;
    this.clientChoose = [];
    this.siteChoose = [];
    this.hide();
  }

  customFormAddService() {
    this.showErrorAddService = false;

    this.loadClientList();
    this.loadSiteList();

    this.formAddService = this.configurationService.renderFormAddService(this.serviceCurrent);
  }

  getStoreData() {
    this.loadClientList();

    this.loadSiteList();

    this.rdServiceCurrent.subscribe(data => {
      if (data) {
        this.serviceCurrent = data;
        this.customFormAddService();
      }
    });

    this.rdServiceNew.subscribe(data => {
      if (data) {
        this.serviceNew = data;
      }
    });

    this.rdService.subscribe(data => {
      if (data) {
        this.configurationServiceList = _.clone(data);
      }
    });

    this.rdServiceView.subscribe(data => {
      if (data) {
        this.configurationServiceView = _.clone(data);
      }
    });
  }

  loadClientList() {
    this.clientList.subscribe(data => {
      if (data) {
        this.clientOptions = _.cloneDeep(data);
      }
    });
  }

  loadSiteList() {
    this.siteList.subscribe(data => {
      if (data) {
        this.siteOptions = _.cloneDeep(data);
      }
    });
  }

  show() {
    this.childModal.show();
  }

  hide() {
    this.childModal.hide();
  }
}
