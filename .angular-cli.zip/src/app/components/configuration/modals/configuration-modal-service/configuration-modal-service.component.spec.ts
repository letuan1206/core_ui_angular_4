import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigurationModalServiceComponent } from './configuration-modal-service.component';

describe('ConfigurationModalServiceComponent', () => {
  let component: ConfigurationModalServiceComponent;
  let fixture: ComponentFixture<ConfigurationModalServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigurationModalServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigurationModalServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
