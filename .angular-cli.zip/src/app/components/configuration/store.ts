import { CountryState, Client, Site } from './../../models/configuration';
import { tassign } from 'tassign';
import * as constant from './actions';

export interface ConfigurationState {
    countryName: string;
    enableBtnEdit: boolean;

    countryStateList: any;
    countryStateOriginal: any;
    countryStateData: any;

    rating: any;
    ratingView: any;
    ratingCurrent: any;
    ratingNew: any;

    service: any;
    serviceView: any;
    serviceCurrent: any;
    serviceNew: any;

    industries: any;
    industriesView: any;
    industriesCurrent: any;
    industriesNew: any;

    positions: any;
    positionsView: any;
    positionsCurrent: any;
    positionsNew: any;

    clientList: any;
    siteList: any;
    prosekEmployees: any;
    contactList: any;

    divisionCurrent: any;
    divisionNew: any;
}

export const CONFIGURATION_INITAL_STATE: ConfigurationState = {
    countryName: '',
    enableBtnEdit: false,
    countryStateList: [],
    countryStateOriginal: [],
    countryStateData: null,

    rating: null,
    ratingView: null,
    ratingCurrent: null,
    ratingNew: [],

    service: null,
    serviceView: null,
    serviceCurrent: null,
    serviceNew: [],

    industries: null,
    industriesView: null,
    industriesCurrent: null,
    industriesNew: [],

    positions: null,
    positionsView: null,
    positionsCurrent: null,
    positionsNew: [],

    clientList: null,
    siteList: null,
    prosekEmployees: null,
    contactList: null,

    divisionCurrent: null,
    divisionNew: []
};

function incrementCount(state, action) {
    return tassign(state, { count: state.count + 1 });
}

export function configurationReducer(state = CONFIGURATION_INITAL_STATE, action): ConfigurationState {
    switch (action.type) {
        case constant.CONFIGURATION_SAVE_COUNTRY: return tassign(state, { countryName: action.payload });
        case constant.CONFIGURATION_ACTION: return tassign(state, { enableBtnEdit: action.payload });

        case constant.CONFIGURATION_SAVE_STATES: return tassign(state, { countryStateList: action.payload.countryStateList });
        case constant.CONFIGURATION_SAVE_STATES_ORIGIN: return tassign(state, { countryStateOriginal: action.payload });

        case constant.CONFIGURATION_SAVE_RATING: return tassign(state, { rating: action.payload });
        case constant.CONFIGURATION_ADD_RATING: return tassign(state, { ratingView: action.payload });
        case constant.CONFIGURATION_CURRENT_RATING: return tassign(state, { ratingCurrent: action.payload });
        case constant.CONFIGURATION_NEW_RATING: return tassign(state, { ratingNew: action.payload });

        case constant.CONFIGURATION_SAVE_SERVICE: return tassign(state, { service: action.payload });
        case constant.CONFIGURATION_ADD_SERVICE: return tassign(state, { serviceView: action.payload });
        case constant.CONFIGURATION_CURRENT_SERVICE: return tassign(state, { serviceCurrent: action.payload });
        case constant.CONFIGURATION_NEW_SERVICE: return tassign(state, { serviceNew: action.payload });

        case constant.CONFIGURATION_SAVE_INDUSTRY: return tassign(state, { industries: action.payload });
        case constant.CONFIGURATION_ADD_INDUSTRY: return tassign(state, { industriesView: action.payload });
        case constant.CONFIGURATION_CURRENT_INDUSTRY: return tassign(state, { industriesCurrent: action.payload });
        case constant.CONFIGURATION_NEW_INDUSTRY: return tassign(state, { industriesNew: action.payload });

        case constant.CONFIGURATION_SAVE_POSITION: return tassign(state, { positions: action.payload });
        case constant.CONFIGURATION_ADD_POSITION: return tassign(state, { positionsView: action.payload });
        case constant.CONFIGURATION_CURRENT_POSITION: return tassign(state, { positionsCurrent: action.payload });
        case constant.CONFIGURATION_NEW_POSITION: return tassign(state, { positionsNew: action.payload });

        case constant.CONFIGURATION_SAVE_CLIENT: return tassign(state, { clientList: action.payload });
        case constant.CONFIGURATION_SAVE_SITE: return tassign(state, { siteList: action.payload });
        case constant.CONFIGURATION_SAVE_EMPLOYEES: return tassign(state, { prosekEmployees: action.payload });
        case constant.CONFIGURATION_SAVE_CONTACT: return tassign(state, { contactList: action.payload });

        case constant.CONFIGURATION_CURRENT_DIVISION: return tassign(state, { divisionCurrent: action.payload });
        case constant.CONFIGURATION_NEW_DIVISION: return tassign(state, { divisionNew: action.payload });
    }

    return state;
}
