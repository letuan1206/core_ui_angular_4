import { ConfigService } from './../../../services/config.service';
import { ConfigurationModalRatingComponent } from './../modals/configuration-modal-rating/configuration-modal-rating.component';
import { ApiService } from './../../../services/api.service';
import { CONFIGURATION_SAVE_RATING, CONFIGURATION_ADD_RATING, CONFIGURATION_NEW_RATING, CONFIGURATION_CURRENT_RATING } from './../actions';
import { select, NgRedux } from 'ng2-redux';
import { Rating } from './../../../models/configuration';
import { ConfigurationService } from './../configuration.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../../services/helper.service';

@Component({
  selector: 'app-configuration-rating',
  templateUrl: './configuration-rating.component.html',
  styleUrls: ['./configuration-rating.component.scss']
})
export class ConfigurationRatingComponent implements OnInit {
  @ViewChild('childModal') childModal: ConfigurationModalRatingComponent;
  configurationRatingList: Rating[] = [];
  configurationRatingView: Rating[] = [];

  enableBtnEdit: boolean;
  btnEditRating = false;
  rating: Rating;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.configuration.enableBtnEdit) rdEnableBtnEdit;
  @select(s => s.configuration.rating) rdRating;
  @select(s => s.configuration.ratingView) rdRatingView;

  constructor(
    private configService: ConfigService,
    private helperSerivce: HelperService,
    private configurationService: ConfigurationService,
    private apiService: ApiService,
    private ngRedux: NgRedux<any>) { 
      this.responseStatus = this.configService.get('status');
    }

  ngOnInit() {
    this.getStoreData();
  }

  changeStatusButton() {
    this.btnEditRating = !this.btnEditRating;
  }

  cancelSaveRating() {
    this.errorMessages = null;
    this.configurationService.setStoreRating();

    this.resetStoreRatingNew();
    this.changeStatusButton();
  }

  resetStoreRatingNew() {
    this.ngRedux.dispatch({
      type: CONFIGURATION_ADD_RATING,
      payload: []
    });

    this.ngRedux.dispatch({
      type: CONFIGURATION_NEW_RATING,
      payload: []
    });
  }

  openModalAddRating(type, index, data) {
    if (!this.btnEditRating) {
      return;
    }
    this.helperSerivce.showLoading();
    return new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getClientByQueryParams({ NoRating: true })
      ]).then(
        ([clients]) => {
          if (type === 'addNew') {
            this.rating = new Rating();
            this.rating.Active = true;
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_RATING,
              payload: this.rating
            });

          } else if (type === 'editNew') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_RATING,
              payload: data
            });

          } else if (type === 'edit') {
            this.ngRedux.dispatch({
              type: CONFIGURATION_CURRENT_RATING,
              payload: data
            });
          }
          this.helperSerivce.hideLoading();
          this.childModal.show();
          resolve();
        }, () => {
          this.helperSerivce.hideLoading();
          reject;
        }
        );
    });
  }

  saveRating() {
    var ratingList = Object.assign({}, this.configurationRatingView);
    var ratingUpdate = _.fromPairs(_.map(this.configurationRatingList, i => [i.ObjectID, i]));

    var params = {
      create: ratingList,
      update: ratingUpdate,
      delete: {},
    };

    this.helperSerivce.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if(res.status === this.responseStatus.error) {
        this.errorMessages =  res.errorDetails;
        this.helperSerivce.hideLoading();
        return;
      }
      this.errorMessages = null;

      this.configurationService.setStoreRating();
      this.changeStatusButton();
      this.resetStoreRatingNew();
      this.helperSerivce.hideLoading();
    });
  }

  getStoreData() {
    this.rdEnableBtnEdit.subscribe(data => {
      this.enableBtnEdit = data;
    });

    this.rdRating.subscribe(data => {
      if (data) {
        this.configurationRatingList = _.clone(data);
      }
    });

    this.rdRatingView.subscribe(data => {
      if (data) {
        this.configurationRatingView = data;
      }
    });
  }

}
