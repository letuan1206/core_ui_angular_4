import { OrganisationService } from './organisation.service';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import * as _ from 'lodash';
import { HelperService } from '../../services/helper.service';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'app-organisation',
  template: '<router-outlet></router-outlet>',
  styleUrls: ['./organisation.component.scss']
})
export class OrganisationComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}

@Component({
  selector: 'app-organisation-list',
  templateUrl: './organisation.component.html',
  styleUrls: ['./organisation.component.scss']
})
export class OrganisationListComponent implements OnInit, AfterViewInit {

  objectKeys = Object.keys;
  companyList: any;

  constructor(private organisationService: OrganisationService,
    private helperSerivce: HelperService) {

  }

  ngOnInit() {
    setTimeout(() => this.getOrganisationList());
      $('body').removeClass('sidebar-minimized brand-minimized');
  }

  ngAfterViewInit() {
    this.helperSerivce.setThemeDefault();
  }

  getOrganisationList() {
    var params = {
      environment: 'qa',
      queryType: 'All',
      queryParams: {},
      attributes: '@all'
    }
    this.helperSerivce.showLoading();
    this.organisationService.getOrganisationList(params, (res) => {
      var data = _.toArray(res.references);
      this.companyList = _.sortBy(data, [function (company) {
        return company.TradingName;
      }]);
      this.helperSerivce.hideLoading();
    });
  }

}
