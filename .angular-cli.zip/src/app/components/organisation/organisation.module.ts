import { SharedProsekModule } from './../../shared/shared.module';
import { TextMaskModule } from 'angular2-text-mask';
import { FileUploadModule } from 'ng2-file-upload';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './../../app.routing';
import { BrowserModule } from '@angular/platform-browser';
import { OrganisationListComponent, OrganisationComponent } from './organisation.component';
import { OrganisationService } from './organisation.service';
import { OrganisationDetailComponent } from './organisation-detail/organisation-detail.component';
import { OrganisationAddComponent } from './organisation-add/organisation-add.component';
import { OrganisationModalAddLogoComponent } from './modals/organisation-modal-add-logo/organisation-modal-add-logo.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    FileUploadModule,
    TextMaskModule,
    SharedProsekModule,
  ],
  declarations: [
    OrganisationComponent,
    OrganisationListComponent,
    OrganisationAddComponent,
    OrganisationDetailComponent,
    OrganisationModalAddLogoComponent,
  ],
  providers: [
    OrganisationService
  ]
})
export class OrganisationModule { }
