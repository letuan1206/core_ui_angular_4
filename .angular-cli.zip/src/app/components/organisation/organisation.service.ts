import { HelperService } from './../../services/helper.service';
import { Organisation, Address, Banking, SuperFund } from './../../models/organisation';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';
import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import * as _ from 'lodash';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class OrganisationService {
  apiBase: string;
  formOrganisationDetail: FormGroup;

  constructor(private http: Http,
    private fb: FormBuilder,
    public configService: ConfigService, private api: ApiService, private helperService: HelperService) {
    this.apiBase = this.configService.get('apiBase');
  }

  getOrganisationList(params, callback) {
    this.api.post('/Organisations', params).subscribe(res => {
      callback(res);
    });
  }

  getOrganisationDetail(params, callback) {
    const data = {
      environment: 'qa',
      queryType: 'ByID',
      assocs: ['Address', 'PostalAddress', 'Banking', 'SuperFunds', 'Logos'],
      queryParams: {
        id: params
      }
    };

    this.api.post(`/Organisations`, data).subscribe(res => {
      callback(res);
    });
  }

  addOrganisation(params, callback) {
    this.api.post(`/Save`, params).subscribe(res => {
      callback(res);
    });
  }

  updateOrganisation(params, callback) {
    this.api.post(`/Save`, params).subscribe(res => {
      callback(res);
    });
  }

  renderFormOrganisation(organisation: Organisation, address1: Address, address2: Address, editCompanyStatus) {
    return this.fb.group({
      Active: [organisation.Active],
      TradingName: [{ value: organisation.TradingName, disabled: editCompanyStatus }, [Validators.required]],
      CompanyName: [{ value: organisation.CompanyName, disabled: editCompanyStatus }, [Validators.required]],
      Phone: [{ value: organisation.Phone, disabled: editCompanyStatus }, [Validators.required]],
      Fax: [{ value: organisation.Fax, disabled: editCompanyStatus }],
      AdminEmail: [{ value: organisation.AdminEmail, disabled: editCompanyStatus }, [Validators.required, Validators.email]],
      Website: [{ value: organisation.Website, disabled: editCompanyStatus }, [Validators.required]],
      ABN: [{ value: organisation.ABN, disabled: editCompanyStatus }, [Validators.required, Validators.pattern('^[0-9]+$')]],
      ACN: [{ value: organisation.ACN, disabled: editCompanyStatus }, [Validators.required, Validators.pattern('^[0-9]+$')]],
      TaxFileNumber: [{ value: organisation.TaxFileNumber, disabled: editCompanyStatus }, [Validators.required]],
      Incorporated: [{ value: organisation.Incorporated, disabled: editCompanyStatus }, [Validators.required, Validators.pattern('^[0-9]{4}$')]],
      State: [{ value: organisation.State, disabled: editCompanyStatus }, [Validators.required]],
      ParentCompany: [{ value: organisation.ParentCompany, disabled: editCompanyStatus }],
      CompanyType: [{ value: organisation.CompanyType, disabled: editCompanyStatus }, [Validators.required]],
      AddressAddress1: [{ value: address1.Address1, disabled: editCompanyStatus }, [Validators.required]],
      AddressState: [{ value: address1.State, disabled: editCompanyStatus }, [Validators.required]],
      AddressPostcode: [{ value: address1.Postcode, disabled: editCompanyStatus }, [Validators.required, Validators.pattern('^[0-9]{4}$')]],
      PostalAddressAddress1: [{ value: address2.Address1, disabled: editCompanyStatus }, [Validators.required]],
      PostalAddressState: [{ value: address2.State, disabled: editCompanyStatus }, [Validators.required]],
      PostalAddressPostcode: [{ value: address2.Postcode, disabled: editCompanyStatus }, [Validators.required, Validators.pattern('^[0-9]{4}$')]],
    });
  }

  renderFormBanking(banking: Banking) {
    return this.fb.group({
      BankName: [banking.BankName],
      Branch: [banking.Branch],
      BSB: [banking.BSB, [Validators.required]],
      AccountNumber: [banking.AccountNumber, [Validators.required]],
      AccountName: [banking.AccountName, [Validators.required]],
      Type: [banking.Type],
    });
  }

  renderFormSuperFund(superFund: SuperFund) {
    return this.fb.group({
      FundName: [superFund.FundName, [Validators.required]],
      FundABN: [superFund.FundABN, [Validators.required]],
      EmployeeNo: [superFund.EmployeeNo, [Validators.required, Validators.pattern('^[0-9 ]+$')]],
    });
  }

  getParamEditOrganisation(companyDetail?: any, companyId?: any, formOrganisationDetail?: FormGroup) {
    const organisation = _.clone(companyDetail.references);

    let organisationDetail: Organisation;

    organisationDetail = _.clone(_.get(organisation, companyId));
    organisationDetail.Website = formOrganisationDetail.value.Website;
    organisationDetail.TradingName = formOrganisationDetail.value.TradingName;
    organisationDetail.TaxFileNumber = formOrganisationDetail.value.TaxFileNumber;
    organisationDetail.CompanyType = formOrganisationDetail.value.CompanyType;
    organisationDetail.ACN = formOrganisationDetail.value.ACN;
    organisationDetail.ABN = formOrganisationDetail.value.ABN;
    organisationDetail.AdminEmail = formOrganisationDetail.value.AdminEmail;
    organisationDetail.CompanyName = formOrganisationDetail.value.CompanyName;
    organisationDetail.ParentCompany = formOrganisationDetail.value.ParentCompany;
    organisationDetail.Phone = formOrganisationDetail.value.Phone;
    organisationDetail.State = formOrganisationDetail.value.State;
    organisationDetail.Incorporated = formOrganisationDetail.value.Incorporated;
    organisationDetail.Fax = formOrganisationDetail.value.Fax;

    let organisationAddress: Address;
    let organisationPostalAddress: Address;

    organisationAddress = _.clone(_.get(organisation, organisationDetail.Address));
    organisationAddress.Address1 = formOrganisationDetail.value.AddressAddress1;
    organisationAddress.State = formOrganisationDetail.value.AddressState;
    organisationAddress.Postcode = formOrganisationDetail.value.AddressPostcode;

    organisationPostalAddress = _.clone(_.get(organisation, organisationDetail.PostalAddress));
    organisationPostalAddress.Address1 = formOrganisationDetail.value.PostalAddressAddress1;
    organisationPostalAddress.State = formOrganisationDetail.value.PostalAddressState;
    organisationPostalAddress.Postcode = formOrganisationDetail.value.PostalAddressPostcode;

    _.set(organisation, organisationDetail.Address, organisationAddress);
    _.set(organisation, organisationDetail.PostalAddress, organisationPostalAddress);
    _.set(organisation, companyId, organisationDetail);

    return {
      'create': {},
      'update': organisation,
      'delete': {}
    };
  }

  getParamUpdateBanking(companyDetail?: any, companyId?: any, bankingViewList?: Banking[], bankingAddList?: Banking[]) {
    const bankingNew = Object.assign({}, bankingAddList);
    const organisation = _.clone(companyDetail.references);
    const path = companyId + '.Banking';

    let bankingKey = _.keys(bankingNew);
    const banking = _.get(organisation, path);
    if (banking) {
      bankingKey = _.concat(banking, _.keys(bankingNew));

      banking.forEach(element => {
        const bankSet = _.find(bankingViewList, ['ObjectID', (_.get(companyDetail.references, element)).ObjectID]);
        _.set(organisation, element, bankSet);
      });
    }

    _.set(organisation, path, bankingKey);

    return {
      'create': bankingNew,
      'update': organisation,
      'delete': {}
    };
  }

  updateBankingViewList(bankingViewList: Banking, formEditBanking: FormGroup) {
    bankingViewList.AccountName = formEditBanking.value.AccountName;
    bankingViewList.AccountNumber = formEditBanking.value.AccountNumber;
    bankingViewList.BankName = formEditBanking.value.BankName;
    bankingViewList.Branch = formEditBanking.value.Branch;
    bankingViewList.Type = formEditBanking.value.Type;
    bankingViewList.BSB = formEditBanking.value.BSB;
  }

  getParamDeactivateOrganisation(companyDetail?: any, companyId?: string, type?: boolean) {
    const organisation = _.clone(companyDetail.references);
    let organisationDetail: Organisation;
    organisationDetail = _.clone(_.get(organisation, companyId));
    organisationDetail.Active = type;

    _.set(organisation, companyId, organisationDetail);

    return {
      'create': {},
      'update': organisation,
      'delete': {}
    };
  }

}
