import { OrganisationService } from './organisation.service';
import { TestBed, inject } from '@angular/core/testing';

describe('OrganisationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrganisationService]
    });
  });

  it('should be created', inject([OrganisationService], (service: OrganisationService) => {
    expect(service).toBeTruthy();
  }));
});
