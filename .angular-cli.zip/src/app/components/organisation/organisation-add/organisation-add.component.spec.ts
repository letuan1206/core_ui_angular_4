import { OrganisationAddComponent } from './organisation-add.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';


describe('OrganisationComponent', () => {
  let component: OrganisationAddComponent;
  let fixture: ComponentFixture<OrganisationAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrganisationAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganisationAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
