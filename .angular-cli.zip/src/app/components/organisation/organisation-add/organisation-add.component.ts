import { Router } from '@angular/router';
import { HelperService } from './../../../services/helper.service';
import { textMask } from './../../common/constants';
import { ConfigService } from './../../../services/config.service';
import { OrganisationService } from './../organisation.service';
import { Organisation, Address, Banking, SuperFund, Logo, LogoUpload } from './../../../models/organisation';
import { Component, OnInit, NgZone, HostListener, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import * as _ from 'lodash';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-organisation-add',
  templateUrl: './organisation-add.component.html',
  styleUrls: ['./organisation-add.component.scss']
})
export class OrganisationAddComponent implements OnInit, AfterViewInit {
  public uploader: FileUploader;
  formOrganisationDetail: FormGroup;
  formAddBanking: FormGroup;
  formEditBanking: FormGroup;
  formAddSuperFund: FormGroup;
  formEditSuperFund: FormGroup;

  organisation: Organisation;
  address1: Address;
  address2: Address;

  bankingViewList: Banking[] = [];
  bankingAddList: Banking[] = [];
  superFundViewList: SuperFund[] = [];
  superFundAddList: SuperFund[] = [];
  logoViewList: Logo[] = [];
  logoDeleteList: Logo[] = [];
  logoTokenList: LogoUpload[] = [];

  banking: Banking;
  bankingEdit: Banking;
  superFund: SuperFund;
  superFundEdit: SuperFund;

  bankingChooseIndex: number;
  superFundChooseIndex: number;

  companyId: string;
  companyDetail: any;

  isActivate: boolean;
  bankStatus = false;
  logoStatus = false;
  superFundStatus = false;
  editCompanyStatus = false;
  canEdit = false;

  // show error
  showErrorCompany = false;
  showErrorAddBank = false;
  showErrorAddSuperFund = false;

  public maskTaxFileNumber = textMask.maskTaxFileNumber;
  public maskPhoneNumber = textMask.maskPhoneNumber;
  public maskFaxNumber = textMask.maskFaxNumber;
  public maskBSBNumber = textMask.maskBSBNumber;
  public maskAccountNumber = textMask.maskAccountNumber;
  public maskFundABN = textMask.maskFundABN;

  webRoot: string;
  constructor(
    private organisationService: OrganisationService,
    private fb: FormBuilder,
    private zone: NgZone,
    private configService: ConfigService,
    private router: Router,
    private helperService: HelperService) {
    this.uploader = new FileUploader({ url: configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };
    this.webRoot = configService.get('webRoot');
    this.clearFieldOrganisation();
    this.banking = new Banking();
    this.bankingEdit = new Banking();
    this.superFund = new SuperFund();
    this.superFundEdit = new SuperFund();
  }

  ngOnInit() {
    this.customFormOrganisation();
    this.customFormAddBanking();
    this.customFormEditBanking();
    this.customFormAddSuperFund();
    this.customFormEditSuperFund();
    window.scrollTo(0, 0);
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  @HostListener('window:keyup', ['$event'])

  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 27) {
      this.clearFieldBankAccount();
      this.clearFieldSuperFund();
    }
  }

  customFormOrganisation() {
    this.formOrganisationDetail = this.organisationService.renderFormOrganisation(this.organisation, this.address1, this.address2, this.editCompanyStatus);
  }

  customFormAddBanking() {
    this.formAddBanking = this.organisationService.renderFormBanking(this.banking);
  }

  customFormEditBanking() {
    this.formEditBanking = this.organisationService.renderFormBanking(this.bankingEdit);
  }

  customFormAddSuperFund() {
    this.formAddSuperFund = this.organisationService.renderFormSuperFund(this.superFund);
  }

  customFormEditSuperFund() {
    this.formEditSuperFund = this.organisationService.renderFormSuperFund(this.superFundEdit);
  }

  addOrganisation() {
    if (!this.formOrganisationDetail.valid) {
      this.showErrorCompany = true;
      this.helperService.markFormGroupTouched(this.formOrganisationDetail);
      return;
    }
    this.showErrorCompany = false;
    this.organisation = _.merge(this.organisation, this.formOrganisationDetail.value);
    this.organisation.Active = true;

    this.address1.Address1 = this.formOrganisationDetail.value.AddressAddress1;
    this.address1.State = this.formOrganisationDetail.value.AddressState;
    this.address1.Postcode = this.formOrganisationDetail.value.AddressPostcode;

    this.address2.Address1 = this.formOrganisationDetail.value.PostalAddressAddress1;
    this.address2.State = this.formOrganisationDetail.value.PostalAddressState;
    this.address2.Postcode = this.formOrganisationDetail.value.PostalAddressPostcode;

    this.organisation.Address = 'NEW:2';
    this.organisation.PostalAddress = 'NEW:3';
    const params = {
      'environment': 'qa',
      'create': {
        'NEW:1': this.organisation,
        'NEW:2': this.address1,
        'NEW:3': this.address2
      },
      'update': {},
      'delete': {}
    };
   
    this.helperService.showLoading();
    this.organisationService.addOrganisation(params, (res) => {
      this.companyId = _.get(res.created, 'NEW:1');
      this.formOrganisationDetail.disable();
      this.loadOrganisationDetail();
      this.canEdit = true;
      this.editCompanyStatus = true;
      this.showErrorCompany = false;
      this.helperService.hideLoading();
    });
  }

  editOrganisation() {
    if (!this.formOrganisationDetail.valid) {
      this.showErrorCompany = true;
      this.helperService.markFormGroupTouched(this.formOrganisationDetail);
      return;
    }
    this.showErrorCompany = false;

    const params = this.organisationService.getParamEditOrganisation(this.companyDetail, this.companyId, this.formOrganisationDetail);
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.changeStatusCompany();
      this.helperService.hideLoading();
    });
  }

  removeAllSpace(formGroup: FormGroup) {
    this.helperService.removeAllSpace(formGroup);
  }

  deactivateOrganisation(type) {
    const params = this.organisationService.getParamDeactivateOrganisation(this.companyDetail, this.companyId, type);
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      if (!type) {
        this.changeStatusCompany();
      }
      this.helperService.hideLoading();
    });
  }

  loadOrganisationDetail() {
    this.helperService.showLoading();
    this.organisationService.getOrganisationDetail(this.companyId, (res) => {
      this.companyDetail = res;
      this.organisation = _.clone(_.get(this.companyDetail.references, this.companyId));
      this.isActivate = this.organisation.Active || false;
      const addressId = _.get(this.companyDetail.references, `${this.companyId}.Address`);
      const postalAddressId = _.get(this.companyDetail.references, `${this.companyId}.PostalAddress`);

      this.address1 = _.clone(_.get(this.companyDetail.references, addressId));
      this.address2 = _.clone(_.get(this.companyDetail.references, postalAddressId));
      this.customFormOrganisation();
      const bankingId = _.get(this.companyDetail.references, `${this.companyId}.Banking`);
      if (bankingId) {
        this.bankingViewList = [];
        bankingId.forEach(element => {
          this.bankingViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }

      const superFundId = _.get(this.companyDetail.references, `${this.companyId}.SuperFunds`);
      if (superFundId) {
        this.superFundViewList = [];
        superFundId.forEach(element => {
          this.superFundViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }

      const logoId = _.get(this.companyDetail.references, `${this.companyId}.Logos`);
      if (logoId) {
        this.logoViewList = [];
        logoId.forEach(element => {
          this.logoViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }

      this.helperService.hideLoading();
    });
  }

  cancelEditOrganisation() {
    this.router.navigate(['/organisation']);
  }

  clearFormEditOrganisation() {
    this.organisation = _.clone(_.get(this.companyDetail.references, this.companyId));
    const addressId = _.get(this.companyDetail.references, `${this.companyId}.Address`);
    const postalAddressId = _.get(this.companyDetail.references, `${this.companyId}.PostalAddress`);

    this.address1 = _.clone(_.get(this.companyDetail.references, addressId));
    this.address2 = _.clone(_.get(this.companyDetail.references, postalAddressId));
    this.customFormOrganisation();
    this.showErrorCompany = false;
  }

  clearFieldOrganisation() {
    if (this.formOrganisationDetail) {
      this.formOrganisationDetail.reset();
    }
    this.organisation = new Organisation();
    this.address1 = new Address();
    this.address2 = new Address();
    this.showErrorCompany = false;
  }

  clearFieldBankAccount() {
    this.showErrorAddBank = false;
    this.formAddBanking.reset();
  }

  clearFieldSuperFund() {
    this.showErrorAddSuperFund = false;
    this.formAddSuperFund.reset();
  }

  changeStatusCompany() {
    this.editCompanyStatus = !this.editCompanyStatus;
    if (!this.editCompanyStatus) {
      this.formOrganisationDetail.enable();
    } else {
      this.formOrganisationDetail.disable();
    }
  }

  changeStatusByType(type) {
    if (!this.canEdit) {
      return;
    }
    if (type === 'banking') {
      this.bankStatus = !this.bankStatus;
    } else if (type === 'superFund') {
      this.superFundStatus = !this.superFundStatus;
    } else if (type === 'logo') {
      this.logoStatus = !this.logoStatus;
    }
  }

  cancelSaveBanking() {
    // this.bankingViewList = _.differenceBy(this.bankingViewList, this.bankingAddList, 'ObjectID');
    const bankingId = _.get(this.companyDetail.references, `${this.companyId}.Banking`);
    if (bankingId) {
      this.bankingViewList = [];
      bankingId.forEach(element => {
        this.bankingViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }

    this.bankingAddList = [];
    this.bankStatus = false;
    this.showErrorAddBank = false;
  }

  addBankingList() {
    if (!this.formAddBanking.valid) {
      this.helperService.markFormGroupTouched(this.formAddBanking);
      this.showErrorAddBank = true;
      return;
    }
    this.showErrorAddBank = false;
    this.banking = _.merge(this.banking, this.formAddBanking.value);
    this.bankingAddList.push(this.banking);
    this.banking = new Banking();
    this.formAddBanking.reset();
    $('#modalAddAcount').modal('hide');
  }

  getBankInBankingList(type, index) {
    if (type === 'view') {
      this.bankingEdit = _.clone(this.bankingViewList[index]);
      this.bankingChooseIndex = index;
    } else {
      this.bankingEdit = _.clone(this.bankingAddList[index]);
      this.bankingChooseIndex = index;
    }
    this.customFormEditBanking();
  }

  updateBankingViewList(index) {
    if (!this.formEditBanking.valid) {
      this.helperService.markFormGroupTouched(this.formEditBanking);
      this.showErrorAddBank = true;
      return;
    }
    this.showErrorAddBank = false;
    $('#modalEditBankViewAcount').modal('hide');
    // this.organisationService.updateBankingViewList(this.bankingViewList[index], this.formEditBanking);
  }

  updateBankingAddList(index) {
    if (!this.formEditBanking.valid) {
      this.helperService.markFormGroupTouched(this.formEditBanking);
      this.showErrorAddBank = true;
      return;
    }
    this.showErrorAddBank = false;
    $('#modalEditBankAddAcount').modal('hide');
    // this.organisationService.updateBankingViewList(this.bankingAddList[index], this.formEditBanking);
  }

  updateBanking() {
    const params = this.organisationService.getParamUpdateBanking(this.companyDetail, this.companyId, this.bankingViewList, this.bankingAddList);
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.bankStatus = false;
      this.showErrorAddBank = false;
      this.bankingAddList = [];
      this.helperService.hideLoading();
    });

  }

  cancelSaveSuperFund() {
    const superFundId = _.get(this.companyDetail.references, `${this.companyId}.SuperFunds`);
    if (superFundId) {
      this.superFundViewList = [];
      superFundId.forEach(element => {
        this.superFundViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }

    this.superFundAddList = [];
    this.superFundStatus = false;
    this.showErrorAddSuperFund = false;
  }

  addSuperFundList() {
    if (!this.formAddSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formAddSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    this.superFund = _.merge(this.superFund, this.formAddSuperFund.value);
    this.superFundAddList.push(this.superFund);
    this.superFund = new SuperFund();
    this.formAddSuperFund.reset();
    $('#modalAddFund').modal('hide');
  }

  getSuperFundInSuperFundList(type, index) {
    if (type === 'view') {
      this.superFundEdit = _.clone(this.superFundViewList[index]);
      this.superFundChooseIndex = index;
    } else {
      this.superFundEdit = _.clone(this.superFundAddList[index]);
      this.superFundChooseIndex = index;
    }
    this.customFormEditSuperFund();
  }

  updateSuperFundViewList(index) {
    if (!this.formEditSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formEditSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    $('#modalEditFundView').modal('hide');
    this.superFundViewList[index].EmployeeNo = this.formEditSuperFund.value.EmployeeNo;
    this.superFundViewList[index].FundABN = this.formEditSuperFund.value.FundABN;
    this.superFundViewList[index].FundName = this.formEditSuperFund.value.FundName;
  }

  updateSuperFundAddList(index) {
    if (!this.formEditSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formEditSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    $('#modalEditFundAdd').modal('hide');
    this.superFundAddList[index].EmployeeNo = this.formEditSuperFund.value.EmployeeNo;
    this.superFundAddList[index].FundABN = this.formEditSuperFund.value.FundABN;
    this.superFundAddList[index].FundName = this.formEditSuperFund.value.FundName;
  }

  updateSuperFund() {
    const superFundNew = Object.assign({}, this.superFundAddList);
    const organisation = _.clone(this.companyDetail.references);
    const path = this.companyId + '.SuperFunds';

    let superFundKey = _.keys(superFundNew);
    const superFund = _.get(organisation, path);
    if (superFund) {
      superFundKey = _.concat(superFund, _.keys(superFundNew));

      superFund.forEach(element => {
        const superFundSet = _.find(this.superFundViewList, ['ObjectID', (_.get(this.companyDetail.references, element)).ObjectID]);
        _.set(organisation, element, superFundSet);
      });
    }

    _.set(organisation, path, superFundKey);

    const params = {
      'environment': 'qa',
      'create': superFundNew,
      'update': organisation,
      'delete': {}
    }
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.superFundStatus = false;
      this.showErrorAddSuperFund = false;
      this.superFundAddList = [];
      this.helperService.hideLoading();
    });
  }

  cancelSaveLogo() {
    this.uploader.clearQueue();
    this.logoTokenList = [];
    this.logoDeleteList = [];
    this.logoStatus = false;

    const logoId = _.get(this.companyDetail.references, `${this.companyId}.Logos`);
    if (logoId) {
      this.logoViewList = [];
      logoId.forEach(element => {
        this.logoViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }
  }

  cancelChooseLogo() {
    $('#fileControl').val('');
    this.uploader.queue.forEach(item => {
      if (!item.isUploaded) {
        item.remove();
      }
    });
  }

  deleteLogo(index, type) {
    if (type === 'view') {
      this.logoDeleteList.push(this.logoViewList[index]);
      this.logoViewList.splice(index, 1);
    } else {
      this.logoTokenList.splice(index, 1);

      this.uploader.queue.forEach((item, aIndex) => {
        if (aIndex === index) {
          item.remove();
        }
      });
    }
  }

  uploadLogo() {
    $('#fileControl').val('');
    this.uploader.queue.forEach(item => {
      if (!item.isUploaded) {
        item.upload();
      }
    });

    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      if (response) {
        const responsePath = JSON.parse(response);
        this.zone.run(() => {
          const data = new LogoUpload();
          data.Logo.FileToken = responsePath.files[0].token;
          this.logoTokenList.push(data);
          $('#modalAddLogo').modal('hide');
        });
      }
    };
  }

  updateLogo() {
    const logoNew = Object.assign({}, this.logoTokenList);
    const logoDel = Object.assign({}, this.logoDeleteList);
    const organisation = _.clone(this.companyDetail.references);
    const path = this.companyId + '.Logos';

    let logoKey = _.keys(logoNew);
    const logos = _.get(organisation, path);
    if (logos) {
      logoKey = _.concat(logos, _.keys(logoNew));

      logos.forEach(element => {
        const logoSet = _.find(this.logoTokenList, ['ObjectID', (_.get(this.companyDetail.references, element)).ObjectID]);
        _.set(organisation, element, logoSet);
      });
    }
    _.set(organisation, path, logoKey);

    const params = {
      'create': logoNew,
      'update': organisation,
      'delete': logoDel
    };
    
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.uploader.clearQueue();
      this.logoTokenList = [];
      this.logoDeleteList = [];
      this.logoStatus = false;
      this.helperService.hideLoading();
    });
  }
}
