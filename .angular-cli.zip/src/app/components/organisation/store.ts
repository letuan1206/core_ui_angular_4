import { tassign } from 'tassign';
import * as constant from './actions';

export interface OrganisationState {
    age: number;
}

export const ORGANISATION_INITAL_STATE: OrganisationState = {
    age: 0
};

function incrementAge(state, action) {
    return tassign(state, { age: state.age + 1 });
}

export function organisationReducer(state = ORGANISATION_INITAL_STATE, action): OrganisationState {
    switch (action.type) {
        case constant.ORGANISATION_ACTION: return incrementAge(state, action);
    }

    return state;
}
