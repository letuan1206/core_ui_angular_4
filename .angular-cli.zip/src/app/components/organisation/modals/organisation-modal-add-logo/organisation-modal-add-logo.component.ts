import { LogoUpload } from './../../../../models/organisation';
import { OrganisationService } from './../../organisation.service';
import { ConfigService } from './../../../../services/config.service';
import { FileUploader } from 'ng2-file-upload';
import { Component, OnInit, NgZone, EventEmitter, Output, Input } from '@angular/core';
import * as _ from 'lodash';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-organisation-modal-add-logo',
  templateUrl: './organisation-modal-add-logo.component.html',
  styleUrls: ['./organisation-modal-add-logo.component.scss']
})
export class OrganisationModalAddLogoComponent implements OnInit {
  @Output() sendUploader: EventEmitter<any> = new EventEmitter();
  @Output() sendLogoToken: EventEmitter<any> = new EventEmitter();
  @Input('logoTokenList') logoTokenList: LogoUpload[] = [];
  @Input('uploader') uploader: FileUploader;
 
  constructor(private organisationService: OrganisationService, private zone: NgZone, private configService: ConfigService) {
    this.uploader = new FileUploader({ url: configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };
  }

  ngOnInit() {
  }

  cancelChooseLogo() {
    $('#fileControl').val('');
    this.uploader.queue.forEach(item => {
      if (!item.isUploaded) {
        item.remove();
      }
    });
    this.sendUploader.emit(this.uploader);
  }

  uploadLogo() {
    $('#fileControl').val('');
    this.uploader.queue.forEach(item => {
      if (!item.isUploaded) {
        item.upload();
      }
    });

    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      if (response) {
        const responsePath = JSON.parse(response);
        this.zone.run(() => {
          const data = new LogoUpload();
          data.Logo.FileToken = responsePath.files[0].token;
          this.logoTokenList.push(data);
          $('#modalAddLogo').modal('hide');
          this.sendUploader.emit(this.uploader);
          this.sendLogoToken.emit(this.logoTokenList);
        });
      }
    };
  }

}
