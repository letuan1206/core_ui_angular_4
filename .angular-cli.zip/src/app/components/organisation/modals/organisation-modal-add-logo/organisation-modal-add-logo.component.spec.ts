import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganisationModalAddLogoComponent } from './organisation-modal-add-logo.component';

describe('OrganisationModalAddLogoComponent', () => {
  let component: OrganisationModalAddLogoComponent;
  let fixture: ComponentFixture<OrganisationModalAddLogoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrganisationModalAddLogoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrganisationModalAddLogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
