import { HelperService } from './../../../services/helper.service';
import { textMask } from './../../common/constants';
import { FileUploader } from 'ng2-file-upload';
import { ConfigService } from './../../../services/config.service';
import { Observable } from 'rxjs/Observable';
import { Organisation, Address, Banking, SuperFund, Logo, LogoUpload } from './../../../models/organisation';
import { OrganisationService } from './../organisation.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, NgZone, HostListener, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

import * as _ from 'lodash';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-organisation-detail',
  templateUrl: './organisation-detail.component.html',
  styleUrls: ['./organisation-detail.component.scss']
})
export class OrganisationDetailComponent implements OnInit, AfterViewInit {
  public uploader: FileUploader;

  formOrganisationDetail: FormGroup;
  formAddBanking: FormGroup;
  formEditBanking: FormGroup;
  formAddSuperFund: FormGroup;
  formEditSuperFund: FormGroup;

  private sub: any;

  companyResponse: any;
  companyId: any;
  companyDetail: any;
  addressId: any;
  postalAddressId: any;
  logoId: any;

  addressDetail: any;
  postalAddressDetail: any;
  logoList = [];

  organisation: Organisation;
  address1: Address;
  address2: Address;

  bankingViewList: Banking[] = [];
  bankingAddList: Banking[] = [];
  superFundViewList: SuperFund[] = [];
  superFundAddList: SuperFund[] = [];
  logoViewList: Logo[] = [];
  logoDeleteList: Logo[] = [];
  logoTokenList: LogoUpload[] = [];

  banking: Banking;
  bankingEdit: Banking;
  superFund: SuperFund;
  superFundEdit: SuperFund;

  bankingChooseIndex: number;
  superFundChooseIndex: number;

  bankStatus = false;
  superFundStatus = false;
  logoStatus = false;
  editCompanyStatus = true;
  canEdit = true;
  isActivate: boolean;

  // show error
  showErrorCompany = false;
  showErrorAddBank = false;
  showErrorAddSuperFund = false;

  public maskTaxFileNumber = textMask.maskTaxFileNumber;
  public maskPhoneNumber = textMask.maskPhoneNumber;
  public maskFaxNumber = textMask.maskFaxNumber;
  public maskBSBNumber = textMask.maskBSBNumber;
  public maskAccountNumber = textMask.maskAccountNumber;
  public maskFundABN = textMask.maskFundABN;

  webRoot: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private organisationService: OrganisationService,
    private fb: FormBuilder,
    private zone: NgZone,
    private configService: ConfigService,
    private helperService: HelperService) {
    this.uploader = new FileUploader({ url: configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };
    this.webRoot = configService.get('webRoot');
    this.clearFieldOrganisation();
    this.banking = new Banking();
    this.bankingEdit = new Banking();
    this.superFund = new SuperFund();
    this.superFundEdit = new SuperFund();
  }

  ngOnInit() {
    this.sub = this.route.params.subscribe(param => {
      this.companyId = param['id'];
    });

    setTimeout(() => this.loadOrganisationDetail());

    this.customFormOrganisation();
    this.customFormAddBanking();
    this.customFormEditBanking();
    this.customFormAddSuperFund();
    this.customFormEditSuperFund();
    window.scrollTo(0, 0);


    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-1 ul li').each(function () {
        if ($('#section-2').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr("href-anchor"));
          if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-1 ul li a').removeClass("active-menu");
            currLink.addClass("active-menu");
          } else {
            currLink.removeClass("active-menu");
          }
        }
      });
    }

    if ($('#section-2').length) {
      $(document).on("scroll", onScroll);
    }


    $('.ancho-1 ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-1 ul li a').removeClass("active-menu");
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });


  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  @HostListener('window:keyup', ['$event'])

  keyEvent(event: KeyboardEvent) {
    if (event.keyCode === 27) {
      this.clearFieldBankAccount();
      this.clearFieldSuperFund();
    }
  }

  customFormOrganisation() {
    this.formOrganisationDetail = this.organisationService.renderFormOrganisation(this.organisation, this.address1, this.address2, this.editCompanyStatus);
  }

  customFormAddBanking() {
    this.formAddBanking = this.organisationService.renderFormBanking(this.banking);
  }

  customFormEditBanking() {
    this.formEditBanking = this.organisationService.renderFormBanking(this.bankingEdit);
  }

  customFormAddSuperFund() {
    this.formAddSuperFund = this.organisationService.renderFormSuperFund(this.superFund);
  }

  customFormEditSuperFund() {
    this.formEditSuperFund = this.organisationService.renderFormSuperFund(this.superFundEdit);
  }

  editOrganisation() {
    if (!this.formOrganisationDetail.valid) {
      this.showErrorCompany = true;
      this.helperService.markFormGroupTouched(this.formOrganisationDetail);
      return;
    }
    this.showErrorCompany = false;
    this.helperService.showLoading();

    var params = this.organisationService.getParamEditOrganisation(this.companyDetail, this.companyId, this.formOrganisationDetail);
    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.changeStatusCompany();
      this.helperService.hideLoading();
    });
  }

  removeAllSpace(formGroup: FormGroup) {
    this.helperService.removeAllSpace(formGroup);
  }

  deactivateOrganisation(type) {
    var params = this.organisationService.getParamDeactivateOrganisation(this.companyDetail, this.companyId, type);

    this.helperService.showLoading();
    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      if (!type) {
        this.changeStatusCompany();
      }
      this.helperService.hideLoading();
    });
  }

  loadOrganisationDetail() {
    this.helperService.showLoading();
    this.organisationService.getOrganisationDetail(this.companyId, (res) => {
      this.companyDetail = res;
      this.organisation = _.clone(_.get(this.companyDetail.references, this.companyId));
      this.isActivate = this.organisation.Active || false;
      var addressId = _.get(this.companyDetail.references, `${this.companyId}.Address`);
      var postalAddressId = _.get(this.companyDetail.references, `${this.companyId}.PostalAddress`);

      this.address1 = _.clone(_.get(this.companyDetail.references, addressId));
      this.address2 = _.clone(_.get(this.companyDetail.references, postalAddressId));
      this.customFormOrganisation();
      var bankingId = _.get(this.companyDetail.references, `${this.companyId}.Banking`);
      if (bankingId) {
        this.bankingViewList = [];
        bankingId.forEach(element => {
          this.bankingViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }

      var superFundId = _.get(this.companyDetail.references, `${this.companyId}.SuperFunds`);
      if (superFundId) {
        this.superFundViewList = [];
        superFundId.forEach(element => {
          this.superFundViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }

      var logoId = _.get(this.companyDetail.references, `${this.companyId}.Logos`);
      if (logoId) {
        this.logoViewList = [];
        logoId.forEach(element => {
          this.logoViewList.push(_.clone(_.get(this.companyDetail.references, element)));
        });
      }
      this.helperService.hideLoading();
    });
  }

  cancelEditOrganisation() {
    this.router.navigate(['/organisation']);
    // this.organisation = _.clone(_.get(this.companyDetail.references, this.companyId));
    // var addressId = _.get(this.companyDetail.references, `${this.companyId}.Address`);
    // var postalAddressId = _.get(this.companyDetail.references, `${this.companyId}.PostalAddress`);

    // this.address1 = _.clone(_.get(this.companyDetail.references, addressId));
    // this.address2 = _.clone(_.get(this.companyDetail.references, postalAddressId));
    // this.changeStatusCompany();
    // this.customFormOrganisation();
    // this.showErrorCompany = false;
  }

  setFormFocus(form: FormGroup, formControlName) {
    return form.get(formControlName).touched;
  }

  clearFormEditOrganisation() {
    this.organisation = _.clone(_.get(this.companyDetail.references, this.companyId));
    var addressId = _.get(this.companyDetail.references, `${this.companyId}.Address`);
    var postalAddressId = _.get(this.companyDetail.references, `${this.companyId}.PostalAddress`);

    this.address1 = _.clone(_.get(this.companyDetail.references, addressId));
    this.address2 = _.clone(_.get(this.companyDetail.references, postalAddressId));
    this.customFormOrganisation();
    this.showErrorCompany = false;
  }

  clearFieldOrganisation() {
    this.organisation = new Organisation();
    this.address1 = new Address();
    this.address2 = new Address();
    this.showErrorCompany = false;
  }

  clearFieldBankAccount() {
    this.showErrorAddBank = false;
    this.formAddBanking.reset();
  }

  clearFieldSuperFund() {
    this.showErrorAddSuperFund = false;
    this.formAddSuperFund.reset();
  }

  changeStatusCompany() {
    this.editCompanyStatus = !this.editCompanyStatus;
    if (!this.editCompanyStatus) {
      this.formOrganisationDetail.enable();
    } else {
      this.formOrganisationDetail.disable();
    }
  }

  changeStatusByType(type) {
    if (!this.canEdit) {
      return;
    }
    if (type === 'banking') {
      this.bankStatus = !this.bankStatus;
    } else if (type === 'superFund') {
      this.superFundStatus = !this.superFundStatus;
    } else if (type === 'logo') {
      this.logoStatus = !this.logoStatus;
    }
  }

  cancelSaveBanking() {
    this.bankingViewList = _.differenceBy(this.bankingViewList, this.bankingAddList, 'ObjectID');
    var bankingId = _.clone(_.get(this.companyDetail.references, `${this.companyId}.Banking`));
    if (bankingId) {
      this.bankingViewList = [];
      bankingId.forEach(element => {
        this.bankingViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }

    this.bankingAddList = [];
    this.bankStatus = false;
    this.showErrorAddBank = false;
  }

  addBankingList() {
    if (!this.formAddBanking.valid) {
      this.helperService.markFormGroupTouched(this.formAddBanking);
      this.showErrorAddBank = true;
      return;
    }
    this.showErrorAddBank = false;
    this.banking = _.merge(this.banking, this.formAddBanking.value);
    // this.banking.BSB = this.banking.BSB.replace(/ /g, '');
    // this.banking.AccountNumber = this.banking.AccountNumber.replace(/ /g, '');
    this.bankingAddList.push(this.banking);
    this.banking = new Banking();
    this.formAddBanking.reset();
    $('#modalAddAcount').modal('hide');
  }

  getBankInBankingList(type, index) {
    if (type === 'view') {
      this.bankingEdit = _.clone(this.bankingViewList[index]);
      this.bankingChooseIndex = index;
    } else {
      this.bankingEdit = _.clone(this.bankingAddList[index]);
      this.bankingChooseIndex = index;
    }
    this.customFormEditBanking();
  }

  updateBankingViewList(index) {
    if (!this.formEditBanking.valid) {
      this.showErrorAddBank = true;
      this.helperService.markFormGroupTouched(this.formEditBanking);
      return;
    }
    this.showErrorAddBank = false;
    $('#modalEditBankViewAcount').modal('hide');
    this.organisationService.updateBankingViewList(this.bankingViewList[index], this.formEditBanking);
  }

  updateBankingAddList(index) {
    if (!this.formEditBanking.valid) {
      this.showErrorAddBank = true;
      this.helperService.markFormGroupTouched(this.formEditBanking);
      return;
    }
    this.showErrorAddBank = false;
    $('#modalEditBankAddAcount').modal('hide');
    this.organisationService.updateBankingViewList(this.bankingAddList[index], this.formEditBanking);
  }

  updateBanking() {
    var params = this.organisationService.getParamUpdateBanking(this.companyDetail, this.companyId, this.bankingViewList, this.bankingAddList);
    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.bankStatus = false;
      this.showErrorAddBank = false;
      this.bankingAddList = [];
      this.helperService.hideLoading();
    });

  }

  cancelSaveSuperFund() {
    var superFundId = _.get(this.companyDetail.references, `${this.companyId}.SuperFunds`);
    if (superFundId) {
      this.superFundViewList = [];
      superFundId.forEach(element => {
        this.superFundViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }
    this.showErrorAddSuperFund = false;
    this.superFundAddList = [];
    this.superFundStatus = false;
  }

  addSuperFundList() {
    if (!this.formAddSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formAddSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    this.superFund = _.merge(this.superFund, this.formAddSuperFund.value);
    this.superFundAddList.push(this.superFund);
    this.superFund = new SuperFund();
    this.formAddSuperFund.reset();
    $('#modalAddFund').modal('hide');
  }

  getSuperFundInSuperFundList(type, index) {
    if (type === 'view') {
      this.superFundEdit = _.clone(this.superFundViewList[index]);
      this.superFundChooseIndex = index;
    } else {
      this.superFundEdit = _.clone(this.superFundAddList[index]);
      this.superFundChooseIndex = index;
    }
    this.customFormEditSuperFund();
  }

  updateSuperFundViewList(index) {
    if (!this.formEditSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formEditSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    $('#modalEditFundView').modal('hide');
    this.superFundViewList[index].EmployeeNo = this.formEditSuperFund.value.EmployeeNo;
    this.superFundViewList[index].FundABN = this.formEditSuperFund.value.FundABN;
    this.superFundViewList[index].FundName = this.formEditSuperFund.value.FundName;
  }

  updateSuperFundAddList(index) {
    if (!this.formEditSuperFund.valid) {
      this.helperService.markFormGroupTouched(this.formEditSuperFund);
      this.showErrorAddSuperFund = true;
      return;
    }
    this.showErrorAddSuperFund = false;
    $('#modalEditFundAdd').modal('hide');
    this.superFundAddList[index].EmployeeNo = this.formEditSuperFund.value.EmployeeNo;
    this.superFundAddList[index].FundABN = this.formEditSuperFund.value.FundABN;
    this.superFundAddList[index].FundName = this.formEditSuperFund.value.FundName;
  }

  updateSuperFund() {
    var superFundNew = Object.assign({}, this.superFundAddList);
    var organisation = _.clone(this.companyDetail.references);
    var path = this.companyId + ".SuperFunds";

    var superFundKey = _.keys(superFundNew);
    var superFund = _.get(organisation, path);
    if (superFund) {
      superFundKey = _.concat(superFund, _.keys(superFundNew));

      superFund.forEach(element => {
        var superFundSet = _.find(this.superFundViewList, ['ObjectID', (_.get(this.companyDetail.references, element)).ObjectID]);
        _.set(organisation, element, superFundSet);
      });
    }

    _.set(organisation, path, superFundKey);

    var params = {
      'create': superFundNew,
      'update': organisation,
      'delete': {}
    };

    this.helperService.showLoading();
    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.superFundStatus = false;
      this.showErrorAddSuperFund = false;
      this.superFundAddList = [];
      this.helperService.hideLoading();
    });
  }

  cancelSaveLogo() {
    this.uploader.clearQueue();
    this.logoTokenList = [];
    this.logoDeleteList = [];
    this.logoStatus = false;

    var logoId = _.get(this.companyDetail.references, `${this.companyId}.Logos`);
    if (logoId) {
      this.logoViewList = [];
      logoId.forEach(element => {
        this.logoViewList.push(_.clone(_.get(this.companyDetail.references, element)));
      });
    }
  }

  deleteLogo(index, type) {
    if (type === 'view') {
      this.logoDeleteList.push(this.logoViewList[index]);
      this.logoViewList.splice(index, 1);
    } else {
      this.logoTokenList.splice(index, 1);

      this.uploader.queue.forEach((item, aIndex) => {
        if (aIndex === index) {
          item.remove();
        }
      });
    }
  }

  updateLogo() {
    var logoNew = Object.assign({}, this.logoTokenList);
    var logoDel = Object.assign({}, this.logoDeleteList);
    var organisation = _.clone(this.companyDetail.references);
    var path = this.companyId + ".Logos";

    var logoKey = _.keys(logoNew);
    var logos = _.get(organisation, path);
    if (logos) {
      logoKey = _.concat(logos, _.keys(logoNew));

      logos.forEach(element => {
        var logoSet = _.find(this.logoTokenList, ['ObjectID', (_.get(this.companyDetail.references, element)).ObjectID]);
        _.set(organisation, element, logoSet);
      });
    }
    _.set(organisation, path, logoKey);

    var params = {
      'create': logoNew,
      'update': organisation,
      'delete': logoDel
    };

    this.helperService.showLoading();

    this.organisationService.updateOrganisation(params, (res) => {
      this.loadOrganisationDetail();
      this.uploader.clearQueue();
      this.logoTokenList = [];
      this.logoDeleteList = [];
      this.logoStatus = false;
      this.helperService.hideLoading();
    });
  }

  getUploader(data: any): void {
    this.uploader = data;
  }

  getLogoTokenList(data: any): void {
    this.logoTokenList = data;
  }
}
