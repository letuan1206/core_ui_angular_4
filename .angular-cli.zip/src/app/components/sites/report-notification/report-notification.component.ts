import { RosteringService } from './../../rostering/rostering.service';
import { Site } from './../../../models/configuration';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ContactService } from './../../contact/contact.service';
import { ModalDirective } from 'ng2-bootstrap';
import { ReportNotification, NotificationReportTypeLink, ReportCategory } from './../../../models/report';
import { SitesService } from './../sites.service';
import { ConfigService } from './../../../services/config.service';
import { ApiService } from './../../../services/api.service';
import { HelperService } from './../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { ISubscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-report-notification',
  templateUrl: './report-notification.component.html',
  styleUrls: ['./report-notification.component.scss'],
  providers: [
    SitesService
  ]
})
export class ReportNotificationComponent implements OnInit {
  @ViewChild('modalDeleteReportNotification') public modalDeleteReportNotification: ModalDirective;
  @ViewChild('modalNotificationSetup') public modalNotificationSetup: ModalDirective;
  @ViewChild('modalSelectContact') public modalSelectContact: ModalDirective;
  @ViewChild('modalCustomContact') public modalCustomContact: ModalDirective;
  @ViewChild('modalSelectCategories') public modalSelectCategories: ModalDirective;

  siteId: string;
  siteDetail: Site;

  saveServiceSub: ISubscription;

  reportNotificationSiteDT: ReportNotification[] = [];
  reportNotificationClientDT: ReportNotification[] = [];
  deleteNotifi = {
    type: null,
    index: -1
  };

  reportForClient = false;

  frequenciesData = [];
  summaryTypesData = [];
  reportTypesData = [];
  reportCategories = [];
  dayOfWeeks = [];
  contactsData = [];
  categoriesData = [];
  categoriesAdd = [];

  formReportNotification: FormGroup;
  formCustomContact: FormGroup;

  reportNotificationModel: ReportNotification = new ReportNotification();
  notifiDescription = '';
  showReportType = false;
  reportCategoryCurrent: ReportCategory;
  isCheckAllDay = false;
  errorMessages: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
    private rosterService: RosteringService,
    private fb: FormBuilder,
    private contactService: ContactService,
    private siteService: SitesService,

  ) {
    this.route.params.subscribe(param => {
      this.siteId = param['siteId'];
    });
    this.formReportNotification = this.renderFormReportNotification(this.reportNotificationModel);
    this.formCustomContact = this.renderFormCustoms();
  }

  ngOnInit() {
    this.getReportNotifications();
    this.loadData();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  showModalNotificationSetup(typeShow) {
    this.reportNotificationModel = new ReportNotification();
    this.reportNotificationModel.SiteDetail = this.siteDetail;
    this.reportNotificationModel.ForClient = typeShow;
    this.reportForClient = typeShow;

    this.notifiDescription = '';
    this.changeSumaryType();
    this.formReportNotification = this.renderFormReportNotification(this.reportNotificationModel);
    this.resetSelectAllDayBox();
    this.modalNotificationSetup.show();
  }

  showModalConfirmDelete(type, index) {
    this.deleteNotifi = {
      type: type,
      index: index
    };

    this.modalDeleteReportNotification.show();
  }

  changeSumaryType() {
    let summaryType = _.find(this.summaryTypesData, s => s.ObjectID === this.formReportNotification.value.SummaryType)
    this.showReportType = false;
    if (summaryType && summaryType.AdditionalAttributes.Shortcuts !== 'CheckpointReport') {
      this.showReportType = true;
    }

    this.reportTypesData.forEach(element => {
      element.Selected = false;
      let sumaryTypeLink = _.find(this.reportNotificationModel.NotificationReportTypeLinksData, s => s.ReportType === element.ObjectID);
      element.SumaryTypeLink = _.cloneDeep(sumaryTypeLink);
      if (sumaryTypeLink && sumaryTypeLink.Selected) {
        element.Selected = true;
      }
    });
  }

  selectReportCategory(item) {
    this.helperService.showLoading();

    if (this.reportNotificationModel.ObjectID) {
      let params = {
        ReportType: item.ObjectID
      }

      if (!item.SumaryTypeLink) {
        let notificationReportTypeLink = new NotificationReportTypeLink();
        notificationReportTypeLink.Notification = this.reportNotificationModel.ObjectID;
        notificationReportTypeLink.ReportType = item.ObjectID;

        let paramsCreate = {
          create: {
            'NEW:1': notificationReportTypeLink
          },
          update: {},
          delete: {}
        }

        this.helperService.showLoading();
        this.apiService.saveService(paramsCreate).subscribe(res => {
          if (this.configService.successStatus === res.result) {
            notificationReportTypeLink.ObjectID = res.created['NEW:1'];

            if (this.reportNotificationModel.NotificationReportTypeLinks) {
              this.reportNotificationModel.NotificationReportTypeLinks.push(notificationReportTypeLink.ObjectID);
              this.reportNotificationModel.NotificationReportTypeLinksData.push(notificationReportTypeLink);
            }

            this.reportTypesData.forEach(element => {
              if (element.ObjectID === notificationReportTypeLink.ReportType) {
                element.SumaryTypeLink = notificationReportTypeLink;
              }
            });

            let paramsLink = {
              NotificationReportTypeLink: notificationReportTypeLink.ObjectID
            }

            new Promise((resolve, reject) => {
              Promise.all([
                this.siteService.getReportCategories(params),
                this.siteService.getNotificationCategoryLinks(paramsLink)
              ]).then(
                ([reportCategories, categoriesLink]) => {
                  this.categoriesData = this.contactService.getReferencesData(reportCategories);
                  let reportCategoriesLink = this.contactService.getReferencesData(categoriesLink);
                  this.categoriesData.forEach(element => {
                    element.NotificationCategoryLink = _.find(reportCategoriesLink, s => s.ReportCategory === element.ObjectID);

                    if (!element.NotificationCategoryLink) {
                      element.NotificationCategoryLink = {
                        ObjectClass: "prosek.orm.NotificationCategoryLink",
                        ReportCategory: element.ObjectID,
                        IsSummary: true,
                      }
                    }

                  });

                  this.modalSelectCategories.show();
                  this.helperService.hideLoading();
                }).catch(e => {
                  this.helperService.hideLoading();
                })
            });
          } else {
            this.helperService.hideLoading();
          }
        });

      } else {
        let paramsLink = {
          NotificationReportTypeLink: item.SumaryTypeLink.ObjectID
        }

        new Promise((resolve, reject) => {
          Promise.all([
            this.siteService.getReportCategories(params),
            this.siteService.getNotificationCategoryLinks(paramsLink)
          ]).then(
            ([reportCategories, categoriesLink]) => {
              this.categoriesData = this.contactService.getReferencesData(reportCategories);
              let reportCategoriesLink = this.contactService.getReferencesData(categoriesLink);
              this.categoriesData.forEach(element => {
                element.NotificationCategoryLink = _.find(reportCategoriesLink, s => s.ReportCategory === element.ObjectID);

                if (!element.NotificationCategoryLink) {
                  element.NotificationCategoryLink = {
                    ObjectClass: "prosek.orm.NotificationCategoryLink",
                    ReportCategory: element.ObjectID,
                    IsSummary: true,
                  }
                }
              });

              this.modalSelectCategories.show();
              this.helperService.hideLoading();
            }).catch(e => {
              this.helperService.hideLoading();
            })
        });
      }
    } else {
      let params = {
        ReportType: item.ObjectID
      }
      this.helperService.showLoading();
      this.siteService.getReportCategories(params).then(res => {
        this.categoriesData = this.contactService.getReferencesData(res);
        this.categoriesData.forEach(element => {
          if (!element.NotificationCategoryLink) {
            element.NotificationCategoryLink = {
              ObjectClass: "prosek.orm.NotificationCategoryLink",
              ReportCategory: element.ObjectID,
              IsSummary: true,
            }
          }
        });

        this.modalSelectCategories.show();
        this.helperService.hideLoading();

      });
    }

  }

  deleteNotification() {
    let reportNotify;

    if (this.deleteNotifi.type === 'site') {
      reportNotify = this.reportNotificationSiteDT[this.deleteNotifi.index];
    } else {
      reportNotify = this.reportNotificationClientDT[this.deleteNotifi.index];
    }

    let params = {
      create: {},
      update: {},
      delete: {
        'DELETE:1': reportNotify
      }
    }

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      if (this.configService.successStatus === res.result) {

        this.getReportNotifications();
        // if (this.deleteNotifi.type === 'site') {
        //   this.reportNotificationSiteDT.splice(1, this.deleteNotifi.index);
        // } else {
        //   this.reportNotificationClientDT.splice(1, this.deleteNotifi.index);
        // }

      }
      this.modalDeleteReportNotification.hide();
      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  editReportNotification(report, typeReport) {
    this.reportNotificationModel = report;
    this.reportForClient = typeReport;

    this.notifiDescription = this.reportNotificationModel.Description;
    this.formReportNotification = this.renderFormReportNotification(this.reportNotificationModel);
    this.changeSumaryType();
    this.resetSelectAllDayBox();

    if (this.reportNotificationModel.ReportDays && this.reportNotificationModel.ReportDays.length === this.dayOfWeeks.length) {
      this.isCheckAllDay = true;
    }

    this.dayOfWeeks.forEach(element => {
      if (this.reportNotificationModel.ReportDays && this.reportNotificationModel.ReportDays.length) {
        if (this.reportNotificationModel.ReportDays.indexOf(element.Value) !== -1) {
          element.isCheck = true;
        }
      }
    });

    this.modalNotificationSetup.show();
  }

  getContactList() {
    this.helperService.showLoading();
    let params: any;
    if (!this.reportForClient) {
      params = {
        Site: this.siteId
      }
    } else {
      params = {
        Client: this.siteDetail.Client
      }
    }

    this.contactService.getContacts(params).then(res => {
      let dataArr = this.contactService.getReferencesData(res);
      this.contactsData = dataArr;
      this.modalSelectContact.show();
      this.helperService.hideLoading();
    }, err => {
      this.helperService.hideLoading();
    })
  }

  selectContact(contact) {
    this.reportNotificationModel.ContactDetail = contact;
    this.modalSelectContact.hide();
  }

  customContact() {
    this.formCustomContact = this.renderFormCustoms();
    this.modalCustomContact.show();
  }

  saveCustomContact() {
    if (!this.formCustomContact.valid) {
      this.helperService.markFormGroupTouched(this.formCustomContact);
      return;
    }

    this.reportNotificationModel.AdHoc = true;
    this.reportNotificationModel.Contact = null;
    this.reportNotificationModel.ContactDetail = null;
    this.reportNotificationModel.CustomContactName = this.formCustomContact.value.Name;
    this.reportNotificationModel.CustomContactEmail = this.formCustomContact.value.Email;

    this.modalCustomContact.hide();
  }

  addCategories() {

    this.categoriesData.forEach(element => {
      _.remove(this.categoriesAdd, s => s.ReportCategory === element.NotificationCategoryLink.ReportCategory);
      this.categoriesAdd.push(element.NotificationCategoryLink);
    });

    // this.categoriesAdd = _.uniqBy(this.categoriesAdd, 'ReportCategory');
    this.modalSelectCategories.hide();
  }

  saveNotification() {
    if (!this.formReportNotification.valid) {
      this.helperService.markFormGroupTouched(this.formReportNotification);
      return;
    }

    this.reportNotificationModel.SummaryType = this.formReportNotification.value.SummaryType;
    this.reportNotificationModel.Name = this.formReportNotification.value.Name;
    this.reportNotificationModel.StartDateTime = moment(this.formReportNotification.value.StartDateTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.reportNotificationModel.CutoffTime = moment(this.formReportNotification.value.CutoffTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.reportNotificationModel.ReportTime = moment(this.formReportNotification.value.ReportTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.reportNotificationModel.NoOfHours = parseInt(this.formReportNotification.value.NoOfHours);
    this.reportNotificationModel.Frequency = this.formReportNotification.value.Frequency;
    this.reportNotificationModel.Description = this.notifiDescription;
    this.reportNotificationModel.Site = this.siteId;
    this.reportNotificationModel.ReportDays = [];

    this.dayOfWeeks.forEach(element => {
      if (element.isCheck) {
        this.reportNotificationModel.ReportDays.push(element.Value);
      }
    });

    if (this.reportNotificationModel.ContactDetail) {
      this.reportNotificationModel.Contact = this.reportNotificationModel.ContactDetail.ObjectID;
    }

    delete this.reportNotificationModel.NotificationReportTypeLinksData;
    delete this.reportNotificationModel.NotificationReportTypeLinks;
    delete this.reportNotificationModel.SummaryTypeDetail;
    // delete this.reportNotificationModel.SiteDetail;
    delete this.reportNotificationModel.ContactDetail;
    // delete this.reportNotificationModel.Description;


    let params: any = {};

    if (this.reportNotificationModel.ObjectID) {
      let notificationReportTypeLinkAdd: NotificationReportTypeLink[] = [];
      let notificationReportTypeLinkUpdate: NotificationReportTypeLink[] = [];

      this.reportTypesData.forEach(element => {
        if (element.SumaryTypeLink) {
          let item = _.cloneDeep(element.SumaryTypeLink);
          delete item.ReportTypeDetail;
          item.Selected = element.Selected;

          notificationReportTypeLinkUpdate.push(item);
        } else {
          let item: NotificationReportTypeLink = new NotificationReportTypeLink();
          item.ReportType = element.ObjectID;
          item.Selected = element.Selected;
          item.Notification = this.reportNotificationModel.ObjectID;
          notificationReportTypeLinkAdd.push(item);
        }
      });

      let createNotifi = Object.assign({}, notificationReportTypeLinkAdd);
      let updateNotifi = Object.assign({}, notificationReportTypeLinkUpdate);
      // let updateNotifi = _.mapValues(_.keyBy(notificationReportTypeLinkUpdate, 'ObjectID'))
      updateNotifi['UPDATE:1'] = this.reportNotificationModel;

      params = {
        create: {},
        update: updateNotifi,
        delete: {}
      }

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        if (this.configService.successStatus === res.result) {
          let categoriesAddList = [];
          let categoriesUpdateList = [];
          this.categoriesAdd.forEach(element => {
            let categoryReport = _.find(this.reportCategories, s => s.ObjectID === element.ReportCategory);
            let notificationLink = _.find(notificationReportTypeLinkUpdate, s => s.ReportType === categoryReport.ReportType);

            if (element.ObjectID) {
              categoriesUpdateList.push(element);
            } else {
              element.NotificationReportTypeLink = notificationLink.ObjectID;
              categoriesAddList.push(element);
            }
          });

          let createCategories = Object.assign({}, categoriesAddList);
          let updateCategories = _.mapValues(_.keyBy(categoriesUpdateList, 'ObjectID'))

          params = {
            create: createCategories,
            update: updateCategories,
            delete: {}
          }

          this.apiService.saveService(params).subscribe(res => {
            if (this.configService.successStatus === res.result) {
              this.categoriesAdd = [];
            }
          });

          this.getReportNotifications();
          this.modalNotificationSetup.hide();
        } else {
          this.helperService.hideLoading();
        }
      }, error => {
        this.helperService.hideLoading();
      });

    } else {
      params = {
        create: {
          'NEW:1': this.reportNotificationModel
        },
        update: {},
        delete: {}
      }

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        if (this.configService.successStatus === res.result) {

          let notificationReportTypeLinkAdd: NotificationReportTypeLink[] = [];

          this.reportTypesData.forEach(element => {
            let item: NotificationReportTypeLink = new NotificationReportTypeLink();
            item.ReportType = element.ObjectID;
            item.Selected = element.Selected;
            item.Notification = res.created['NEW:1'];
            notificationReportTypeLinkAdd.push(item);
          });

          let createNotifi = Object.assign({}, notificationReportTypeLinkAdd);

          params = {
            create: createNotifi,
            update: {},
            delete: {}
          }

          this.apiService.saveService(params).subscribe(res => {
            if (this.configService.successStatus === res.result) {
              notificationReportTypeLinkAdd.forEach((element, index) => {
                element.ObjectID = res.created[index];
              });

              this.categoriesAdd.forEach(element => {
                let categoryReport = _.find(this.reportCategories, s => s.ObjectID === element.ReportCategory);
                let notificationLink = _.find(notificationReportTypeLinkAdd, s => s.ReportType === categoryReport.ReportType);
                element.NotificationReportTypeLink = notificationLink.ObjectID;
              });

              let createCategories = Object.assign({}, this.categoriesAdd);

              params = {
                create: createCategories,
                update: {},
                delete: {}
              }

              this.apiService.saveService(params).subscribe(res => {
                if (this.configService.successStatus === res.result) {
                  this.categoriesAdd = [];
                } else {
                }
              });

              this.getReportNotifications();
              this.modalNotificationSetup.hide();

            } else {
              this.errorMessages = res.errorDetails;
              this.helperService.hideLoading();
            }
          });
        } else {
          this.errorMessages = res.errorDetails;
          this.helperService.hideLoading();
        }
      }, error => {
        this.helperService.hideLoading();
      });
    }


  }

  renderFormReportNotification(report: ReportNotification) {
    let form = this.fb.group({
      SummaryType: [report.SummaryType, [Validators.required]],
      Name: [report.Name, [Validators.required]],
      StartDateTime: [report.StartDateTime ? moment(report.StartDateTime).utc().format('YYYY-MM-DDTHH:mm:ss.SSS') : null, [Validators.required]],
      CutoffTime: [report.CutoffTime ? moment(report.CutoffTime).utc().format('YYYY-MM-DDTHH:mm:ss.SSS') : null],
      NoOfHours: [report.NoOfHours, [Validators.required]],
      ReportTime: [report.ReportTime ? moment(report.ReportTime).utc().format('YYYY-MM-DDTHH:mm:ss.SSS') : null],
      Frequency: [report.Frequency ? report.Frequency.Value : null, [Validators.required]],
    });
    return form;
  }

  renderFormCustoms() {
    let form = this.fb.group({
      Name: ['', [Validators.required]],
      Email: ['', [Validators.required, Validators.email]],
    });
    return form;
  }

  checkSelectAllDay() {
    if (!this.isCheckAllDay) {
      this.dayOfWeeks.forEach(element => {
        element.isCheck = true;
      });
    } else {
      this.resetSelectAllDayBox();
    }
  }

  resetSelectAllDayBox() {
    this.isCheckAllDay = false;
    this.dayOfWeeks.forEach(element => {
      element.isCheck = false;
    });
  }

  changeDayStatus(index) {
    this.dayOfWeeks[index].isCheck = !this.dayOfWeeks[index].isCheck;
    this.checkStatusSelectAllDay();
  }

  checkStatusSelectAllDay() {
    let numDays = this.dayOfWeeks.filter(element => element.isCheck === false);

    if (numDays.length) {
      this.isCheckAllDay = false;
    } else {
      this.isCheckAllDay = true;
    }
  }

  loadData() {
    new Promise((resolve, reject) => {
      Promise.all([
        this.siteService.getSummaryTypes(),
        this.siteService.getFrequencies(),
        this.siteService.getDetailSite(this.siteId),
        this.siteService.getReportTypes(),
        this.siteService.getReportCategories({}),
        this.rosterService.getDayOfWeekTypes(),
      ]).then(
        ([summaryTypes, frequencies, siteDetail, reportTypes, reportCategory, dayOfWeeks]) => {
          this.summaryTypesData = this.contactService.getReferencesData(summaryTypes);
          this.reportTypesData = this.contactService.getReferencesData(reportTypes);
          this.reportCategories = this.contactService.getReferencesData(reportCategory);
          this.dayOfWeeks = dayOfWeeks.results;

          this.frequenciesData = frequencies.results;
          this.siteDetail = _.get(siteDetail.references, siteDetail.results[0]);
        }).catch(e => {
        })
    });
  }

  getReportNotifications() {
    this.helperService.showLoading();
    let params = {
      Site: this.siteId
    };
    this.siteService.getReportNotifications(params).then(res => {
      let dataSiteArr = [];
      let dataClientArr = [];

      res.results.forEach(element => {
        let rpn: ReportNotification = _.get(res.references, element);
        rpn.ContactDetail = _.get(res.references, rpn.Contact);
        rpn.SiteDetail = _.get(res.references, rpn.Site);
        rpn.SummaryTypeDetail = _.get(res.references, rpn.SummaryType);
        rpn.NotificationReportTypeLinksData = [];

        if (rpn.NotificationReportTypeLinks) {
          rpn.NotificationReportTypeLinks.forEach(element => {
            let rpnTypeLink = _.get(res.references, element);
            rpnTypeLink.ReportTypeDetail = _.find(this.reportTypesData, s => s.ObjectID === rpnTypeLink.ReportType);
            rpn.NotificationReportTypeLinksData.push(rpnTypeLink);
          });
        }

        if (rpn.ForClient) {
          dataClientArr.push(rpn);
        } else {
          dataSiteArr.push(rpn);
        }
      });

      this.reportNotificationSiteDT = dataSiteArr;
      this.reportNotificationClientDT = dataClientArr;
      this.helperService.hideLoading();
    }, err => {
      this.helperService.hideLoading();
    });
  }
}
