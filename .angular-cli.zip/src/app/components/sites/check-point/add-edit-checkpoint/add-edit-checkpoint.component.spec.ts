import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditCheckpointComponent } from './add-edit-checkpoint.component';

describe('AddEditCheckpointComponent', () => {
  let component: AddEditCheckpointComponent;
  let fixture: ComponentFixture<AddEditCheckpointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddEditCheckpointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditCheckpointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
