import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
import * as _ from 'lodash';
import { Observable } from 'rxjs/Observable';

// Services
import { ConfigService } from '../../../../services/config.service';
import { CommonService } from '../../../../services/common.service';
import { HelperService } from '../../../../services/helper.service';
import { ApiService } from '../../../../services/api.service';

// Interfaces
import { ObjectAddress } from '../../../../interfaces/clients-interface';

@Component({
  selector: 'app-add-edit-checkpoint',
  templateUrl: './add-edit-checkpoint.component.html',
  styleUrls: ['./add-edit-checkpoint.component.scss']
})
export class AddEditCheckpointComponent implements OnInit {

  @ViewChild('addOrEditCheckpointModal') public addOrEditCheckpointModal: ModalDirective;
  @Output() saveCheckpointSuccessed = new EventEmitter<boolean>();

  statusOptions: any;

  checkpointData: any;

  scannedTypesOptions: any;
  checkpointMonitoringOptions: any;
  extraScanOptions: any;
  locationDetail: any;

  actionType: string;
  types: any = [];
  client: any = {};
  clientId: string;
  contact: any = {};
  contactId: string;
  site: any = {};
  siteId: string;
  activityStatuses: any = [];

  checkpointForm: FormGroup;

  isChangedValue: boolean = false;


  constructor(
    private configService: ConfigService,
    private commonService: CommonService,
    private helperService: HelperService,
    private apiService: ApiService
  ) {
  }

  ngOnInit() {
    this.initForm();
  }

  async initParams(siteId, actionsType: any, checkpointObjectID: any) {
    this.siteId = siteId;
    this.actionType = actionsType;
    this.getStatus();
    this.getCheckpointMonitorTypes();
    this.getScannedOptions();
    this.getExtraScanOptions();
    // }
    if (actionsType === 'create') {
      this.initForm();
    } else {
      await this.getCheckpointDetail(checkpointObjectID);
      this.initFormWithValue();
    }
  }

  // get current location
  private scanLocation() {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position: any) => {
        this.locationDetail = position.coords;
        this.checkpointForm.patchValue({ location: `Latitude: ${position.coords.latitude}, Longitude: ${position.coords.longitude}` })
      }, err => {
        console.log(err);
      });
    }
  }


  initForm() {
    this.checkpointForm = new FormGroup({
      status: new FormControl("", Validators.required),
      name: new FormControl("", Validators.required),
      scannedType: new FormControl("", Validators.required),
      locatedAt: new FormControl(""),
      checkpointMonitoring: new FormControl("", Validators.required),
      extraScan: new FormControl("", Validators.required),
      code: new FormControl(""),
      location: new FormControl("", Validators.required),
      accuracy: new FormControl("")
    });
    this.checkpointForm.valueChanges.subscribe((value) => {
      this.isChangedValue = true;
    });
  }

  initFormWithValue() {
    this.checkpointForm = new FormGroup({
      status: new FormControl(this.checkpointData.CheckPointStatus.Value, Validators.required),
      name: new FormControl(this.checkpointData.Name, Validators.required),
      scannedType: new FormControl(this.checkpointData.ScannedBy.Value, Validators.required),
      locatedAt: new FormControl(this.checkpointData.LocatedAt),
      checkpointMonitoring: new FormControl(this.checkpointData.Monitor.Value, Validators.required),
      extraScan: new FormControl(this.checkpointData.ExtraScan.Value, Validators.required),
      code: new FormControl(this.checkpointData.NSCQRCode),
      location: new FormControl(`Latitude: ${this.checkpointData.Latitude}, Longitude: ${this.checkpointData.Longitude}`, Validators.required),
      accuracy: new FormControl(this.checkpointData.GPSAccuracy)
    });
    this.checkpointForm.valueChanges.subscribe((value) => {
      this.isChangedValue = true;
    });
  }

  // Reset Value when close modal
  handler(type: string, $event: ModalDirective) {
    this.isChangedValue = false;
  }

  async getCheckpointDetail(checkpointObjectID) {
    let dataCheckpoint = await this.commonService.queryById('/CheckPoints', checkpointObjectID);
    try {
      if (dataCheckpoint.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.checkpointData = _.get(dataCheckpoint.references, dataCheckpoint.results[0]);
      this.locationDetail = {
        latitude: this.checkpointData.latitude,
        longitude: this.checkpointData.longitude
      }
    } catch (error) {

    }
  }

  async getStatus() {
    let dataStatus = await this.commonService.queryAllData('/CheckPointStatuses');
    try {
      if (dataStatus.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.statusOptions = dataStatus.results;
    } catch (error) {

    }

  }

  async getCheckpointMonitorTypes() {
    let dataMonitorType = await this.commonService.queryAllData('/CheckPointMonitorTypes ');
    try {
      if (dataMonitorType.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.checkpointMonitoringOptions = dataMonitorType.results;
    } catch (error) {

    }

  }

  async getScannedOptions() {
    let data = await this.commonService.queryAllData('/ScannedByTypes');
    try {
      if (data.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.scannedTypesOptions = data.results;
    } catch (error) {

    }
  }

  async getExtraScanOptions() {
    let data = await this.commonService.queryAllData('/ExtraScanTypes');
    try {
      if (data.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.extraScanOptions = data.results;
    } catch (error) {

    }
  }


  // Add checkpoint
  async addCheckpoint(form) {
    if (form.valid === false || !this.locationDetail) {
      return;
    }
    try {
      this.helperService.showLoading();
      let data = {
        "ObjectClass": "prosek.orm.CheckPoint",
        "Name": form.value.name,
        "ScannedBy": _.find(this.scannedTypesOptions, { Value: form.value.scannedType }),
        "CheckPointStatus": _.find(this.statusOptions, { Value: form.value.status }),
        "LocatedAt": form.value.locatedAt,
        "Monitor": form.value.checkpointMonitoring,
        "ExtraScan": _.find(this.extraScanOptions, { Value: form.value.extraScan }),
        "NSCQRCode": form.value.code,
        "GPSAccuracy": form.value.accuracy,
        "GPSLocation": `Latitude: ${this.locationDetail.latitude || this.checkpointData.Longitude}, Longitude: ${this.locationDetail.longitude || this.checkpointData.Latitude}`,
        "Longitude": this.locationDetail.longitude || this.checkpointData.Longitude,
        "Latitude": this.locationDetail.latitude || this.checkpointData.Latitude,
        "Site": this.siteId
      }
      let params = {
        update: {},
        create: {}
      }
      if (this.actionType === 'create') {
        params.create["NEW 1"] = data
      } else {
        data["ObjectID"] = this.checkpointData.ObjectID;
        params.update[this.checkpointData.ObjectID] = data
      }
      let updateResult = await this.apiService.saveService(params).toPromise();
      this.helperService.hideLoading();
      if (updateResult.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveCheckpointSuccessed.emit(true);
      this.hide();
    } catch (error) {
      console.log(error);
    }


  }

  // Delete Checkpoint
  async deleteCheckpoint() {
    try {
      this.helperService.showLoading();
      let params = {
        delete: {}
      }
      let data = {
        "ObjectClass": "prosek.orm.CheckPoint",
        "ObjectID": this.checkpointData.ObjectID,
        "Site": this.siteId
      }
      params.delete[this.checkpointData.ObjectID] = data
      let deleteResult = await this.apiService.saveService(params).toPromise();
      this.helperService.hideLoading();
      if (deleteResult.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveCheckpointSuccessed.emit(true);
      this.hide();
    } catch (error) {
      console.log(error);
    }
  }


  //#region modal actions
  public show() {
    this.addOrEditCheckpointModal.show();
  }

  public hide() {
    this.addOrEditCheckpointModal.hide();
  }
  //#endregion

}
