import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivationEnd } from '@angular/router';
import { ModalDirective } from 'ng2-bootstrap';
import * as moment from 'moment';
import { } from '@types/googlemaps';
import * as _ from 'lodash';

// Services
import { SitesService } from '../sites.service';
import { HelperService } from '../../../services/helper.service';
import { ApiService } from '../../../services/api.service';
import { ConfigService } from '../../../services/config.service';

// Components
import { AddEditCheckpointComponent } from './add-edit-checkpoint/add-edit-checkpoint.component'


@Component({
  selector: 'app-check-point',
  templateUrl: './check-point.component.html',
  styleUrls: ['./check-point.component.scss']
})
export class CheckPointComponent implements OnInit {
  @ViewChild('addOrEditCheckpointModal') addOrEditCheckpointModal: AddEditCheckpointComponent;
  @ViewChild('viewMapModal') viewMapModal: ModalDirective;
  @ViewChild('gmap') gmapElement: any;
  public map: google.maps.Map;

  checkpointArr: any = [];
  siteID: string;
  siteDetail: any;

  isShowDisabled: boolean = false;

  constructor(
    private siteSerive: SitesService,
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService
  ) { }

  async ngOnInit() {
    let params = await this.route.params.first().toPromise();
    this.siteID = params.siteId;

    this.loadDataCheckpoint();
    this.siteSerive.getDetailSite(this.siteID).then(res => {
      this.siteDetail = _.get(res.references, res.results[0]);
    });
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  async loadDataCheckpoint() {
    this.helperService.showLoading();
    try {
      let params = {
        Site: this.siteID,
        ShowDisabled: this.isShowDisabled
      }
      let asyncCheckpointData = await this.siteSerive.getCheckpointByParams(params);
      if (asyncCheckpointData.result === this.configService.successStatus) {
        this.checkpointArr = this.helperService.getReferenceDataByObjId(asyncCheckpointData.results, asyncCheckpointData.references);
        this.checkpointArr.forEach(element => {
          element.LocationReadOn = element.LocationReadOn ? moment(element.LocationReadOn).format("DD MMM YYYY hh:mm") : element.LocationReadOn;
        });
      } else {
        throw Error('error');
      }
      this.helperService.hideLoading();
    } catch (e) {
      this.helperService.hideLoading();
      this.helperService.handleError(e);
    }
  }

  handleRowClick(event) {
    console.log(event);
  }

  // Event when save successfully
  saveCheckpointSuccessed(event) {
    if (event) {
      this.checkpointArr = [];
      this.loadDataCheckpoint();
    }
  }

  // Open modal Create Checkpoint
  openModalCreateCheckpoint(type, checkpointObjectID) {
    this.addOrEditCheckpointModal.initParams(this.siteID, type, checkpointObjectID);
    this.addOrEditCheckpointModal.show();
  }

  // init Map
  openModalViewMap(item) {
    this.viewMapModal.show();
    let locationData = {
      lat: item.Latitude,
      lng: item.Longitude
    }
    this.initMap(locationData);
  }

  closeMapModal() {
    this.viewMapModal.hide();
  }

  initMap(locationData) {
    let mapProp = {
      center: new google.maps.LatLng(locationData.lat, locationData.lng),
      zoom: 19,
      mapTypeId: google.maps.MapTypeId.SATELLITE
    };
    this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);
    var marker = new google.maps.Marker({
      position: locationData,
      map: this.map,
      title: 'Hello World!'
    });
  }
}
