import { Site } from './../../../models/configuration';
import { User } from './../../../models/user';
import { FileUploader } from 'ng2-file-upload';
import { ContactService } from './../../contact/contact.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Report, ReportPhoto } from './../../../models/report';
import { SitesService } from './../sites.service';
import { ConfigService } from './../../../services/config.service';
import { ApiService } from './../../../services/api.service';
import { HelperService } from './../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, NgZone, ViewChild, AfterViewInit } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';

import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-report-detail',
  templateUrl: './report-detail.component.html',
  styleUrls: ['./report-detail.component.scss']
})
export class ReportDetailComponent implements OnInit, AfterViewInit {
  @ViewChild(SignaturePad) signaturePad: SignaturePad;

  private signaturePadOptions: Object = {
    'minWidth': 5,
    'canvasWidth': 500,
    'canvasHeight': 300
  };

  reportId: any;
  reportDetail: Report = new Report();
  guardUser: User;
  site: Site;
  reportPhotos: ReportPhoto[] = [];
  reportPhotoAdd: ReportPhoto[] = [];

  reportPhotoDelete: ReportPhoto[] = [];

  public uploader: FileUploader;

  formReportDetail: FormGroup;
  subCategoriesData = [];
  categoriesData = [];
  subCategoriesFilter = [];

  enableBtnEdit = true;
  imageUrl: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
    private siteService: SitesService,
    private fb: FormBuilder,
    private contactService: ContactService,
    private zone: NgZone
  ) {
    this.uploader = new FileUploader({ url: configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => {
      file.withCredentials = true;

      this.uploadAttachment();
    };

    this.imageUrl = configService.get('webRoot');
    this.route.params.subscribe(param => {
      this.reportId = param['id'];
    });

    this.formReportDetail = this.renderFormReportDetail(this.reportDetail);
  }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.loadData();
  }

  ngAfterViewInit() {
    // this.signaturePad is now available
    this.signaturePad.set('minWidth', 1); // set szimek/signature_pad options at runtime
    this.signaturePad.clear(); // invoke functions from szimek/signature_pad API
    this.helperService.setThemeDefault();
  }

  drawComplete() {
    // will be notified of szimek/signature_pad's onEnd event
  }

  drawStart() {
    // will be notified of szimek/signature_pad's onBegin event
  }

  async downloadPDF() {

    this.helperService.showLoading();

    try {

      let data = await this.siteService.downnloadPDF(this.reportId);
      const file = new Blob([data], { type: 'application/pdf' });
      FileSaver.saveAs(file, `${new Date().toISOString()}.pdf`);
      this.helperService.hideLoading();

    } catch (e) {
      this.helperService.hideLoading();
    }

  }

  clearSignature() {
    if (this.enableBtnEdit) {
      return;
    }

    this.signaturePad.clear();
  }

  changeStatusEdit() {
    this.enableBtnEdit = !this.enableBtnEdit;

    this.setDisableForm();
  }

  deletePhotoByIndex(index, type) {
    if (type === 'edit') {
      this.reportPhotoDelete.push(_.cloneDeep(this.reportPhotos[index]));
      this.reportPhotos.splice(index, 1);
    } else {
      this.reportPhotoAdd.splice(index, 1);
      if (this.uploader.queue.length) {
        this.uploader.queue.splice(index, 1);
      }
    }
  }

  setDisableForm() {
    if (this.enableBtnEdit) {
      setTimeout(() => {
        this.formReportDetail.disable();
        this.signaturePad.off();
      });
    } else {
      setTimeout(() => {
        this.formReportDetail.enable();
        this.signaturePad.on();
      });
    }
  }

  filterSubCategories(categoryId) {
    this.subCategoriesFilter = this.subCategoriesData.filter(s => s.Category === categoryId);
  };

  getReportDetail() {
    this.helperService.showLoading();
    this.siteService.getReportById(this.reportId).then(res => {
      this.reportDetail = _.get(res.references, res.results[0]);
      this.guardUser = _.get(res.references, this.reportDetail.GuardUser);
      this.site = _.get(res.references, this.reportDetail.Site);
      let dataTmp = [];
      if (this.reportDetail.FieldValues) {
        this.reportDetail.FieldValues.forEach(element => {
          let item = _.get(res.references, element);
          item.ReportFieldDetail = _.get(res.references, item.ReportField);
          dataTmp.push(item);
        });
        this.reportDetail.FieldValuesDetail = dataTmp;
      }
      this.signaturePad.clear();
      this.signaturePad.fromDataURL(_.cloneDeep(this.reportDetail.Signature));

      this.reportPhotos = [];
      this.reportPhotoAdd = [];
      this.reportPhotoDelete = [];

      if (this.reportDetail.ReportPhotos) {
        this.reportDetail.ReportPhotos.forEach(element => {
          this.reportPhotos.push(_.get(res.references, element));
        });
      }

      this.filterSubCategories(this.reportDetail.ReportCategory);
      this.formReportDetail = this.renderFormReportDetail(this.reportDetail);
      this.setDisableForm();
      this.helperService.hideLoading();
    }, err => {
      this.helperService.hideLoading();
    });
  }

  loadData() {
    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.siteService.getReportCategories({}),
        this.siteService.getReportSubCategories(),
        // this.contactService.getClientManager(),
      ]).then(
        ([categories, subCategories]) => {
          this.categoriesData = this.contactService.getReferencesData(categories);
          this.subCategoriesData = this.contactService.getReferencesData(subCategories);

          this.getReportDetail();
        }).catch(e => {
          this.helperService.hideLoading();
        })
    });
  }

  cancelReport() {
    this.uploader.clearQueue();
    this.getReportDetail();
    this.changeStatusEdit();
  }

  saveReport() {
    let photoAdds = Object.assign({}, this.reportPhotoAdd);
    let photoDels = Object.assign({}, this.reportPhotoDelete);
    let fieldValueUpdate = Object.assign({}, this.reportDetail.FieldValuesDetail);

    this.reportDetail.Signature = this.signaturePad.toDataURL();
    this.reportDetail.ReportCategory = this.formReportDetail.value.ReportCategory;
    this.reportDetail.ReportSubCategory = this.formReportDetail.value.ReportSubCategory;
    this.reportDetail.Date = moment(this.formReportDetail.value.Date).format('YYYY-MM-DDT') + moment(this.formReportDetail.value.DateTime).format('HH:mm:ss.SSS[Z]');
    this.reportDetail.Time = moment(this.formReportDetail.value.Date).format('YYYY-MM-DDT') + moment(this.formReportDetail.value.DateTime).format('HH:mm:ss.SSS[Z]');
    let params = {
      create: photoAdds,
      update: {},
      delete: photoDels
    }

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      if (this.configService.successStatus === res.result) {
        this.reportPhotoAdd = [];
        this.reportPhotoDelete = [];
        this.uploader.clearQueue();

        let params = {
          create: {},
          update: fieldValueUpdate,
          delete: {}
        }

        params.update["UPDATE:1"] = _.cloneDeep(this.reportDetail);
        delete params.update["UPDATE:1"].ReportPhotos;

        this.apiService.saveService(params).subscribe(res => {
          if (this.configService.successStatus === res.result) {
            this.getReportDetail();
            this.changeStatusEdit();
          } else {
            this.helperService.hideLoading();
          }
        }, error => {
          this.helperService.hideLoading();
        });
      } else {
        this.helperService.hideLoading();
      }
    }, error => {
      this.helperService.hideLoading();
    });
  }

  uploadAttachment() {
    if (this.uploader.queue.length) {
      this.helperService.showLoading();
      this.uploader.queue.forEach(item => {
        if (!item.isUploaded) {
          item.upload();
        }
      });

      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          const responsePath = JSON.parse(response);
          this.zone.run(() => {

            const reportPhoto = new ReportPhoto();
            reportPhoto.Report = this.reportId;
            reportPhoto.Photo = {
              FileToken: responsePath.files[0].token
            };

            this.reportPhotoAdd.push(reportPhoto);

            this.helperService.hideLoading();
          });
        }
      };
    }
  }

  renderFormReportDetail(reportDetail: Report) {
    let form = this.fb.group({
      Date: [reportDetail.Date ? moment(reportDetail.Date).utc().format('YYYY-MM-DDTHH:mm:ss.SSS') : null],
      DateTime: [reportDetail.Date ? moment(reportDetail.Date).utc().format('YYYY-MM-DDTHH:mm:ss.SSS') : null],
      GuardUser: [reportDetail.GuardUser],
      Site: [reportDetail.Site],
      ReportCategory: [reportDetail.ReportCategory],
      ReportSubCategory: [reportDetail.ReportSubCategory],
      ClosedDate: [reportDetail.ClosedDate],
      Time: [reportDetail.Time],
    });

    // form.valueChanges.subscribe(s => {
    //   this.calculateBannedLifted();
    // })
    return form;
  }

}
