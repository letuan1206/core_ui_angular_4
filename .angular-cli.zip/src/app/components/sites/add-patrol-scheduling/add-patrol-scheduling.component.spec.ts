import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPatrolSchedulingComponent } from './add-patrol-scheduling.component';

describe('AddPatrolSchedulingComponent', () => {
  let component: AddPatrolSchedulingComponent;
  let fixture: ComponentFixture<AddPatrolSchedulingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPatrolSchedulingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPatrolSchedulingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
