import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';
import { HelperService } from '../../../services/helper.service';
import * as _ from 'lodash';
import { SitesService } from '../sites.service';
import { NgForm } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
@Component({
  selector: 'app-add-patrol-scheduling',
  templateUrl: './add-patrol-scheduling.component.html',
  styleUrls: ['./add-patrol-scheduling.component.scss']
})
export class AddPatrolSchedulingComponent implements OnInit {
  @ViewChild('form') patrolForm: NgForm;
  @ViewChild('modalConfirmRemove') modalConfirmRemove: ModalDirective;

  index : any;
  scannedByTypes: any = [];
  activeStatuses: any = [];
  scheduleTypes: any = [];
  dayOfWeekTypes: any = [];
  tourSchedules: any = [];
  removeTourSchedules: any = []

  patrolScheduling: any = {};
  constructor(private configService: ConfigService,
    private helperService: HelperService,
    private siteService: SitesService) { }

  ngOnInit() {
    this.getScannedByTypes();
    this.getPatrolStatuses();
    this.getScheduleTypes();
    this.getDayOfWeekTypes();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  async getDayOfWeekTypes() {
    try {
      let data = await this.siteService.getDayOfWeekTypes();
      if (data.result === this.configService.settings.status.success) {
        this.dayOfWeekTypes.push(null);
        for (let i in data.results) {
          this.dayOfWeekTypes.push(data.results[i]);
        }

      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }

  createObjectTourSchedules(tourSchedules, type) {
    let tourSchedulesObject: any = {
      EndTime: tourSchedules.EndTime ? new Date(this.helperService.convertDate(tourSchedules.EndTime)) : null,
      StartTime: tourSchedules.StartTime ? new Date(this.helperService.convertDate(tourSchedules.StartTime)) : null,
      StartDay: tourSchedules.StartDay,
      SitePatrolSchedule: tourSchedules.SitePatrolSchedule,
      ObjectID: tourSchedules.ObjectID,
      ObjectClass: 'prosek.orm.TourSchedule',
      Type: type,
    }
    return tourSchedulesObject;
  }

  async getPatrolSchedulingById(Id) {
    try {
      let data = await this.siteService.getPatrolSchedulingById(Id);
      this.tourSchedules = [];
      if (data.result === this.configService.settings.status.success) {
        this.patrolScheduling = data.references[data.results];
        if (this.patrolScheduling && this.patrolScheduling.TourSchedules && this.patrolScheduling.TourSchedules.length > 0) {
          for (let i in this.patrolScheduling.TourSchedules) {
            this.tourSchedules.push(this.createObjectTourSchedules(data.references[this.patrolScheduling.TourSchedules[i]], "Update"));
          }
        }
      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }

  async getScannedByTypes() {
    try {
      let data = await this.siteService.getScannedByTypes();
      if (data.result === this.configService.settings.status.success) {
        this.scannedByTypes = data.results;
        this.patrolScheduling.ScannedByTypes = this.scannedByTypes[0];
      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }

  async getPatrolStatuses() {
    try {
      let data = await this.siteService.getPatrolStatuses();
      if (data.result === this.configService.settings.status.success) {
        this.activeStatuses = data.results;
        this.patrolScheduling.PatrolStatus = this.activeStatuses[0];
      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }

  async getScheduleTypes() {
    try {
      let data = await this.siteService.getScheduleTypes();
      if (data.result === this.configService.settings.status.success) {
        this.scheduleTypes = data.results;
        this.patrolScheduling.ScheduleType = this.scheduleTypes[0].Value;
      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
  }


  removeItem() {
    let result = this.checkAdditionalCostInvalid(false);
    if (!result) {
      let object = this.tourSchedules.filter((val, i) => i == this.index)[0]
      if (object && object.ObjectID) {
        this.removeTourSchedules.push(object);
      }
      this.tourSchedules = this.tourSchedules.filter((val, i) => i != this.index);
    }
    this.modalConfirmRemove.hide();
  }

  checkAdditionalCostInvalid(isAdd) {
    if (!isAdd)
      return false;

    for (let i in this.patrolForm.controls) {
      if (i.indexOf("StartDay_") != -1 && this.patrolForm.controls[i].invalid == true) {
        return true;
      }

      if (i.indexOf("StartTime_") != -1 && this.patrolForm.controls[i].invalid == true) {
        return true;
      }

      if (i.indexOf("EndTime_") != -1 && this.patrolForm.controls[i].invalid == true) {
        return true;
      }
    }
    return false;
  }

  addItem() {
    let result = this.checkAdditionalCostInvalid(true);
    if (!result) {
      this.tourSchedules = [...this.tourSchedules, {
        SitePatrolSchedule: this.patrolScheduling ? this.patrolScheduling.ObjectID : null,
        StartDay: null, EndTime: null, ObjectID: "", ObjectClass: "prosek.orm.TourSchedule", StartTime: null, Type: "Create"
      }];
    }
  }

  showConfirm(index) {
    this.index = index;
    this.modalConfirmRemove.show();
  }

  hideConfirm() {
    this.modalConfirmRemove.hide();
  }


}
