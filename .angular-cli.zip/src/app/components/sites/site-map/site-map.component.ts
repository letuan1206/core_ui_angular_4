import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivationEnd } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { } from '@types/googlemaps';
import * as _ from 'lodash';

import { SitesService } from '../sites.service';
import { HelperService } from './../../../services/helper.service';

import { ObjectAddress, ObjectGoogleAddress, ObjectInformation } from '../../../interfaces/clients-interface';
import { ObjectSite } from '../../../interfaces/sites-interface';

const defaultLocation = {
  lat: 21.1367594,
  lng: 105.794727
};

@Component({
  selector: 'app-site-map',
  templateUrl: './site-map.component.html',
  styleUrls: ['./site-map.component.scss'],
  providers: [
    SitesService
  ]
})
export class SiteMapComponent implements OnInit {
  @ViewChild('gmap') gmapElement: any;

  public map: google.maps.Map;

  // Object data from API
  private objectSite: ObjectSite;
  private objectSiteInformation: ObjectInformation;
  private objectSiteAddress: ObjectAddress;
  private objectSiteGoogleAddress: ObjectGoogleAddress;

  private listMarker = [];

  private siteID: string;
  constructor(
    private siteService: SitesService,
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
  ) { }

  async ngOnInit() {

    let params = await this.route.params.first().toPromise();
    this.siteID = params.id ? params.id : null;

    this.helperService.showLoading();
    this.initDataRef()
      .subscribe((res: any[]) => {
        this.helperService.hideLoading();
        if (res && res.length == 0) {
          return;
        }



        this.listMarker = res;

        setTimeout(() => {
          let mapProp = {
            center: new google.maps.LatLng(res[0].lat, res[0].lng),
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
          };

          this.map = new google.maps.Map(this.gmapElement.nativeElement, mapProp);

          this.listMarker.forEach(item => {
            // Create marker
            let marker = new google.maps.Marker({
              position: { lat: item.lat, lng: item.lng },
              map: this.map,
              title: item.title
            });
          })
        })

      }, err => {
        this.helperService.hideLoading();
      })

  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  private initDataRef() {
    let objObs = new Observable(obs => {
      this.siteService.getListCheckpoint(this.siteID)
        .then((res: any) => {
          let listPos = [];
          if (!res.results || !res.results.length) {
            obs.next(listPos);
            obs.complete();
            return;
          }

          // Get lat,lng site
          this.objectSite = _.get(res.references, res.results[0]);
          this.objectSiteInformation = this.objectSite.Information ? _.get<any, string>(res.references, this.objectSite.Information) : null;
          this.objectSiteAddress = this.objectSiteInformation && this.objectSiteInformation.Address ? _.get<any, string>(res.references, this.objectSiteInformation.Address) : null;
          this.objectSiteGoogleAddress = this.objectSiteAddress && this.objectSiteAddress.GoogleAddress ? _.get<any, string>(res.references, this.objectSiteAddress.GoogleAddress) : null;

          if (this.objectSiteGoogleAddress) {
            listPos.push({ lat: this.objectSiteGoogleAddress.Latitude, lng: this.objectSiteGoogleAddress.Longitude, title: this.objectSite.SiteName, locateAt: null });
          }

          _.filter(res.references, x => x.ObjectClass === 'prosek.orm.CheckPoint')
            .map(item => {
              listPos.push({ lat: item.Latitude, lng: item.Longitude, title: item.Name, locateAt: item.LocatedAt });
            })

          obs.next(listPos);
          obs.complete();
        }, err => {
          obs.error(err);
        })
    })
    return objObs;
  }

}
