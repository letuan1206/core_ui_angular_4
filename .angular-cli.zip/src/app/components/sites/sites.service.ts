import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from "rxjs/Subscription";
import * as _ from 'lodash';
import { GEOLOCATION_TYPE } from '../common/constants';

// Services
import { HelperService } from './../../services/helper.service';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';

// Interfaces
import { Params } from '../../interfaces/common-interface';
import { SitesTransformParam } from '../../interfaces/sites-interface';

// Redux
import {
  STORE_FILTER_STATE,
  STORE_FILTER_STATUS,
  STORE_FILTER_SERVICE,
  STORE_FILTER_DIVISION,
  STORE_SITES_DATA
} from '../common/common-actions';

@Injectable()
export class SitesService {

  getAllSitesSub: ISubscription;
  getAllServicesSub: ISubscription;
  getAllStatesSub: ISubscription;
  getAllDivisionByStateSub: ISubscription;
  getAllDivisionSub: ISubscription;
  getAllIndustrySub: ISubscription;

  constructor(
    public configService: ConfigService,
    private apiService: ApiService,
    private helperService: HelperService
  ) {

  }

  getDetailSite(Id: string): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: Id
        },
        assocs: ['Information', 'Information.Address', 'Information.State', 'Information.PostalAddress', 'Information.Industry', 'Information.Rating', 'Information.Division', 'Information.Address.GoogleAddress', 'Information.PostalAddress.GoogleAddress']
      };
      this.getAllSitesSub = this.apiService.post(`/Sites`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllSites(clientParams, isAssocs = true): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: clientParams,
        assocs: ['Information', 'Information.Address', 'Information.Services', 'Information.State', 'Information.Address.GoogleAddress', 'Information.Division', 'Contacts']
      };

      if (!isAssocs) {
        params.assocs = [];
      }
      this.getAllSitesSub = this.apiService.post(`/Sites`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllClients(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryParams: {
          ActiveStatus: {
            "Description": "Include Inactive",
            "Value": "INCLUDE_INACTIVE",
            "Name": "INCLUDE_INACTIVE"
          }
        },
        queryType: 'All',
        assocs: []
      };
      this.getAllSitesSub = this.apiService.post(`/Clients`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllServices(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All',
        assocs: []
      };
      this.getAllServicesSub = this.apiService.post(`/Services`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllDivisionByState(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_DETAILS',
        queryParams: {},
        assocs: ['State']
      };
      this.getAllDivisionByStateSub = this.apiService.post(`/Division`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllRating(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All',
        assocs: []
      };
      this.getAllServicesSub = this.apiService.post(`/Ratings`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getActiveStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.apiService.post(`/ActiveStatuses`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getScheduleTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.apiService.post(`/ScheduleTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getAllStates(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_COUNTRY',
        queryParams: {},
        assocs: []
      };
      this.getAllStatesSub = this.apiService.post(`/CountryState`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllDivision(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_DETAILS',
        queryParams: {},
        assocs: []
      };
      this.getAllDivisionSub = this.apiService.post(`/Division`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllIndustry(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.getAllIndustrySub = this.apiService.post(`/Industries`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        assocs: []
      };
      this.apiService.post(`/ReportTypes`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportCategories(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: []
      };
      this.apiService.post(`/ReportCategories`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getNotificationCategoryLinks(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: []
      };
      this.apiService.post(`/NotificationCategoryLinks`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportSubCategories(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        assocs: []
      };
      this.apiService.post(`/ReportSubCategories`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportByParams(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: ['GuardUser', 'ReportForm', 'ReportForm.Type']
      };
      this.apiService.post(`/Reports`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getCheckpointByParams(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: ['Site']
      };
      this.apiService.post(`/CheckPoints`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportNotifications(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: [
          'Contact',
          'Site',
          'SummaryType',
          'CategoryLinks',
          'NotificationReportTypeLinks'
        ]
      };
      this.apiService.post(`/ReportNotifications`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getSummaryTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {},
        assocs: []
      };
      this.apiService.post(`/SummaryTypes`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getFrequencies(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {},
        assocs: []
      };
      this.apiService.post(`/Frequencies`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getPatrolSchedules(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: ['Checkpoints', 'TourSchedules', 'Site']
      };
      this.apiService.post(`/PatrolSchedules`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReportById(reportId): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: reportId
        },
        assocs: ['Site', 'GuardUser', 'ReportForm', 'ReportForm.Type', 'ReportForm.ReportFormCategories', 'ReportCategory', 'FieldValues.ReportField', 'FieldValues', 'ReportPhotos']
      };
      this.apiService.post(`/Reports`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  generateReportPDF(reportId): Promise<any> {
    return new Promise((resolve, reject) => {
      let params = {
        queryType: 'ByID',
        queryParams: {
          id: reportId
        },
        generateDocument: "GenerateReportPDF"
      };
      this.apiService.post(`/Reports`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getPatrolSchedulingById(Id): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: Id
        },
        assocs: ['TourSchedules']
      };
      this.apiService.post(`/PatrolSchedules`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getListCheckpoint(siteId: string) {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {
          Site: siteId,
          ShowDisabled: false
        },
        assocs: []
      };

      this.getAllSitesSub = this.apiService.post(`/CheckPoints`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }
  getDayOfWeekTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {},
        assocs: []
      };
      this.apiService.post(`/DayOfWeekTypes`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getPatrolStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {},
        assocs: []
      };
      this.apiService.post(`/PatrolStatuses`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getScannedByTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        queryParams: {},
        assocs: []
      };
      this.apiService.post(`/ScannedByTypes`, params).subscribe(res => {

        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  filterCategory(query, data: any[]): any[] {
    let filtered: any[] = [];
    for (let i = 0; i < data.length; i++) {
      let item = data[i];
      if (item.Name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    return filtered;
  }

  getAddressDetail(addressComponent) {
    return {
      Country: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.COUNTRY) !== -1) {
          return s;
        }
      }),
      ZipCode: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.ZIP_CODE) !== -1) {
          return s;
        }
      }),
      City: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.CITY) !== -1) {
          return s;
        }
      }),
      StreetNumber: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_NUMBER) !== -1) {
          return s;
        }
      }),
      StreetAddress: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_ADDRESS) !== -1) {
          return s;
        }
      }),
      State: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STATE) !== -1) {
          return s;
        }
      })
    }
  }
  /**
   * Function load data of sites
   */
  async loadDataSites(type, queryParams, stateOptions, serviceOptions, divisionOptions, statusOptions) {

    this.helperService.showLoading();

    try {

      let asyncDataSite = this.getAllSites(queryParams);
      let asyncDataService = this.getAllServices();
      let asyncDataDivision = this.getAllDivisionByState();
      let dataSite = await asyncDataSite;
      let dataService = await asyncDataService;
      let dataDivision = await asyncDataDivision;

      if (dataSite.result === this.configService.successStatus && dataService.result === this.configService.successStatus && dataDivision.result === this.configService.successStatus) {

        let transformParam: SitesTransformParam = new SitesTransformParam();
        transformParam.dataSite = dataSite;
        transformParam.dataDivision = dataDivision;
        transformParam.dataService = dataService;
        transformParam.stateOptions = stateOptions;
        transformParam.serviceOptions = serviceOptions;
        transformParam.divisionOptions = divisionOptions;
        let resultOfSites: any = this.helperService.transformData(transformParam);

        let datas = resultOfSites.datas;
        stateOptions = resultOfSites.stateOptions;
        serviceOptions = resultOfSites.serviceOptions;
        divisionOptions = resultOfSites.divisionOptions;

        this.helperService.dispatchToRedux(STORE_SITES_DATA, datas);

        if (type && type === this.configService.get('typeLoad')) {
          this.helperService.dispatchToRedux(STORE_FILTER_STATE, stateOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_STATUS, statusOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_SERVICE, serviceOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_DIVISION, divisionOptions);
        }

      } else {
        throw Error('error');
      }
      this.helperService.hideLoading();
    } catch (e) {
      this.helperService.hideLoading();
      this.helperService.handleError(e);
    }

  }

  createObjectForPatrolScheduling(patrolScheduling, tourSchedules) {
    let data: any = {};
    let key = ""

    if (patrolScheduling.ObjectID) {
      key = patrolScheduling.ObjectID;
    } else {
      key = "NEW:1";
    }

    data[key] = {
      PatrolStatus: patrolScheduling.PatrolStatus,
      Description: patrolScheduling.Description,
      AssignedTo: patrolScheduling.ScannedByTypes,
      Instructions: patrolScheduling.Instructions,
      EstimateTime: Number(patrolScheduling.EstimateTime),
      GracePeriod: Number(patrolScheduling.GracePeriod),
      ScheduleType: patrolScheduling.ScheduleType ? patrolScheduling.ScheduleType : "DAILY",
      Site: patrolScheduling.Site,
      ObjectClass: "prosek.orm.SitePatrolSchedule",
      TourSchedules: []
    };

    if (patrolScheduling.ObjectID) {
      data[key].ObjectID = patrolScheduling.ObjectID
    }

    Object.assign(data[key].TourSchedules, tourSchedules);
    return data;
  }

  createObjectForTourSchedules(tourSchedules, patrolScheduling) {
    let data: any = {};
    let key = "";
    if (tourSchedules.ObjectID) {
      key = tourSchedules.ObjectID;
    } else {
      key = this.helperService.generatorRandomString();
    }
    data[key] = {
      StartTime: tourSchedules.StartTime.toISOString(),
      EndTime: tourSchedules.EndTime.toISOString(),
      ObjectClass: tourSchedules.ObjectClass,
      StartDay: tourSchedules.StartDay
    };

    if (tourSchedules.ObjectID) {
      data[key].ObjectID = tourSchedules.ObjectID
      data[key].SitePatrolSchedule = patrolScheduling;
    }
    return data;
  }

  executePatrolScheduling(patrolScheduling, tourSchedules, removeTourSchedules): Promise<any> {
    let tourSchedulesKey: string[] = [];

    let params = {
      create: {},
      update: {},
      delete: {}
    }

    if (removeTourSchedules != null && removeTourSchedules != undefined && removeTourSchedules.length > 0) {
      Object.assign(params.delete, removeTourSchedules);
    }

    for (let i in removeTourSchedules) {
      tourSchedulesKey.push(removeTourSchedules[i].ObjectID);
    }

    for (let i in tourSchedules) {
      let object = this.createObjectForTourSchedules(tourSchedules[i], patrolScheduling.ObjectID)

      if (tourSchedules[i].Type == "Create") {
        Object.assign(params.create, object);
      } else {
        Object.assign(params.update, object);
      }

      tourSchedulesKey.push(this.helperService.getKeysOfValue(object)[0]);
    }

    debugger
    let objectPatrolScheduling = this.createObjectForPatrolScheduling(patrolScheduling, tourSchedulesKey);
    if (patrolScheduling.ObjectID) {
      Object.assign(params.update, objectPatrolScheduling);
    } else {
      Object.assign(params.create, objectPatrolScheduling);
    }


    return new Promise((resolve, reject) => {
      this.apiService.post(`/Save`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  downnloadPDF(reportId) {
    let params = {
      queryType: 'ByID',
      queryParams: {
        id: reportId
      },
      generateDocument: "GenerateReportPDF"
    };
    return new Promise((resolve, reject) => {
      this.apiService.post(`/Reports`, params, 'blob').subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

}
