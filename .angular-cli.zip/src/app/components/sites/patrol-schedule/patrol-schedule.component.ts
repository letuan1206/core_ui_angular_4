import { ContactService } from './../../contact/contact.service';
import { ModalDirective } from 'ng2-bootstrap';
import { FormBuilder } from '@angular/forms';
import { SitesService } from './../sites.service';
import { ConfigService } from './../../../services/config.service';
import { ApiService } from './../../../services/api.service';
import { HelperService } from './../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Site, SitePatrolSchedule } from './../../../models/configuration';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { AddPatrolSchedulingComponent } from '../add-patrol-scheduling/add-patrol-scheduling.component';

@Component({
  selector: 'app-patrol-schedule',
  templateUrl: './patrol-schedule.component.html',
  styleUrls: ['./patrol-schedule.component.scss']
})
export class PatrolScheduleComponent implements OnInit {
  @ViewChild('modalManageCheckpoints') public modalManageCheckpoints: ModalDirective;
  @ViewChild('addPatrolScheduling') addPatrolScheduling: AddPatrolSchedulingComponent;
  @ViewChild('modalCreatePatrolSchedule') modal: ModalDirective;

  actionType: string;
  siteId: string;
  siteDetail: Site;
  sitePatrolSchedules: SitePatrolSchedule[] = [];
  checkpointsDT = [];
  checkPointAssigns = [];
  checkPointUnassigns = [];
  isSelectAllAssign = false;
  isSelectAllUnassign = false;
  scheduleSelect: SitePatrolSchedule;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
    private siteService: SitesService,
    private fb: FormBuilder,
    private contactService: ContactService,
  ) {
    this.route.params.subscribe(param => {
      this.siteId = param['siteId'];
    });
  }

  ngOnInit() {
    this.loadData();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  selectCheckpoint(item, type) {
    item.Selected = !item.Selected;

    if (type === 'assign') {
      let countSelect = this.checkPointAssigns.filter(value => value.Selected === true);

      this.isSelectAllAssign = false;

      if (countSelect.length === this.checkPointAssigns.length) {
        this.isSelectAllAssign = true;
      }
    } else {
      let countSelect = this.checkPointUnassigns.filter(value => value.Selected === true);

      this.isSelectAllUnassign = false;

      if (countSelect.length === this.checkPointUnassigns.length) {
        this.isSelectAllUnassign = true;
      }
    }
  }

  selectAll(type) {
    if (type === 'assign') {
      this.isSelectAllAssign = !this.isSelectAllAssign;
      this.checkPointAssigns.forEach(element => {
        element.Selected = this.isSelectAllAssign;
      });
    } else {
      this.isSelectAllUnassign = !this.isSelectAllUnassign;
      this.checkPointUnassigns.forEach(element => {
        element.Selected = this.isSelectAllUnassign;
      });
    }
  }

  assignAction(type) {
    this.isSelectAllAssign = false;
    this.isSelectAllUnassign = false;
    let checkPointAssigns = [];
    let checkPointUnassigns = [];

    if (type === 'add') {
      let dataAdd = [];
      this.checkPointUnassigns.forEach((element, index) => {
        if (element.Selected) {
          element.Selected = false;
          dataAdd.push(_.cloneDeep(element));
        } else {
          checkPointUnassigns.push(_.cloneDeep(element));
        }
      });

      this.checkPointAssigns = _.concat(this.checkPointAssigns, dataAdd);
      this.checkPointUnassigns = checkPointUnassigns;

    } else {
      let dataDel = [];
      this.checkPointAssigns.forEach((element, index) => {
        if (element.Selected) {
          element.Selected = false;
          dataDel.push(_.cloneDeep(element));
        } else {
          checkPointAssigns.push(_.cloneDeep(element));
        }
      });

      this.checkPointUnassigns = _.concat(this.checkPointUnassigns, dataDel);
      this.checkPointAssigns = checkPointAssigns;
    }

  }

  saveManageCheckpoint() {
    this.scheduleSelect.SPSCheckpoints = [];
    this.checkPointAssigns.forEach(element => {
      this.scheduleSelect.SPSCheckpoints.push(element.ObjectID);
    });

    delete this.scheduleSelect.Checkpoints;

    let params = {
      create: {},
      update: {
        'UPDATE:1': this.scheduleSelect
      },
      delete: {}
    }
    this.helperService.showLoading();

    this.apiService.saveService(params).subscribe(res => {
      if (this.configService.successStatus === res.result) {
        this.modalManageCheckpoints.hide();
      }
      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  manageCheckpoint(data) {
    let checkPointAssigns = [];
    let checkPointUnassigns = [];
    this.scheduleSelect = data;

    this.checkpointsDT.forEach(element => {
      if (data.SPSCheckpoints.indexOf(element.ObjectID) !== -1) {
        checkPointAssigns.push(element);
      } else {
        checkPointUnassigns.push(element);
      }
    });

    this.checkPointAssigns = checkPointAssigns;
    this.checkPointUnassigns = checkPointUnassigns;

    this.modalManageCheckpoints.show();
  }

  loadData() {

    let params = {
      Site: this.siteId
    }

    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.siteService.getPatrolSchedules(params),
        this.siteService.getCheckpointByParams(params),
        this.siteService.getDetailSite(this.siteId),
      ]).then(
        ([patrolSchedules, checkpoints, siteDetail]) => {
          let dataArr = [];
          patrolSchedules.results.forEach(element => {
            let sitePatrolSchedule: SitePatrolSchedule;
            sitePatrolSchedule = patrolSchedules.references[element];

            dataArr.push(sitePatrolSchedule);
          });

          this.sitePatrolSchedules = dataArr;
          this.checkpointsDT = this.contactService.getReferencesData(checkpoints);
          this.siteDetail = _.get(siteDetail.references, siteDetail.results[0]);

          this.helperService.hideLoading();
        }).catch(e => {
          this.helperService.hideLoading();
        })
    });
  }

  show(type) {
    if(type == 'create'){
      this.addPatrolScheduling.patrolScheduling = {};
      this.addPatrolScheduling.tourSchedules = [];
      this.addPatrolScheduling.patrolScheduling.Site = this.siteId;
    }
    this.actionType = type;
    this.modal.show();
  }

  hide() {
    this.modal.hide();
  }

  getPatrolSchedulingDetails(Id, type) {
    this.addPatrolScheduling.getPatrolSchedulingById(Id);
    this.show(type);
  }

  async updatePatrolScheduling() {
    try {
      let data = await this.siteService.executePatrolScheduling(this.addPatrolScheduling.patrolScheduling, this.addPatrolScheduling.tourSchedules, this.addPatrolScheduling.removeTourSchedules);
      if (data.result === this.configService.settings.status.success) {
        this.loadData();
      } else {
        throw new Error(data.errorDetails);
      }
    } catch (e) {
      console.log(e);
    }
    this.hide();
  }

}
