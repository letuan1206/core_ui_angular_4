import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatrolScheduleComponent } from './patrol-schedule.component';

describe('PatrolScheduleComponent', () => {
  let component: PatrolScheduleComponent;
  let fixture: ComponentFixture<PatrolScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatrolScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatrolScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
