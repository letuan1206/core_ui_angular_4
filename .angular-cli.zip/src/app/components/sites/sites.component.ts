import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

// Services
import { SitesService } from './sites.service';
import { ConfigService } from './../../services/config.service';
import { HelperService } from './../../services/helper.service';

// Redux
import { NgRedux, select } from 'ng2-redux';

// Interfaces
import { SitesParam, DataOfTableSite } from '../../interfaces/sites-interface';
import { StatusOptions, ServiceOptions, StateOptions, DivisionOptions } from '../../interfaces/common-interface';

@Component({
  selector: 'app-sites',
  templateUrl: './sites.component.html',
  styleUrls: ['./sites.component.scss']
})
export class SitesComponent implements OnInit, OnDestroy {

  private typeFilter: string;

  private sitesArr: any = [];

  statusOptions: StatusOptions[] = [
    {
      Description: "Active Only",
      Value: "ACTIVE"
    }, 
    {
      Description: "Include Inactive",
      Value: "INACTIVE"
    }
  ];
  serviceOptions: ServiceOptions[] = [
    {
      Active: null,
      Description: 'Choose Service',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  stateOptions: StateOptions[] = [
    {
      Active: null,
      Country: null,
      Name: 'Choose State',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  divisionOptions: DivisionOptions[] = [
    {
      Active: null,
      Description: 'Choose Division',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      State: null
    }
  ];

  querySiteParams: SitesParam = {
    ActiveStatus: null,
    Service: null,
    Division: null,
    Rating: null,
    State: null
  }

  @select(s => s.common.sitesData) sitesData;
  
  constructor(
    private sitesService: SitesService,
    private configService: ConfigService,
    private helperService: HelperService,
    private router: Router,
    private ngRedux: NgRedux<any>
  ) { 
    this.sitesData.subscribe(data => {
      this.sitesArr = data;
    });
  }

  ngOnInit() {
    this.typeFilter = this.configService.get('menuType')['sites'];
    this.querySiteParams.ActiveStatus = this.statusOptions[0];
    this.sitesService.loadDataSites(this.configService.get('typeLoad'), this.querySiteParams, this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  handleRowClick(event: any) {
    this.router.navigate(['/sites/detail/', event.data.objectID]);
  }
  ngOnDestroy() {
    // this.sitesService.getAllSitesSub.unsubscribe();
    // this.sitesService.getAllServicesSub.unsubscribe();
    // this.sitesService.getAllStatesSub.unsubscribe();
    // this.sitesService.getAllDivisionByStateSub.unsubscribe();
  }
  
}
