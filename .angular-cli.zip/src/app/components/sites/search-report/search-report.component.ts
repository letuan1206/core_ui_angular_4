import { ContactService } from './../../contact/contact.service';
import { SitesService } from './../sites.service';
import { ConfigService } from './../../../services/config.service';
import { ApiService } from './../../../services/api.service';
import { HelperService } from './../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { Site } from '../../../models/configuration';

@Component({
  selector: 'app-search-report',
  templateUrl: './search-report.component.html',
  styleUrls: ['./search-report.component.scss'],

})
export class SearchReportComponent implements OnInit {
  searchReportDT = [];
  reportTypesData = [];
  categoriesData = [];
  subCategoriesData = [];
  guardUsersData = [];

  filteredGuardUser: any[];
  filteredCategory: any[];
  filteredSubCategory: any[];

  searchFilter = {
    detail: null,
    type: null,
    guard: null,
    category: null,
    subCategory: null,
    from: null,
    fromTime: null,
    to: null,
    toTime: null
  }

  siteId: string;
  siteDetail: Site;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
    private contactService: ContactService,
    private siteService: SitesService,
  ) {
    this.route.params.subscribe(param => {
      this.siteId = param['siteId'];
    });
  }

  ngOnInit() {
    this.resetModelFilter();
    setTimeout(() => {
      this.loadData();
    })
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  resetModelFilter() {
    return {
      detail: null,
      type: null,
      guard: null,
      category: null,
      subCategory: null,
      from: null,
      fromTime: null,
      to: null,
      toTime: null
    }
  }

  searchReport() {
    let params = {
      SubCategory: this.searchFilter.subCategory ? this.searchFilter.subCategory.ObjectID : null,
      Type: this.searchFilter.type !== 'null' ? this.searchFilter.type : null,
      Category: this.searchFilter.category ? this.searchFilter.category.ObjectID : null,
      Guard: this.searchFilter.guard ? this.searchFilter.guard.ObjectID : null,
      Site: this.siteId,
      From: this.searchFilter.from ? moment(this.searchFilter.from).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      FromTime: this.searchFilter.fromTime ? moment(this.searchFilter.fromTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      To: this.searchFilter.to ? moment(this.searchFilter.to).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      ToTime: this.searchFilter.toTime ? moment(this.searchFilter.toTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
    }

    this.helperService.showLoading();

    this.siteService.getReportByParams(params).then(res => {
      let dataArr = [];
      if (res.result === this.configService.successStatus) {
        res.results.forEach(element => {
          let report = _.get(res.references, element);
          report.GuardUserDetail = _.get(res.references, report.GuardUser);
          report.ReportFormDetail = _.get(res.references, report.ReportForm);
          report.ReportType = _.get(res.references, report.ReportFormDetail.Type);
          // report.ReportFormDetail = _.get(res.references, report.ReportForm);
          dataArr.push(report);
        });
        this.searchReportDT = dataArr;
      }
      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  handleRowClick(event) {
    this.router.navigate(['/report-detail', event.data.ObjectID]);
  }

  filterGuardUser(event) {
    this.filteredGuardUser = this.contactService.filterClientManager(event.query, this.guardUsersData);
  }

  filterCategory(event) {
    this.filteredCategory = this.siteService.filterCategory(event.query, this.categoriesData);
  }

  filterSubCategory(event) {
    this.filteredSubCategory = this.siteService.filterCategory(event.query, this.subCategoriesData);
  }

  loadData() {
    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.siteService.getReportTypes(),
        this.siteService.getReportCategories({}),
        this.siteService.getReportSubCategories(),
        this.contactService.getClientManager(),
      ]).then(
        ([reportTypes, categories, subCategories, guardUsers]) => {
          this.reportTypesData = this.contactService.getReferencesData(reportTypes);
          this.categoriesData = this.contactService.getReferencesData(categories);
          this.subCategoriesData = this.contactService.getReferencesData(subCategories);
          this.guardUsersData = this.contactService.getReferencesData(guardUsers);
          this.guardUsersData.forEach(element => {
            if (element.FirstName) {
              element.UserName = element.FirstName + ' ' + element.LastName;
            }
          });

          this.helperService.hideLoading();
        }).catch(e => {
          this.helperService.hideLoading();
        })
    });
  }
}
