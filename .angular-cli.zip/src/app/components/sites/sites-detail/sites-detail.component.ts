import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivationEnd } from '@angular/router';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, Form, EmailValidator } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { Observable } from 'rxjs/Observable'
import * as _ from 'lodash';
declare var $: any;

// Interface
import { ObjectAddress, ObjectGoogleAddress, ObjectInformation } from '../../../interfaces/clients-interface';
import { ObjectSite } from '../../../interfaces/sites-interface';

// Service
import { SitesService } from '../sites.service';
import { HelperService } from './../../../services/helper.service';
import { ApiService } from './../../../services/api.service';
import { ConfigService } from './../../../services/config.service';
import { AddOrEditTimelineComponent } from '../../subs/modals/add-or-edit-timeline/add-or-edit-timeline.component';
import { AddNoteModalComponent } from '../../subs/modals/add-note-modal/add-note-modal.component';
import { TimelineComponent } from '../../subs/timeline/timeline.component';

interface SiteDetailOverview {
  siteName: string | null;
  phone: string | null;
  fax: string | null;
  email: string | null;
  email2: string | null;
  website: string | null;
  address: string | null;
  postalAddress: string | null;
  rating: string | null;
  service: string[];
  state: string | null;
  division: string | null;
  industry: string | null;
  client: string | null;
}

enum Action {
  Edit = 1,
  Add
}

enum AddressAction {
  Add = 1,
  Update,
  Delete
}

enum SectionData {
  Rating,
  State,
  Division,
  Industry,
  Service,
  Client
}

@Component({
  selector: 'app-sites-detail',
  templateUrl: './sites-detail.component.html',
  styleUrls: ['./sites-detail.component.scss']
})
export class SitesDetailComponent implements OnInit {
  @ViewChild('addOrEditTimelineModal') addOrEditTimelineModal: AddOrEditTimelineComponent;
  @ViewChild('addNotesModal') public addNotesModal: AddNoteModalComponent;
  @ViewChild('timelineTable') public timelineTable: TimelineComponent;

  // Variable for action (edit/add) site
  private action: Action = null;
  private preClientId: any = null;
  private preLink: any = null;
  private siteID: string;

  // Variable for FormGroup
  private siteDetailForm: FormGroup = null;
  private formDisabled: boolean = null;

  // Variable for autocomplete
  private listClientOption: any[];
  private listRatingOption: any[];
  private listServiceOption: any[];
  private listStateOption: any[];
  private listIndustryOption: any[];
  private listDivisionOption: any[];
  siteId: string;

  // Auto complete
  private filteredServiceMultiple: any[];
  private addressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };
  private postalAddressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };

  // Logo
  private uploader: FileUploader;
  private logoImg: any;
  private logoToken: any;
  private oldLogo: string;

  // Object data from API
  private objectSite: ObjectSite;
  private listRefSite: any[];
  private objectSiteInformation: ObjectInformation;
  private objectSiteAddress: ObjectAddress;
  private objectSitePostalAddress: ObjectAddress;
  private objectSiteGoogleAddress: ObjectGoogleAddress;
  private objectSiteGooglePostalAddress: ObjectGoogleAddress;

  // Variable for address
  private objectSiteNewAddress: ObjectAddress;
  private objectSiteNewGoogleAddress: ObjectGoogleAddress;
  private objectSiteNewPostalAddress: ObjectAddress;
  private objectSiteNewGooglePostalAddress: ObjectGoogleAddress;

  // Variable for summary error
  private enableErrorSummary: boolean;
  private msgErrorSummary: string;

  constructor(
    private siteSerive: SitesService,
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService
  ) {
    this.route.params.subscribe(param => {
      this.siteId = param['id'];
    });
  }

  async ngOnInit() {
    window.scrollTo(0, 0);
    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-sites ul li').each(function () {
        if ($('#section-site-detail').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr('href-anchor'));
          if (refElement.position() && refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-sites ul li a').removeClass('active-menu');
            currLink.addClass('active-menu');
          } else {
            currLink.removeClass('active-menu');
          }
        }
      });
    }

    if ($('#section-site-detail').length) {
      $(document).on('scroll', onScroll);
    }

    $('.ancho-sites ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-sites ul li a').removeClass('active-menu');
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });

    this.helperService.showLoading();

    this.formDisabled = true;

    this.objectSiteNewAddress = null;
    this.objectSiteNewGoogleAddress = null;
    this.objectSiteNewPostalAddress = null;
    this.objectSiteNewGooglePostalAddress = null;

    this.setDataForm(null);
    this.hideSummaryError();

    // Init file upload
    this.uploader = new FileUploader({ url: this.configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };

    // Set action (edit/add)
    await this.setAction();

    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      actionObs = this.initAddAction();
    }

    this.initDataRef()
      .flatMap(() => actionObs)
      .subscribe(res => {
        this.helperService.hideLoading();
      }, err => {
        this.helperService.hideLoading();
      })

  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  private reloadData(): Observable<any> {
    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      actionObs = this.initAddAction();
    }

    return actionObs;
  }

  private resetIfNotANumber(controlName: string, val: string) {
    if (val == null) {
      return;
    }

    let isValid = /^[0-9]*$/.test(val);
    if (!isValid) {
      this.siteDetailForm.get(controlName).setValue(val.slice(0, val.length - 1))
    }
  }

  // get site data
  private getSiteDetail() {
    let obsObj = new Observable(obs => {
      this.route.params.first()
        .subscribe(params => {
          this.siteSerive.getDetailSite(params.id)
            .then(res => {
              obs.next(res);
              obs.complete();
            }, err => {
              obs.error(err);
            })
        }, err => {
          obs.error('Get site id fail!')
        })
    })

    return obsObj;
  }

  // Set action of this request
  private async setAction() {

    let params = await this.route.queryParams.first().toPromise();
    let mapUrl = await this.route.url.first().toPromise();
    this.action = mapUrl.length > 0 && mapUrl[0].path !== 'add' ? Action.Edit : Action.Add;
    if (this.action == Action.Add) {
      this.preClientId = params.clientId ? params.clientId : null;
      this.preLink = this.preClientId ? ['/clients/detail/', this.preClientId] : null
    }
    this.siteID = params.id && params.id !== 'add' ? params.id : null;
  }

  private initAddAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.enableEditForm();

      // Clone object address. CANT BE NULL
      let objectEmptyGoogleAddress: ObjectGoogleAddress = {
        ObjectClass: 'prosek.orm.GoogleAddress',
        ObjectCreated: null,
        ObjectID: null,
        ObjectLastModified: null,
        City: null,
        Country: null,
        GoogleAddressText: null,
        Latitude: null,
        Longitude: null,
        State: null,
        StreetAddress: null,
        StreetNumber: null,
        ZipCode: null
      };

      let objectEmptyAddress: ObjectAddress = {
        ObjectClass: 'prosek.orm.Address',
        GoogleAddress: null,
        ObjectCreated: null,
        ObjectID: null,
        ObjectLastModified: null,
        PostcodeSuburb: null,
        Street: null
      }

      this.objectSiteAddress = Object.assign({}, objectEmptyAddress);
      this.objectSiteGoogleAddress = Object.assign({}, objectEmptyGoogleAddress);
      this.objectSitePostalAddress = Object.assign({}, objectEmptyAddress);
      this.objectSiteGooglePostalAddress = Object.assign({}, objectEmptyGoogleAddress);

      this.objectSiteNewAddress = Object.assign({}, objectEmptyAddress);
      this.objectSiteNewGoogleAddress = Object.assign({}, objectEmptyGoogleAddress);
      this.objectSiteNewPostalAddress = Object.assign({}, objectEmptyAddress);
      this.objectSiteNewGooglePostalAddress = Object.assign({}, objectEmptyGoogleAddress);

      if (this.preClientId) {
        let client = _.find(this.listClientOption, x => x.ObjectID === this.preClientId);
        this.siteDetailForm.get('client').setValue(client);
      }

      obs.next();
      obs.complete();
    })

    return obsObj;
  }

  private initEditAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.disableEditForm();
      this.getSiteDetail().toPromise()
        .then((res: any) => {
          // Assign Object Site
          this.listRefSite = res.references;

          this.objectSite = _.get(this.listRefSite, res.results[0]);
          this.objectSiteInformation = this.objectSite.Information ? _.get<any, string>(this.listRefSite, this.objectSite.Information) : null;
          this.objectSiteAddress = this.objectSiteInformation && this.objectSiteInformation.Address ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Address) : null;
          this.objectSiteGoogleAddress = this.objectSiteAddress && this.objectSiteAddress.GoogleAddress ? _.get<any, string>(this.listRefSite, this.objectSiteAddress.GoogleAddress) : null;
          this.objectSitePostalAddress = this.objectSiteInformation && this.objectSiteInformation.PostalAddress ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.PostalAddress) : null;
          this.objectSiteGooglePostalAddress = this.objectSitePostalAddress && this.objectSitePostalAddress.GoogleAddress ? _.get<any, string>(this.listRefSite, this.objectSitePostalAddress.GoogleAddress) : null;

          // Clone object address. CANT BE NULL
          let objectEmptyGoogleAddress: ObjectGoogleAddress = {
            ObjectClass: 'prosek.orm.GoogleAddress',
            ObjectCreated: null,
            ObjectID: null,
            ObjectLastModified: null,
            City: null,
            Country: null,
            GoogleAddressText: null,
            Latitude: null,
            Longitude: null,
            State: null,
            StreetAddress: null,
            StreetNumber: null,
            ZipCode: null
          };

          let objectEmptyAddress: ObjectAddress = {
            ObjectClass: 'prosek.orm.Address',
            GoogleAddress: null,
            ObjectCreated: null,
            ObjectID: null,
            ObjectLastModified: null,
            PostcodeSuburb: null,
            Street: null
          }

          this.objectSiteNewAddress = this.objectSiteAddress ? Object.assign({}, this.objectSiteAddress) : Object.assign({}, objectEmptyAddress);
          this.objectSiteNewGoogleAddress = this.objectSiteGoogleAddress ? Object.assign({}, this.objectSiteGoogleAddress) : Object.assign({}, objectEmptyGoogleAddress);
          this.objectSiteNewPostalAddress = this.objectSitePostalAddress ? Object.assign({}, this.objectSitePostalAddress) : Object.assign({}, objectEmptyAddress);
          this.objectSiteNewGooglePostalAddress = this.objectSiteGooglePostalAddress ? Object.assign({}, this.objectSiteGooglePostalAddress) : Object.assign({}, objectEmptyGoogleAddress);

          this.addressGeolocationSetting = Object.assign({}, this.addressGeolocationSetting, { inputString: this.objectSiteAddress ? this.objectSiteAddress.Street : '' });
          this.postalAddressGeolocationSetting = Object.assign({}, this.postalAddressGeolocationSetting, { inputString: this.objectSitePostalAddress ? this.objectSitePostalAddress.Street : '' });

          this.logoImg = this.objectSite && this.objectSite.Logo ? `${this.configService.get('webRoot')}/${this.objectSite.Logo.URI}` : null;
          this.oldLogo = this.logoImg;

          let objState = this.objectSiteInformation && this.objectSiteInformation.State ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.State) : null;
          let objRating = this.objectSiteInformation && this.objectSiteInformation.Rating ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Rating) : null;
          let objIndustry = this.objectSiteInformation && this.objectSiteInformation.Industry ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Industry) : null;
          let objDivision = this.objectSiteInformation && this.objectSiteInformation.Division ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Division) : null;
          let objClient = this.objectSite && this.objectSite.Client ? _.find(this.listClientOption, x => x.ObjectID === this.objectSite.Client) : null;

          this.preLink = objClient && objClient.ObjectID ? ['/clients/detail/', objClient.ObjectID] : null

          let dataForm = {
            siteName: this.objectSite.SiteName,
            phone: this.objectSiteInformation.Phone,
            fax: this.objectSiteInformation.Fax,
            email: this.objectSiteInformation.Email,
            email2: this.objectSiteInformation.Recipients,
            website: this.objectSiteInformation.Website,
            address: null,
            postalAddress: null,
            rating: objRating,
            service: _.filter(this.listServiceOption, x => this.objectSite.InformationServices.indexOf(x.ObjectID) != -1),
            state: objState,
            division: objDivision,
            industry: objIndustry,
            client: objClient
          }
          this.setDataForm(dataForm);

          // Complete init
          obs.next(null)
          obs.complete();
        }, err => {
          obs.error(err);
        })
    })

    return obsObj;
  }

  private enableEditForm() {
    this.formDisabled = false;
    this.siteDetailForm.enable();
  }

  private disableEditForm() {
    this.formDisabled = true;
    this.siteDetailForm.disable();
  }

  private showSummaryError(msg: string) {
    this.enableErrorSummary = true;
    this.msgErrorSummary = msg;
  }

  private hideSummaryError() {
    this.enableErrorSummary = false;
    this.msgErrorSummary = '';
  }

  private initDataRef() {
    let obsObj = new Observable(obs => {
      Promise.all([
        this.getDataSection(SectionData.Rating).toPromise(),
        this.getDataSection(SectionData.State).toPromise(),
        this.getDataSection(SectionData.Division).toPromise(),
        this.getDataSection(SectionData.Industry).toPromise(),
        this.getDataSection(SectionData.Service).toPromise(),
        this.getDataSection(SectionData.Client).toPromise()
      ]).then(res => {
        // Assign autoComplete
        let [dataRating, dataState, dataDivision, dataIndustry, dataService, dataClient] = res;
        this.listRatingOption = _.filter(dataRating.references, x => dataRating.results.indexOf(x.ObjectID) !== -1);
        this.listServiceOption = _.filter(dataService.references, x => dataService.results.indexOf(x.ObjectID) !== -1);
        this.listStateOption = _.filter(dataState.references, x => dataState.results.indexOf(x.ObjectID) !== -1);
        this.listIndustryOption = _.filter(dataIndustry.references, x => dataIndustry.results.indexOf(x.ObjectID) !== -1);
        this.listDivisionOption = _.filter(dataDivision.references, x => dataDivision.results.indexOf(x.ObjectID) !== -1);
        this.listClientOption = _.filter(dataClient.references, x => dataClient.results.indexOf(x.ObjectID) !== -1);

        obs.next();
        // obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private getDataSection(section: SectionData): Observable<any> {
    let obsObj = new Observable(obs => {
      let o = null;
      switch (section) {
        case SectionData.Rating: {
          o = this.siteSerive.getAllRating();
          break;
        }
        case SectionData.State: {
          o = this.siteSerive.getAllStates();
          break;
        }
        case SectionData.Division: {
          o = this.siteSerive.getAllDivision();
          break;
        }
        case SectionData.Industry: {
          o = this.siteSerive.getAllIndustry();
          break;
        }
        case SectionData.Service: {
          o = this.siteSerive.getAllServices();
          break;
        }
        case SectionData.Client: {
          o = this.siteSerive.getAllClients();
          break;
        }
      }

      o.then(res => {
        obs.next(res);
        obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private setDataForm(data: SiteDetailOverview) {
    if (!data) {
      // reset data
      data = {
        siteName: null,
        phone: null,
        fax: null,
        email: null,
        email2: null,
        website: null,
        address: null,
        postalAddress: null,
        rating: null,
        service: [],
        state: null,
        division: null,
        industry: null,
        client: null
      }
    }

    if (this.siteDetailForm) {
      this.siteDetailForm.setValue(data);
    } else {
      this.siteDetailForm = new FormGroup({
        siteName: new FormControl(data.siteName, Validators.required),
        phone: new FormControl(data.phone),
        fax: new FormControl(data.fax),
        email: new FormControl(data.email, this.helperService.customEmailValidator),
        email2: new FormControl(data.email2, this.helperService.customEmailValidator),
        website: new FormControl(data.website),
        address: new FormControl(data.address),
        postalAddress: new FormControl(data.postalAddress),
        rating: new FormControl(data.rating),
        service: new FormControl(data.service),
        state: new FormControl(data.state),
        division: new FormControl(data.division),
        industry: new FormControl(data.industry),
        client: new FormControl(data.client, Validators.required)
      })

      this.siteDetailForm.get('phone').valueChanges.subscribe((val: string) => this.resetIfNotANumber('phone', val));
      this.siteDetailForm.get('fax').valueChanges.subscribe((val: string) => this.resetIfNotANumber('fax', val));
    }
  }

  private resetDataForm() {
    if (this.action == Action.Edit) {
      let objState = this.objectSiteInformation && this.objectSiteInformation.State ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.State) : null;
      let objRating = this.objectSiteInformation && this.objectSiteInformation.Rating ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Rating) : null;
      let objIndustry = this.objectSiteInformation && this.objectSiteInformation.Industry ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Industry) : null;
      let objDivision = this.objectSiteInformation && this.objectSiteInformation.Division ? _.get<any, string>(this.listRefSite, this.objectSiteInformation.Division) : null;
      let objClient = this.objectSite && this.objectSite.Client ? _.find(this.listClientOption, x => x.ObjectID === this.objectSite.Client) : null;
      let objServiceArr = _.filter(this.listServiceOption, x => {
        return this.objectSite.InformationServices.indexOf(x.ObjectID) !== -1
      });

      this.logoImg = this.objectSite && this.objectSite.Logo ? `${this.configService.get('webRoot')}/${this.objectSite.Logo.URI}` : null;
      this.oldLogo = this.logoImg;

      let dataForm = {
        siteName: this.objectSite.SiteName,
        phone: this.objectSiteInformation.Phone,
        fax: this.objectSiteInformation.Fax,
        email: this.objectSiteInformation.Email,
        email2: this.objectSiteInformation.Recipients,
        website: this.objectSiteInformation.Website,
        address: null,
        postalAddress: null,
        rating: objRating,
        service: objServiceArr,
        state: objState,
        division: objDivision,
        industry: objIndustry,
        client: objClient
      }
      this.setDataForm(dataForm);

    } else if (this.action == Action.Add) {
      this.setDataForm(null);
    }

    this.disableEditForm();
  }

  private autoCompleteAddressCallback(selectedData: any, type) {
    // Init Object GoogleAddress and Address
    let objectGoogleAddress: ObjectGoogleAddress = {
      ObjectClass: 'prosek.orm.GoogleAddress',
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      City: null,
      Country: null,
      GoogleAddressText: null,
      Latitude: null,
      Longitude: null,
      State: null,
      StreetAddress: null,
      StreetNumber: null,
      ZipCode: null
    };

    let objectAddress: ObjectAddress = {
      ObjectClass: 'prosek.orm.Address',
      GoogleAddress: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      PostcodeSuburb: null,
      Street: null
    }

    if (selectedData.response) {
      // Parse address
      let addressDetail = this.siteSerive.getAddressDetail(selectedData.data.address_components);

      objectGoogleAddress.City = addressDetail.City ? addressDetail.City.long_name : null;
      objectGoogleAddress.Country = addressDetail.Country ? addressDetail.Country.long_name : null;
      objectGoogleAddress.State = addressDetail.State ? addressDetail.State.long_name : null;
      objectGoogleAddress.StreetAddress = addressDetail.StreetAddress ? addressDetail.StreetAddress.long_name : null;
      objectGoogleAddress.StreetNumber = addressDetail.StreetNumber ? addressDetail.StreetNumber.long_name : null;
      objectGoogleAddress.ZipCode = addressDetail.ZipCode ? addressDetail.ZipCode.long_name : null;
      objectGoogleAddress.GoogleAddressText = selectedData.data.description;
      objectGoogleAddress.Latitude = selectedData.data.geometry.location.lat;
      objectGoogleAddress.Longitude = selectedData.data.geometry.location.lng;
    }

    /**
    /* Update object
    */
    if (type === 'Address') {
      /**
      /* Update for input Address
      */

      // Object GoogleAddress
      if (this.objectSiteGoogleAddress && this.objectSiteGoogleAddress.ObjectID) {
        this.objectSiteNewGoogleAddress = Object.assign({}, objectGoogleAddress, {
          ObjectID: this.objectSiteGoogleAddress.ObjectID,
          ObjectCreated: this.objectSiteGoogleAddress.ObjectCreated
        })
      } else {
        this.objectSiteNewGoogleAddress = Object.assign({}, objectGoogleAddress);
      }

      // Object Address
      if (this.objectSiteAddress && this.objectSiteAddress.ObjectID) {
        this.objectSiteNewAddress = Object.assign({}, objectAddress, {
          ObjectID: this.objectSiteAddress.ObjectID,
          ObjectCreated: this.objectSiteAddress.ObjectCreated,
          GoogleAddress: this.objectSiteAddress.GoogleAddress
        })
      } else {
        this.objectSiteNewAddress = Object.assign({}, objectAddress);
      }

      if (selectedData.response) {
        this.objectSiteNewAddress.Street = selectedData.data.description;
      }

    } else if (type === 'PostalAddress') {
      /**
      /* Update for input PostalAddress
      */

      // Object GoogleAddress
      if (this.objectSiteGooglePostalAddress && this.objectSiteGooglePostalAddress.ObjectID) {
        this.objectSiteNewGooglePostalAddress = Object.assign({}, objectGoogleAddress, {
          ObjectID: this.objectSiteGooglePostalAddress.ObjectID,
          ObjectCreated: this.objectSiteGooglePostalAddress.ObjectCreated
        })
      } else {
        this.objectSiteNewGooglePostalAddress = Object.assign({}, objectGoogleAddress);
      }

      // Object Address
      if (this.objectSitePostalAddress && this.objectSitePostalAddress.ObjectID) {
        this.objectSiteNewPostalAddress = Object.assign({}, objectAddress, {
          ObjectID: this.objectSitePostalAddress.ObjectID,
          ObjectCreated: this.objectSitePostalAddress.ObjectCreated,
          GoogleAddress: this.objectSitePostalAddress.GoogleAddress
        })
      } else {
        this.objectSiteNewPostalAddress = Object.assign({}, objectAddress);
      }

      if (selectedData.response) {
        this.objectSiteNewPostalAddress.Street = selectedData.data.description;
      }
    }

  }

  private autoComplete(event, listSuggest: any[]) {
    let inputText = event.query;
    let filtered: any[] = [];

    for (let i = 0; i < listSuggest.length; i++) {
      let item = listSuggest[i];
      if (item.Description.toLowerCase().indexOf(inputText.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }

    this.filteredServiceMultiple = filtered;
  }

  private accessObject(paramCreate: any[], paramUpdate: any[], paramDelete: any[]): Observable<any> {
    let params = {
      create: {},
      update: {},
      delete: {}
    }

    for (var i = 0; i < paramCreate.length; ++i) {
      params.create[`NEW:${i}`] = paramCreate[i];
    }

    for (var i = 0; i < paramUpdate.length; ++i) {
      params.update[paramUpdate[i].ObjectID] = paramUpdate[i];
    }

    for (var i = 0; i < paramDelete.length; ++i) {
      params.delete[paramDelete[i].ObjectID] = paramDelete[i];
    }

    let returnObject = {
      created: [],
      updated: [],
      deleted: []
    }

    let obsObj = new Observable(obs => {
      this.apiService.saveService(params)
        .subscribe(res => {
          if (res.result) {
            // Push created object
            Object.keys(res.created).map(function (key, index) {
              returnObject.created.push(res.created[key]);
            });

            // Push updated object
            paramUpdate.map(o => o.ObjectID).forEach(item => {
              if (res.updated.indexOf(item) != -1) {
                returnObject.updated.push(_.get(res.references, item))
              }
            });

            // Push deleted object
            returnObject.deleted = res.deleted;

            obs.next(returnObject);
            obs.complete();
          } else {
            obs.error("Create object Address fail")
          }
        }, err => {
          obs.error(err);
        })

    })

    return obsObj;
  }

  private updateSite() {

    if (!this.siteDetailForm.valid || !this.objectSiteNewAddress.Street) {
      this.siteDetailForm.get('siteName').markAsTouched();
      this.siteDetailForm.get('phone').markAsTouched();
      this.siteDetailForm.get('fax').markAsTouched();
      this.siteDetailForm.get('email').markAsTouched();
      this.siteDetailForm.get('email2').markAsTouched();
      this.siteDetailForm.get('client').markAsTouched();

      this.siteDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    Observable.forkJoin([
      this.updateAddress(this.objectSiteAddress, this.objectSiteGoogleAddress, this.objectSiteNewAddress, this.objectSiteNewGoogleAddress),
      this.updateAddress(this.objectSitePostalAddress, this.objectSiteGooglePostalAddress, this.objectSiteNewPostalAddress, this.objectSiteNewGooglePostalAddress),
      this.uploadLogo()
    ])
      .flatMap(resp => this.updateObjectSite(resp))
      .flatMap(() => this.reloadData())
      .subscribe(res => {
        this.uploader.clearQueue();
        this.helperService.hideLoading();
        this.hideSummaryError();

      }, err => {
        this.helperService.hideLoading();
      });
  }

  private addSite() {
    if (!this.siteDetailForm.valid || this.objectSiteAddress.Street) {
      this.siteDetailForm.get('siteName').markAsTouched();
      this.siteDetailForm.get('phone').markAsTouched();
      this.siteDetailForm.get('fax').markAsTouched();
      this.siteDetailForm.get('email').markAsTouched();
      this.siteDetailForm.get('email2').markAsTouched();
      this.siteDetailForm.get('client').markAsTouched();

      this.siteDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    let createObjectInformation = (address, logo) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.siteDetailForm.value;

        let objInfo: ObjectInformation = {
          ObjectID: null,
          ObjectClass: 'prosek.orm.Information',
          ObjectCreated: null,
          ObjectLastModified: null,
          Phone: valueOfForm.phone,
          Fax: valueOfForm.fax,
          Email: valueOfForm.email,
          Recipients: valueOfForm.email2,
          Website: valueOfForm.website,
          Rating: valueOfForm.rating ? valueOfForm.rating.ObjectID : null,
          State: valueOfForm.state ? valueOfForm.state.ObjectID : null,
          Division: valueOfForm.division ? valueOfForm.division.ObjectID : null,
          Industry: valueOfForm.industry ? valueOfForm.industry.ObjectID : null,
          Address: address.length > 0 && address[0] ? address[0] : null,
          PostalAddress: address.length > 0 && address[1] ? address[1] : null,
          ContractExpiry: null,
          ContractExtended: null,
          ContractOption: null,
          ContractTerm: null,
          Description: null,
          OptionExpiry: null,
          ReportsByEmail: null,
          Services: [],
          StartDate: null,
          TerminationDate: null
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next([res.created[0], logo])
            } else {
              obs.error('Create object Information fail');
            }
          }, err => {
            obs.error(err);
          }
          )
      })

      return objObs;
    }

    let createObjectSite = (res) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.siteDetailForm.value;
        let objInfo: ObjectSite = {
          ObjectID: null,
          ObjectClass: 'prosek.orm.Site',
          ObjectCreated: null,
          ObjectLastModified: null,
          Active: true,
          Client: valueOfForm.client.ObjectID,
          Information: res[0],
          InformationServices: valueOfForm.service.map(x => x.ObjectID),
          Logo: res[1],
          SiteName: valueOfForm.siteName,
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next(res.created[0])
            } else {
              obs.error('Create object Site fail');
            }
          }, err => {
            obs.error(err);
          }
          )
      })

      return objObs;
    }

    Observable.forkJoin(
      this.updateAddress(this.objectSiteAddress, this.objectSiteGoogleAddress, this.objectSiteNewAddress, this.objectSiteNewGoogleAddress),
      this.updateAddress(this.objectSitePostalAddress, this.objectSiteGooglePostalAddress, this.objectSiteNewPostalAddress, this.objectSiteNewGooglePostalAddress),
      this.uploadLogo()
    )
      .flatMap((resp: any) => {
        let logo = null;
        if (resp && resp.length > 0 && resp[2] && resp[2].token) {
          logo = { FileToken: resp[2].token }
        }
        return createObjectInformation(resp, logo);
      })
      .flatMap(res => createObjectSite(res))
      .subscribe(res => {
        this.helperService.hideLoading();
        let ObjectIDSite = res;

        // Navigate to new site
        this.router.navigate(['/sites/detail/', ObjectIDSite]);
        this.hideSummaryError();
      }, err => {
        this.helperService.hideLoading();

      });
  }

  private updateAddress(oAddress: ObjectAddress, oGAddress: ObjectGoogleAddress, nAddress: ObjectAddress, nGAddress: ObjectGoogleAddress) {
    let objObs = new Observable(obs => {
      let action = null;

      // Choose action for change of address
      if (!oAddress.ObjectID) {
        action = AddressAction.Add;
      } else {
        action = AddressAction.Update;
      }

      // Make
      switch (action) {
        case AddressAction.Add: {

          this.accessObject([nGAddress], [], [])
            .flatMap((listObj) => {
              // Assign object GoogleAddress to Address
              let nReturnGoogleAddress = listObj.created.length > 0 ? listObj.created[0] : null;
              if (!nReturnGoogleAddress) {
                return Observable.throw(new Error('Object Google Address wrong!'));
              }

              nAddress.GoogleAddress = nReturnGoogleAddress;
              return this.accessObject([nAddress], [], []);
            })
            .subscribe(res => {
              obs.next(res.created[0])
              obs.complete();;
            }, err => {
              obs.error(err);;
            })
          break;
        }

        case AddressAction.Update: {
          if (nGAddress.ObjectID) {
            this.accessObject([], [nAddress, nGAddress], [])
              .subscribe(res => {
                obs.next(res.updated.length > 0 ? res.updated[0] : null);
                obs.complete();
              }, err => {
                obs.error(err);
              })
          } else {
            this.accessObject([nGAddress], [], [])
              .flatMap((listObj: any) => {
                // Assign object GoogleAddress to Address
                nAddress.GoogleAddress = listObj.created.length > 0 ? listObj.created[0] : null;
                return this.accessObject([], [nAddress], [])
              })
              .subscribe(res => {
                obs.next(res.updated[0])
                obs.complete();
              }, err => {
                obs.error(err);
              })
          }
          break;
        }
        // case AddressAction.Delete: {
        //   this.accessObject([], [], [nAddress, nGAddress])
        //     .subscribe(res => {
        //       obs.next(null);
        //       obs.complete();
        //     }, err => {
        //       obs.error(err);
        //     })
        // }
      }
    })

    return objObs;
  }

  private updateObjectSite(resp): Observable<any> {
    let valueOfForm = this.siteDetailForm.value;

    if (!this.logoImg) {
      this.objectSite.Logo = null;
    } else {
      if (resp.length > 0 && resp[2]) {
        this.objectSite.Logo = { FileToken: resp[2].token }
      }
    }

    this.objectSite.SiteName = valueOfForm.siteName;
    this.objectSite.InformationServices = valueOfForm.service.map(x => x.ObjectID);

    this.objectSiteInformation.Phone = valueOfForm.phone;
    this.objectSiteInformation.Fax = valueOfForm.fax;
    this.objectSiteInformation.Email = valueOfForm.email;
    this.objectSiteInformation.Recipients = valueOfForm.email2;
    this.objectSiteInformation.Website = valueOfForm.website;
    this.objectSiteInformation.Rating = valueOfForm.rating ? valueOfForm.rating.ObjectID : null;
    this.objectSiteInformation.State = valueOfForm.state ? valueOfForm.state.ObjectID : null;
    this.objectSiteInformation.Division = valueOfForm.division ? valueOfForm.division.ObjectID : null;
    this.objectSiteInformation.Industry = valueOfForm.industry ? valueOfForm.industry.ObjectID : null;
    this.objectSiteInformation.Address = resp.length > 0 && resp[0] ? resp[0] : this.objectSiteInformation.Address;
    this.objectSiteInformation.PostalAddress = resp.length > 0 && resp[1] ? resp[1] : this.objectSiteInformation.PostalAddress;

    return this.accessObject([], [this.objectSiteInformation, this.objectSite], []);
  }

  private setActiveSite(value: boolean) {
    let obj = {
      ObjectClass: 'prosek.orm.Site',
      ObjectID: this.objectSite.ObjectID,
      Active: value
    }
    this.helperService.showLoading();

    this.accessObject([], [obj], [])
      .subscribe(res => {
        if (res && res.updated && res.updated.length > 0) {
          this.objectSite.Active = value;
        } else {
          if (value) {
            this.showSummaryError('Set active site fail!');
          } else {
            this.showSummaryError('Set disactive site fail!');
          }
        }
        this.helperService.hideLoading();
      }, err => {

        if (value) {
          this.showSummaryError('Set active site fail!');
        } else {
          this.showSummaryError('Set disactive site fail!');
        }
        this.helperService.hideLoading();
      })
  }

  showAddOrEditTimelineModal(type) {
    this.addOrEditTimelineModal.initParams(null, type, null, null, this.siteId);
    this.addOrEditTimelineModal.show();
  }

  showAddNotesModal() {
    this.addNotesModal.initParams(null, null, null, this.siteId);
    this.addNotesModal.show();
  }

  saveTimelineSuccessed(event) {
    this.timelineTable.saveTimelineSuccessed(event);
  }

  saveNoteSuccessed(event) {
    this.timelineTable.saveNoteSuccessed(event);
  }

  private loadLogo(event: any): any {
    var reader = new FileReader();
    reader.onload = () => {
      var dataURL = reader.result;
      this.logoImg = dataURL;
    };
    reader.readAsDataURL(event[0]);
  }

  private uploadLogo() {
    let objObs = new Observable(obs => {
      if (this.uploader.queue.length == 0) {
        obs.next(null);
        obs.complete();
      } else {
        this.uploader.queue.forEach(item => {
          item.upload();
        });
      }

      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          let resp = JSON.parse(response);
          if (resp.files && resp.files.length > 0) {
            obs.next(resp.files[0]);
            obs.complete();
          } else {
            obs.error('Upload photo fail');
          }
        } else {
          obs.error('Upload photo fail');
        }
      };

    })

    return objObs;
  }

  private clearLogoSelected() {
    this.uploader.clearQueue();
    this.logoImg = this.oldLogo;
  }

  private removeLogo() {
    this.logoImg = null;
    this.oldLogo = null;
  }

  private goCheckpoint() {
    this.router.navigate(['/sites/check-point/', this.siteID]);
  }

  validateService(event) {
    if (!this.filteredServiceMultiple || (this.filteredServiceMultiple && this.filteredServiceMultiple.length == 0)) {
      event.target.value = "";
    }
  }

  viewClient() {
    this.router.navigate(this.preLink);
  }
}
