import { AttachmentsModule } from './../subs/attachments/attachments.module';
import { ModalModule } from 'ngx-bootstrap/modal/modal.module';
import { SharedProsekModule } from './../../shared/shared.module';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FilterModule } from '../filter/filter.module';
import { DataTableModule } from 'primeng/datatable';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { ButtonModule } from 'primeng/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng4GeoautocompleteModule } from 'ng4-gmap-autocomplete';
import { FileUploadModule } from 'ng2-file-upload';
import { ImagePreviewDirective } from './../../directives/image-preview.directive';
import { SignaturePadModule } from 'angular2-signaturepad';
import { CalendarModule } from 'primeng/calendar';

import { SitesComponent } from './sites.component';
import { SitesService } from './sites.service';
import { SitesDetailComponent } from './sites-detail/sites-detail.component';
import { TimelineModule } from '../subs/timeline/timeline.module';
import { AddOrEditTimelineModule } from '../subs/modals/add-or-edit-timeline/add-or-edit-timeline.module';
import { AddNoteModalModule } from '../subs/modals/add-note-modal/add-note-modal.module';
import { ContactsModule } from '../subs/contacts/contacts.module';

import { SearchReportComponent } from './search-report/search-report.component';
import { ReportNotificationComponent } from './report-notification/report-notification.component';
import { ReportDetailComponent } from './report-detail/report-detail.component';
import { CheckPointComponent } from './check-point/check-point.component';
import { PatrolScheduleComponent } from './patrol-schedule/patrol-schedule.component';

import { MomentModule } from 'angular2-moment';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { BannedEmployeesModule } from '../subs/banned-employees/banned-employees.module';
import { ContractDetailsModule } from '../subs/contract-details/contract-details.module';

import { CKEditorModule } from 'ng2-ckeditor';
import { AddPatrolSchedulingComponent } from './add-patrol-scheduling/add-patrol-scheduling.component';
import { AddEditCheckpointComponent } from './check-point/add-edit-checkpoint/add-edit-checkpoint.component';
import { SiteMapComponent } from './site-map/site-map.component';

const routing: Routes = [
  { path: '', component: SitesComponent }
];

const Routing: ModuleWithProviders = RouterModule.forChild(routing);

@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    Routing,
    FilterModule,
    DropdownModule,
    ButtonModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    Ng4GeoautocompleteModule.forRoot(),
    TimelineModule,
    AddOrEditTimelineModule,
    AddNoteModalModule,
    ContactsModule,
    ModalModule.forRoot(),
    CKEditorModule,
    FileUploadModule,
    MomentModule,
    DateTimePickerModule,
    BannedEmployeesModule,
    ContractDetailsModule,
    SharedProsekModule,
    SignaturePadModule,
    CalendarModule,
    AttachmentsModule
  ],
  declarations: [
    SitesComponent,
    SitesDetailComponent,
    SearchReportComponent,
    ReportNotificationComponent,
    ReportDetailComponent,
    AddPatrolSchedulingComponent,
    CheckPointComponent,
    AddEditCheckpointComponent,
    PatrolScheduleComponent,
    SiteMapComponent,

    // ImagePreviewDirective
  ],
  providers: [
    SitesService
  ]
})
export class SitesModule { }
