import { TestBed, inject } from '@angular/core/testing';

import { RosteringService } from './rostering.service';

describe('RosteringService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RosteringService]
    });
  });

  it('should be created', inject([RosteringService], (service: RosteringService) => {
    expect(service).toBeTruthy();
  }));
});
