import { tassign } from 'tassign';
import * as constant from './actions';

export interface RosteringState {
    age: number;
    sites: any;
    positions: any;
    industries: any;
    rating: any;
    employees: any;
    shiftStatus: any;
    dayOfWeekTypes: any;
    shiftTypes: any;
    filterModel: any;
}

export const ROSTERING_INITAL_STATE: RosteringState = {
    age: 0,
    sites: null,
    positions: null,
    industries: null,
    rating: null,
    employees: null,
    shiftStatus: null,
    dayOfWeekTypes: null,
    shiftTypes: null,
    filterModel: null
};


export function rosteringReducer(state = ROSTERING_INITAL_STATE, action): RosteringState {
    switch (action.type) {
        case constant.ROSTERING_SAVE_FILTER_CALENDER: return tassign(state, { filterModel: action.payload });
        case constant.ROSTERING_SAVE_SITES: return tassign(state, { sites: action.payload });
        case constant.ROSTERING_SAVE_POSITIONS: return tassign(state, { positions: action.payload });
        case constant.ROSTERING_SAVE_INDUSTRIES: return tassign(state, { industries: action.payload });
        case constant.ROSTERING_SAVE_RATING: return tassign(state, { rating: action.payload });
        case constant.ROSTERING_SAVE_EMPLOYEES: return tassign(state, { employees: action.payload });
        case constant.ROSTERING_SAVE_SHIFT_STATUS: return tassign(state, { shiftStatus: action.payload });
        case constant.ROSTERING_SAVE_DAY_OF_WEEK: return tassign(state, { dayOfWeekTypes: action.payload });
        case constant.ROSTERING_SAVE_SHIFT_TYPES: return tassign(state, { shiftTypes: action.payload });
    }

    return state;
}
