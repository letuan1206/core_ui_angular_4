import { ROSTERING_SELECT_TYPE, ROSTER_TEMPLATE_TYPE } from './../common/constants';
import { SaveShiftTemplateWSFP } from './../../models/rostering';
import { FormBuilder, Validators } from '@angular/forms';
import { ApiService } from './../../services/api.service';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { RosteredShift } from '../../models/rostering';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class RosteringService {

  constructor(
    private api: ApiService,
    private fb: FormBuilder,
  ) { }

  renderFormAddShift(rosteredShift: SaveShiftTemplateWSFP) {
    let form = this.fb.group({
      ShiftType: [rosteredShift.ShiftType],
      StartDate: [rosteredShift.EffectiveFromDate, [Validators.required]],
      EndDate: [rosteredShift.EffectiveUntilDate],
      Cyclic: [rosteredShift.CycleWeek],
      StartTime: [rosteredShift.StartTime, [Validators.required]],
      BreakStart: [rosteredShift.BreakStartTime],
      BreakEnd: [rosteredShift.BreakEndTime],
      FinishTime: [rosteredShift.EndTime, [Validators.required]],
      RosterComments: [rosteredShift.RosterComments],
      DayOfWeek: [rosteredShift.DaysOfWeek],
      ShiftStatus: [],
      Employee: [rosteredShift.Employee],
      Industry: [rosteredShift.Industry, [Validators.required]],
      Site: [rosteredShift.Site],
      Position: [rosteredShift.Position, [Validators.required]],
    });

    return form;
  }

  renderFormChangeTime(rosteredShift: any) {
    return this.fb.group({
      ShiftType: [rosteredShift.ShiftType],
      EffectiveFromDate: [rosteredShift.EffectiveFromDate],
      EffectiveUntilDate: [],
      StartTime: [],
      EndTime: []
    });
  }

  getDayOfTheWeek() {
    return [
      {
        description: 'All',
        value: 'ALL',
        status: false
      },
      {
        description: 'Mon',
        value: 'MON',
        status: false
      },
      {
        description: 'Tue',
        value: 'TUE',
        status: false
      },
      {
        description: 'Wed',
        value: 'WED',
        status: false
      },
      {
        description: 'Thu',
        value: 'THU',
        status: false
      },
      {
        description: 'Fri',
        value: 'FRI',
        status: false
      },
      {
        description: 'Sat',
        value: 'SAT',
        status: false
      },
      {
        description: 'Sun',
        value: 'SUN',
        status: false
      }
    ];
  }

  saveShiftTemplate(data): Observable<any> {
    let params = {
      formParams: data
    }

    return this.api.post(`/SaveShiftTemplate`, params)
      .map(res => res);
  }

  autoSelectDateRange(filterType, dateChoose) {
    if (filterType === ROSTERING_SELECT_TYPE.WEEK) {
      return [
        moment(dateChoose).startOf('isoWeek').format('YYYY-MM-DD'),
        moment(dateChoose).endOf('isoWeek').format('YYYY-MM-DD')
      ];
    } else if (filterType === ROSTERING_SELECT_TYPE.MONTH) {
      let startDate = moment(dateChoose).startOf('isoWeek').format('YYYY-MM-DD');
      let endDate = moment(startDate).add(4, 'weeks').format('YYYY-MM-DD');
      endDate = moment(endDate).subtract(1, 'days').format('YYYY-MM-DD');

      return [
        startDate,
        endDate
      ];
    } else {
      return [
        moment(dateChoose).format('YYYY-MM-DD'),
        moment(dateChoose).format('YYYY-MM-DD')
      ];
    }
  }

  resetAssignEmployeeModel() {
    return {
      shiftType: ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT,
      effectiveFrom: null,
      effectiveUntil: null
    };
  }

  saveShiftChange(data, type: boolean): Observable<any> {
    let params = {
      formParams: data
    }

    if (type) {
      return this.api.post(`/PermanentChange`, params)
        .map(res => res);
    } else {
      return this.api.post(`/AdHocChange`, params)
        .map(res => res);
    }
  }

  calculateShiftDuration(timeWork, timeBreak) {
    if (!Number.isNaN(timeWork)) {
      if (!Number.isNaN(timeBreak)) {
        return (timeWork - timeBreak).toString();
      } else {
        return timeWork.toString();
      }
    }
  }

  saveChangeShiftTime(data): Observable<any> {
    let params = {
      formParams: data
    }

    return this.api.post(`/ChangeShiftTime`, params)
      .map(res => res);
  }

  getRosteredDatesWithParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: ['ShiftDetails', 'ShiftTemplate'],
        queryParams: data
      };

      this.api.post(`/RosteredDates`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getShiftTemplatesWithParams(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: ['ShiftDetails'],
        queryParams: data
      };

      this.api.post(`/ShiftTemplates`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getAvailableEmployees(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: []
      };

      this.api.post(`/AvailableEmployees`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getShiftStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: []
      };

      this.api.post(`/ShiftStatuses`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getShiftTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: []
      };

      this.api.post(`/ShiftTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getDayOfWeekTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        assocs: []
      };

      this.api.post(`/DayOfWeekTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  ordinalSuffixOf(i) {
    var j = i % 10,
      k = i % 100;
    if (j == 1 && k != 11) {
      return "st";
    }
    if (j == 2 && k != 12) {
      return "nd";
    }
    if (j == 3 && k != 13) {
      return "rd";
    }
    return "th";
  }

  sortUserData(userData: any) {
    let users = [];
    let evens = _.remove(userData, (s: any) => {
      return typeof s.ObjectID === 'number';
    });
    evens = _.sortBy(evens, ['ObjectID']);
    users = _.concat(userData, evens);
    return users;
  }

  getMaxUnassignedRow(data: any) {
    if (data.length && typeof data[data.length - 1].ObjectID === 'number') {
      return data[data.length - 1].ObjectID + 1;
    } else {
      return 0;
    }
  }

  getColorStatus(shift) {
    if (!shift.Employee) {
      return '#ff0000';
    }

    if (shift.ShiftStatus.Value === 'CONFIRMED') {
      return '#bdd7ee';
    } else if (shift.ShiftStatus.Value === 'UNCONFIRMED') {
      return '#ffc000';
    } else if (shift.ShiftStatus.Value === 'VERIFIED') {
      return '#a9d18e';
    }
  }

  calculateTotalTimeShiftTemplate(userId, shiftData) {
    let shiftUser = [];
    let totalHours = 0;
    shiftData.forEach(element => {
      if (typeof userId !== 'number') {
        element.listData.forEach(lData => {
          if (lData.items.length) {
            lData.items.forEach(shift => {
              if (userId === shift.Employee) {
                totalHours += parseFloat(shift.WorkHours);
              }
            });
          }
        });
      } else {
        element.listDragDrop.forEach(lData => {
          if (lData.items.length) {
            lData.items.forEach(shift => {
              if (userId === shift.UnassignedRowNumber) {
                totalHours += parseFloat(shift.WorkHours);
              }
            });
          }
        });
      }
    });

    return totalHours;
  }
}
