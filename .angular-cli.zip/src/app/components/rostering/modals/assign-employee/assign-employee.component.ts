import { AdHocChange } from './../../../../models/rostering';
import { ActivatedRoute } from '@angular/router';
import { ConfigService } from './../../../../services/config.service';
import { HelperService } from './../../../../services/helper.service';
import { ApiService } from './../../../../services/api.service';
import { RosteringService } from './../../rostering.service';
import { ConfigurationService } from './../../../configuration/configuration.service';
import { ModalDirective } from 'ng2-bootstrap';
import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';
import * as _ from 'lodash';
import { NgRedux, select } from 'ng2-redux';
import { ROSTER_TEMPLATE_TYPE } from '../../../common/constants';

@Component({
  selector: 'app-assign-employee',
  templateUrl: './assign-employee.component.html',
  styleUrls: ['./assign-employee.component.scss']
})
export class AssignEmployeeComponent implements OnInit {
  @ViewChild('modalAssignEmployee') public modalAssignEmployee: ModalDirective;
  @Output('checkedChange') change = new EventEmitter<any>();

  showAdHocBtn = true;
  shiftDatas = [];
  siteData: any;
  employees = [];
  isPermanent = true;
  shiftTypes: any;
  shiftModel = {
    shiftType: ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT,
    effectiveFrom: null,
    effectiveUntil: null
  };

  shiftChangeModel: AdHocChange;
  responseStatus: any;
  errorMessages: any;

  @select(s => s.rostering.shiftTypes) rdShiftTypes;

  constructor(
    private configurationService: ConfigurationService,
    private rosterService: RosteringService,
    private apiService: ApiService,
    private helperService: HelperService,
    private configService: ConfigService,
    private ngRedux: NgRedux<any>,
    private _activatedRoute: ActivatedRoute
  ) {
    this.responseStatus = this.configService.get('status');
  }

  ngOnInit() {
    this.loadAvaiableEmployees();
    this.loadStoreData();
  }

  resetModel() {
    this.isPermanent = true;
    this.shiftModel = {
      shiftType: ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT,
      effectiveFrom: null,
      effectiveUntil: null
    };
  }

  shiftTypeChange(value) {
    console.log(value);
    this.shiftModel.shiftType = value;
    this.isPermanent = true;
    if (this.shiftModel.shiftType !== ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT) {
      this.isPermanent = false;
    }
  }

  selectEmployee(index) {
    this.employees.forEach((element, eIndex) => {
      if (index === eIndex) {
        element.Select = true;
      } else {
        element.Select = false;
      }
    });
  }

  resetSelectEmployee() {
    this.employees.forEach((element, eIndex) => {
      element.Select = false;
    });
  }

  saveAvaiableEmployee() {
    let employee = _.find(this.employees, s => s.Select === true);

    let shiftTemplateIDs = [];

    this.shiftDatas.forEach(element => {
      let templateID = element.SourceTemplate.split(':');
      shiftTemplateIDs.push(parseInt(templateID[1]));
    });

    this.shiftChangeModel.ShiftTemplatesToChange = shiftTemplateIDs;
    this.shiftChangeModel.Employee = employee.Employee;

    this.shiftChangeModel.EffectiveFromDate = moment(this.shiftModel.effectiveFrom).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');

    if (!this.isPermanent) {
      this.shiftChangeModel.EffectiveUntilDate = moment(this.shiftModel.effectiveUntil).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    } else {
      this.shiftChangeModel.EffectiveUntilDate = null;
    }

    this.helperService.showLoading();
    this.rosterService.saveShiftChange(this.shiftChangeModel, this.isPermanent).subscribe(res => {
      console.log('assign', res);
      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperService.hideLoading();
        return;
      }
      this.errorMessages = null;
      this.emitChangeValue();
      // this.helperService.hideLoading();
      this.hide();
    }, error => {
      this.errorMessages = error.error.errorDetails;
      this.helperService.hideLoading();
      console.log(error);

    });

    console.log(this.shiftChangeModel);
  }

  loadAvaiableEmployees() {
    this.employees = [];
    this.rosterService.getAvailableEmployees().then(res => {
      res.results.forEach(element => {
        let employee = _.get(res.references, element);
        employee.Select = false;
        this.employees.push(employee);
      });
    });
  }

  show(data, typeShow = false) {
    this.errorMessages = null;
    this.showAdHocBtn = typeShow;
    this.shiftChangeModel = new AdHocChange();
    this.resetModel();
    this.resetSelectEmployee();
    this.shiftTypeChange(data.ShiftAction);
    console.log(data);

    console.log(this.shiftChangeModel);
    this.shiftDatas = [];
    this.siteData = data.Site;
    data.ShiftData.forEach(element => {
      if (element.length) {
        this.shiftDatas = this.shiftDatas.concat(element);
      }
    });

    this.shiftDatas.forEach(element => {
      element.ShiftFormat = `${moment(element.Date).utc().format('ddd Do')} ${moment(element.ShiftDetailsObject.StartTime).utc().format('HHmm')} to ${moment(element.Date).utc().format('ddd Do')} ${moment(element.ShiftDetailsObject.EndTime).utc().format('HHmm')} ${element.WorkHours} Hrs`;
    });

    let firstShift: any = _.minBy(this.shiftDatas, 'Date');

    console.log('fistShift', firstShift);

    this.shiftChangeModel.EffectiveFromDate = moment(firstShift.Date).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.shiftModel.effectiveFrom = this.shiftChangeModel.EffectiveFromDate;
    this.shiftModel.effectiveUntil = this.shiftChangeModel.EffectiveFromDate;

    if (data.IsRostering) {
      this.shiftChangeModel.EffectiveFromDate = moment(data.EffectiveFrom).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    }

    if (!this.isPermanent) {

      this.shiftChangeModel.EffectiveUntilDate = moment(data.EffectiveFrom).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    }

    console.log(this.shiftDatas);
    if (this.shiftDatas.length) {
      setTimeout(() => this.modalAssignEmployee.show(), 500);
    }
  }

  hide() {
    this.modalAssignEmployee.hide();
  }

  loadStoreData() {
    this.rdShiftTypes.subscribe(data => {
      if (data) {
        this.shiftTypes = data;
      }
    });
  }

  emitChangeValue() {
    let params = {
      isAddTemplate: false,
      employee: ''
    }
    this.change.emit(params);
  }
}
