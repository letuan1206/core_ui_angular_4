import { ConfigService } from './../../../../services/config.service';
import { ApiService } from './../../../../services/api.service';
import { HelperService } from './../../../../services/helper.service';
import { RosteredShift, ShiftDetails, ShiftTemplate, SaveShiftTemplateWSFP, AdHocChange } from './../../../../models/rostering';
import { RosteringService } from './../../rostering.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { select } from 'ng2-redux';
import { IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import * as moment from 'moment';
import * as _ from 'lodash';
import { ROSTER_TEMPLATE_TYPE, textMask } from '../../../common/constants';
import createAutoCorrectedDatePipe from 'text-mask-addons/dist/createAutoCorrectedDatePipe';

@Component({
  selector: 'app-add-shift',
  templateUrl: './add-shift.component.html',
  styleUrls: ['./add-shift.component.scss']
})
export class AddShiftComponent implements OnInit {
  @ViewChild('modalAddShift') public modalAddShift: ModalDirective;
  @Input() siteChoose: any;
  @Output('checkedChange') change = new EventEmitter<any>();

  public maskTimeFormat = textMask.maskTimeFormat;
  autoCorrectedDatePipe: any = createAutoCorrectedDatePipe('HH:MM');

  formAddShift: FormGroup;
  rosterModel: RosteredShift;
  shiftDetailsModel: ShiftDetails;
  shiftTemplateModel: ShiftTemplate;
  shiftChangeModel: AdHocChange;
  saveShiftTemplateModel: SaveShiftTemplateWSFP;

  employees = [];
  rating: any;
  industries: any;
  positions: any;
  sites: any;
  shiftStatus: any;
  shiftTypes: any;

  dayOfTheWeek: any;
  isCheckAllDay = false;

  @select(s => s.rostering.dayOfWeekTypes) rdDayOfWeekTypes;
  @select(s => s.rostering.employees) rdEmployees;
  @select(s => s.rostering.rating) rdRating;
  @select(s => s.rostering.industries) rdIndustries;
  @select(s => s.rostering.positions) rdPositions;
  @select(s => s.rostering.sites) rdSites;
  @select(s => s.rostering.shiftStatus) rdShiftStatus;
  @select(s => s.rostering.shiftTypes) rdShiftTypes;

  siteOptions: any;
  isPermanentShift = false;
  isAddTemplate = false;
  isEditShift = false;

  mySettings: IMultiSelectSettings = {
    enableSearch: true,
    dynamicTitleMaxItems: 1,
    selectionLimit: 1,
    closeOnSelect: true,
    autoUnselect: true
  };

  responseStatus: any;
  errorMessages: any;
  viewModel = {
    titleDescription: 'Add Shift',
    shiftDuration: 0,
    ratingDescription: '',
    employeeStatus: '',
    action: ''
  }

  validatorMes = {
    EndTime: null,
    BreakFrom: null,
    BreakTo: null,
    DateUntil: null
  }

  constructor(
    private rosteringService: RosteringService,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
  ) {
    this.rosterModel = new RosteredShift();
    this.saveShiftTemplateModel = new SaveShiftTemplateWSFP();
    this.responseStatus = this.configService.get('status');
  }

  ngOnInit() {
    this.loadStoreData();
    this.customFromAddShift();


  }

  onChanges(): void {

  }

  customFromAddShift() {
    this.formAddShift = this.rosteringService.renderFormAddShift(this.saveShiftTemplateModel);
    this.formAddShift.valueChanges.subscribe(() => {
      // console.log(this.formAddShift.value);
    });
    this.calculateShiftDuration();
  }

  changeDayStatus(index) {
    this.dayOfTheWeek[index].isCheck = !this.dayOfTheWeek[index].isCheck;
    this.checkStatusSelectAllDay();
  }

  testBlur() {
    console.log('blur');
  }

  checkStatusSelectAllDay() {
    let numDays = this.dayOfTheWeek.filter(element => element.isCheck === false);

    if (numDays.length) {
      this.isCheckAllDay = false;
    } else {
      this.isCheckAllDay = true;
    }
  }

  checkSelectAllDay() {
    if (!this.isCheckAllDay) {
      this.dayOfTheWeek.forEach(element => {
        element.isCheck = true;
      });
    } else {
      this.resetSelectAllDayBox();
    }
  }

  resetSelectAllDayBox() {
    this.dayOfTheWeek.forEach(element => {
      element.isCheck = false;
    });
  }

  shiftTypeChange(value) {
    this.isPermanentShift = false;
    this.formAddShift.controls['ShiftType'].setValue(ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT);

    if (value === ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT) {
      this.formAddShift.controls['ShiftType'].setValue(ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT);
      this.isPermanentShift = true;
    }
    console.log(this.formAddShift.get('ShiftType'));
  }

  selectEmployee() {
    let employee = _.find(this.employees, s => s.ObjectID === this.formAddShift.value.Employee);
    console.log(employee);
    if (employee) {
      this.viewModel.ratingDescription = employee.RatingDetails ? employee.RatingDetails.Description : '';
      if (employee.UserDetails.Enabled) {
        this.viewModel.employeeStatus = 'Active';
      } else {
        this.viewModel.employeeStatus = 'Deactive';
      }
    } else {
      this.viewModel.employeeStatus = '';
      this.viewModel.ratingDescription = '';
    }
    console.log(employee);
  }

  resetViewModel() {
    this.viewModel.employeeStatus = '';
    this.viewModel.ratingDescription = '';
  }

  calculateShiftDuration() {
    let startTime = null;
    let endTime = null;
    let breakStart = null;
    let breakEnd = null;

    if (this.formAddShift.value.StartTime) {
      startTime = moment(this.formAddShift.value.StartTime, 'hh:mm').toDate();
      console.log(startTime);
    }

    if (this.formAddShift.value.BreakStart) {
      breakStart = moment(this.formAddShift.value.BreakStart, 'hh:mm').toDate();
    }

    if (this.formAddShift.value.BreakEnd) {
      breakEnd = moment(this.formAddShift.value.BreakEnd, 'hh:mm').toDate();
    }

    if (this.formAddShift.value.FinishTime) {
      endTime = moment(this.formAddShift.value.FinishTime, 'hh:mm').toDate();
    }


    if (breakStart && breakEnd) {

      if (breakStart < startTime) {
        breakStart = moment(breakStart).add(1, 'days').toDate();
      }

      if (breakEnd < breakStart) {
        let dayStep = moment(breakStart).diff(moment(breakEnd), 'days', true).toFixed(1);
        breakEnd = moment(breakEnd).add(dayStep, 'days').toDate();

        if (breakEnd < breakStart) {
          breakEnd = moment(breakEnd).add(1, 'days').toDate();
        }
      }

      if (endTime < breakEnd) {
        let dayStep = moment(breakEnd).diff(moment(endTime), 'days', true).toFixed(1);
        endTime = moment(endTime).add(dayStep, 'days').toDate();

        if (endTime < breakEnd) {
          endTime = moment(endTime).add(1, 'days').toDate();
        }
      }

    } else {
      if (endTime < startTime) {
        endTime = moment(endTime).add(1, 'days').toDate();
      }
    }

    console.log('startTime', startTime);
    console.log('breakStart', breakStart);
    console.log('breakEnd', breakEnd);
    console.log('endTime', endTime);

    // if (startTime && breakStart) {
    //   if (breakStart < startTime) {
    //     breakStart = moment(breakStart).add(1, 'days');
    //   }
    // }

    // if (breakStart && breakEnd) {

    //   if (breakEnd < breakStart) {
    //     let dayStep = moment(breakStart).diff(moment(breakEnd), 'days', true).toFixed(1);
    //     breakEnd = moment(breakStart).add(dayStep, 'days');

    //     if (breakStart < startTime) {
    //       breakEnd = moment(breakStart).add(1, 'days');
    //     }

    //   }

    // }


    let timeWork = parseFloat(moment(endTime, 'hh:mm').diff(moment(startTime, 'hh:mm'), 'hours', true).toFixed(1));
    let timeBreak = parseFloat(moment(breakEnd, 'hh:mm').diff(moment(breakStart, 'hh:mm'), 'hours', true).toFixed(1));

    if (!Number.isNaN(timeWork)) {
      if (!Number.isNaN(timeBreak)) {
        this.viewModel.shiftDuration = timeWork - timeBreak;
      } else {
        this.viewModel.shiftDuration = timeWork;
      }
      this.viewModel.shiftDuration = parseFloat(this.viewModel.shiftDuration.toFixed(1));
    }

    return {
      startTime: startTime,
      endTime: endTime,
      breakStart: breakStart,
      breakEnd: breakEnd
    }
  }

  emitChangeValue(event) {
    let params = {
      isAddTemplate: this.isAddTemplate,
      employee: this.formAddShift.value.Employee
    }
    this.change.emit(params);
  }

  validatorFromAddShift(formName) {
    let timeWork = 0;
    // if (this.formAddShift.get('FinishTime').touched) {
    //   timeWork = parseFloat(moment(this.formAddShift.value.FinishTime, 'hh:mm').diff(moment(this.formAddShift.value.StartTime, 'hh:mm'), 'minutes', true).toFixed(1));
    //   if (timeWork < 0) {
    //     this.validatorMes.EndTime = 'End time must be after Start time';
    //   } else {
    //     this.validatorMes.EndTime = null;
    //   }
    // }

    if (this.formAddShift.get('BreakStart').touched) {
      // timeWork = parseFloat(moment(this.formAddShift.value.BreakStart, 'hh:mm').diff(moment(this.formAddShift.value.StartTime, 'hh:mm'), 'minutes', true).toFixed(1));
      // if (timeWork < 0) {
      //   this.validatorMes.BreakFrom = 'Break from must be after Start time';
      // } else {
      //   timeWork = parseFloat(moment(this.formAddShift.value.FinishTime, 'hh:mm').diff(moment(this.formAddShift.value.BreakStart, 'hh:mm'), 'minutes', true).toFixed(1));
      //   if (timeWork < 0) {
      //     this.validatorMes.BreakFrom = 'Break from must be before End time';
      //   } else {
      //     this.validatorMes.BreakFrom = null;
      //   }
      // }

      if (this.formAddShift.value.BreakEnd && !this.formAddShift.value.BreakStart) {
        this.validatorMes.BreakFrom = 'Break from is required if Break to is filled';
      } else {
        this.validatorMes.BreakFrom = null;
      }
    }

    if (this.formAddShift.get('BreakEnd').touched) {
      // timeWork = parseFloat(moment(this.formAddShift.value.FinishTime, 'hh:mm').diff(moment(this.formAddShift.value.BreakEnd, 'hh:mm'), 'minutes', true).toFixed(1));
      // if (timeWork < 0) {
      //   this.validatorMes.BreakTo = 'Break to must be before End time';
      // } else {
      //   timeWork = parseFloat(moment(this.formAddShift.value.BreakEnd, 'hh:mm').diff(moment(this.formAddShift.value.BreakStart, 'hh:mm'), 'minutes', true).toFixed(1));
      //   if (timeWork < 0) {
      //     this.validatorMes.BreakTo = 'Break from must be after Break to';
      //   } else {
      //     this.validatorMes.BreakTo = null;
      //   }
      // }

      if (!this.formAddShift.value.BreakEnd && this.formAddShift.value.BreakStart) {
        this.validatorMes.BreakTo = 'Break to is required if Break from is filled';
      } else {
        this.validatorMes.BreakTo = null;
      }
    }

  }

  checkDateUntil() {
    if (!this.isPermanentShift) {
      if (!this.formAddShift.value.EndDate) {
        this.validatorMes.DateUntil = 'Date Until is required';
        return;
      } else {

      }

      this.validatorMes.DateUntil = null;
    }
  }

  saveAddShift() {
    console.log(this.formAddShift);
    this.checkDateUntil();
    let dateSave = this.calculateShiftDuration();

    if (!this.formAddShift.valid || this.validatorMes.BreakFrom || this.validatorMes.BreakTo || this.validatorMes.EndTime || this.validatorMes.DateUntil) {
      this.helperService.markFormGroupTouched(this.formAddShift);
      return;
    }

    console.log(this.saveShiftTemplateModel);
    // if (!this.saveShiftTemplateModel.ObjectID) {
    this.saveShiftTemplateModel.ShiftType = this.formAddShift.value.ShiftType;
    this.saveShiftTemplateModel.StartTime = moment(dateSave.startTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.saveShiftTemplateModel.EndTime = moment(dateSave.endTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');

    if (this.formAddShift.value.BreakStart && this.formAddShift.value.BreakEnd) {
      this.saveShiftTemplateModel.BreakStartTime = moment(dateSave.breakStart).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      this.saveShiftTemplateModel.BreakEndTime = moment(dateSave.breakEnd).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    } else {
      this.saveShiftTemplateModel.BreakStartTime = null;
      this.saveShiftTemplateModel.BreakEndTime = null;
    }
    this.saveShiftTemplateModel.RosterComments = this.formAddShift.value.RosterComments;
    this.saveShiftTemplateModel.Position = this.formAddShift.value.Position;
    if (this.formAddShift.value.Employee) {
      this.saveShiftTemplateModel.Employee = this.formAddShift.value.Employee;
    }
    this.saveShiftTemplateModel.Industry = this.formAddShift.value.Industry;
    this.saveShiftTemplateModel.DaysOfWeek = [];

    if (!this.saveShiftTemplateModel.ObjectID) {
      this.dayOfTheWeek.forEach(element => {
        if (element.isCheck) {
          this.saveShiftTemplateModel.DaysOfWeek.push(element.Value);
        }
      });
    } else {
      let dayEdit = _.find(this.dayOfTheWeek, obj => obj.Value === this.formAddShift.value.DayOfWeek);
      this.saveShiftTemplateModel.DaysOfWeek.push(dayEdit.Value);
    }

    this.saveShiftTemplateModel.Site = this.siteOptions[this.siteChoose[0] - 1].ObjectID;
    this.saveShiftTemplateModel.EffectiveFromDate = moment(this.formAddShift.value.StartDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.saveShiftTemplateModel.EffectiveUntilDate = null;
    if (this.formAddShift.value.Cyclic) {
      this.saveShiftTemplateModel.CycleWeek = parseInt(this.formAddShift.value.Cyclic);
    } else {
      this.saveShiftTemplateModel.CycleWeek = 1
    }

    if (!this.isPermanentShift) {
      if (!this.formAddShift.value.EndDate) {
        this.validatorMes.DateUntil = 'Date Until is required';
        return;
      }
      this.validatorMes.DateUntil = null;
      this.saveShiftTemplateModel.EffectiveUntilDate = moment(this.formAddShift.value.EndDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      this.saveShiftTemplateModel.CycleWeek = 1;

    }

    this.helperService.showLoading();
    this.rosteringService.saveShiftTemplate(this.saveShiftTemplateModel).subscribe(res => {
      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperService.hideLoading();
        return;
      }
      this.errorMessages = null;
      delete this.saveShiftTemplateModel.ObjectID;
      delete this.saveShiftTemplateModel.ObjectClass;
      this.helperService.hideLoading();
      this.hide();
      this.emitChangeValue(true);
    }, error => {
      this.errorMessages = error.error.errorDetails;
      this.helperService.hideLoading();
    });
  }

  loadStoreData() {
    this.rdEmployees.subscribe(data => {
      console.log(data)
      if (data) {
        this.employees = data;
        let employee = {
          UserName: 'Select employee',
          ObjectID: null,
          Rating: null,
          UserDetails: {
            Enabled: false
          }
        }
        this.employees.unshift(employee);
        this.employees = _.uniqBy(this.employees, 'ObjectID');
      }
    });

    this.rdRating.subscribe(data => {
      if (data) {
        this.rating = data;
      }
    });

    this.rdIndustries.subscribe(data => {
      if (data) {
        this.industries = data;
      }
    });

    this.rdPositions.subscribe(data => {
      if (data) {
        this.positions = data;
      }
    });

    this.rdSites.subscribe(data => {
      if (data) {
        this.siteOptions = _.clone(data);
        this.siteOptions.shift();
      }
    });

    this.rdShiftStatus.subscribe(data => {
      if (data) {
        this.shiftStatus = data;
      }
    });

    this.rdDayOfWeekTypes.subscribe(data => {
      if (data) {
        this.dayOfTheWeek = data;
      }
    });

    this.rdShiftTypes.subscribe(data => {
      if (data) {
        this.shiftTypes = data;
      }
    });
  }

  show(shift: any, action: any, dataModel: any) {
    console.log('shift', shift);
    this.isPermanentShift = false;
    this.isAddTemplate = false;
    this.isEditShift = false;
    this.errorMessages = null;
    this.validatorMes = {
      EndTime: null,
      BreakFrom: null,
      BreakTo: null,
      DateUntil: null
    }

    this.employees = _.uniqBy(this.employees, 'ObjectID');

    this.saveShiftTemplateModel = new SaveShiftTemplateWSFP();
    this.saveShiftTemplateModel.EffectiveFromDate = moment().utc().format('YYYY-MM-DD HH:mm:ss');

    if (shift === null) {
      if (action === 'AddShift') {
        this.viewModel.titleDescription = ROSTER_TEMPLATE_TYPE.ADD_SHIFT;
        this.saveShiftTemplateModel.ShiftType = ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT;
        this.saveShiftTemplateModel.EffectiveFromDate = moment(dataModel.dateRange[0]).format('YYYY-MM-DD HH:mm:ss');
        this.saveShiftTemplateModel.EffectiveUntilDate = moment(dataModel.dateRange[0]).format('YYYY-MM-DD HH:mm:ss');
      } else {
        this.isPermanentShift = true;
        this.isAddTemplate = true;
        this.viewModel.titleDescription = ROSTER_TEMPLATE_TYPE.ADD_TEMPLATE;
        this.saveShiftTemplateModel.ShiftType = ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT;
        this.saveShiftTemplateModel.CycleWeek = 1;
        this.saveShiftTemplateModel.EffectiveFromDate = moment(dataModel.dateRange[0]).format('YYYY-MM-DD HH:mm:ss');
      }
      this.resetViewModel();
      this.resetSelectAllDayBox();
    } else {
      if (action === 'AddTemplate') {
        this.isPermanentShift = true;
        this.isAddTemplate = true;
        this.saveShiftTemplateModel.ShiftType = ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT;
        this.saveShiftTemplateModel.EffectiveUntilDate = null;
      } else {
        this.saveShiftTemplateModel.ShiftType = ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT;
        this.saveShiftTemplateModel.EffectiveUntilDate = moment(shift.Date).utc().format('YYYY-MM-DD HH:mm:ss');;
      }

      this.isEditShift = true;
      this.viewModel.titleDescription = ROSTER_TEMPLATE_TYPE.EDIT_SHIFT;
      this.saveShiftTemplateModel.ObjectID = shift.ShiftTemplateObject.ObjectID;
      this.saveShiftTemplateModel.EffectiveFromDate = moment(shift.Date).utc().format('YYYY-MM-DD HH:mm:ss');

      // if (shift.ShiftTemplateObject.EffectiveUntilDate) {
      //   this.saveShiftTemplateModel.EffectiveUntilDate = moment(shift.ShiftTemplateObject.EffectiveUntilDate).utc().format('YYYY-MM-DD HH:mm:ss');
      // }
      this.saveShiftTemplateModel.CycleWeek = shift.ShiftTemplateObject.CycleWeek;
      this.saveShiftTemplateModel.ShiftDetails = shift.ShiftTemplateObject.ShiftDetails;
      this.saveShiftTemplateModel.Source = shift.SourceTemplate;
      this.saveShiftTemplateModel.OriginalAncestor = shift.ShiftTemplateObject.OriginalAncestor;

      this.saveShiftTemplateModel.StartTime = moment(shift.ShiftDetailsObject.StartTime).utc().format('HH:mm');
      this.saveShiftTemplateModel.EndTime = moment(shift.ShiftDetailsObject.EndTime).utc().format('HH:mm');

      this.saveShiftTemplateModel.BreakStartTime = null;
      this.saveShiftTemplateModel.BreakEndTime = null;

      if (shift.ShiftDetailsObject.BreakStartTime) {
        this.saveShiftTemplateModel.BreakStartTime = moment(shift.ShiftDetailsObject.BreakStartTime).utc().format('HH:mm');
      }
      if (shift.ShiftDetailsObject.BreakEndTime) {
        this.saveShiftTemplateModel.BreakEndTime = moment(shift.ShiftDetailsObject.BreakEndTime).utc().format('HH:mm');
      }

      this.calculateShiftDuration();
      this.saveShiftTemplateModel.RosterComments = shift.ShiftDetailsObject.RosterComments;
      this.saveShiftTemplateModel.Employee = shift.ShiftDetailsObject.Employee;
      this.saveShiftTemplateModel.Industry = shift.ShiftDetailsObject.Industry;
      this.saveShiftTemplateModel.Position = shift.ShiftDetailsObject.Position;
      this.saveShiftTemplateModel.DaysOfWeek = shift.ShiftDetailsObject.DayOfWeek ? shift.ShiftDetailsObject.DayOfWeek.Value : null;
      // this.saveShiftTemplateModel.ShiftType = shift.ShiftTemplateObject.ShiftType.Value;

      if (this.saveShiftTemplateModel.ShiftType === ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT) {
        this.isPermanentShift = true;
      }
    }
    this.customFromAddShift();
    this.selectEmployee();
    this.modalAddShift.show();
  }

  hide() {
    this.modalAddShift.hide();
  }

}
