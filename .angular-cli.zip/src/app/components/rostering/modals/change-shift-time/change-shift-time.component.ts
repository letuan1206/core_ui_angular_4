import { AdHocChange } from './../../../../models/rostering';
import { ConfigService } from './../../../../services/config.service';
import { ApiService } from './../../../../services/api.service';
import { HelperService } from './../../../../services/helper.service';
import { RosteringService } from './../../rostering.service';
import { FormGroup } from '@angular/forms';
import { ModalDirective } from 'ng2-bootstrap';
import { Component, OnInit, ViewChild, EventEmitter, Output } from '@angular/core';
import { ROSTER_TEMPLATE_TYPE, textMask } from '../../../common/constants';
import { select } from 'ng2-redux';
import * as moment from 'moment';
import * as _ from 'lodash';
import createAutoCorrectedDatePipe from 'text-mask-addons/dist/createAutoCorrectedDatePipe';

@Component({
  selector: 'app-change-shift-time',
  templateUrl: './change-shift-time.component.html',
  styleUrls: ['./change-shift-time.component.scss']
})
export class ChangeShiftTimeComponent implements OnInit {
  @ViewChild('modalChangeShiftTime') public modalChangeShiftTime: ModalDirective;
  @Output('checkedChange') change = new EventEmitter<any>();

  public maskTimeFormat = textMask.maskTimeFormat;
  autoCorrectedDatePipe: any = createAutoCorrectedDatePipe('HH:MM');

  formChangeTime: FormGroup;
  shiftChange: AdHocChange;
  isPermanent = false;
  showAdHocBtn = true;
  responseStatus: any;
  errorMessages: any;
  isErrors = {
    endTime: false,
    startTime: false
  };
  shiftTypes: any;
  shiftDatas = [];

  employess: any;
  sites: any;

  @select(s => s.rostering.shiftTypes) rdShiftTypes;
  @select(s => s.rostering.employees) rdEmployees;
  @select(s => s.rostering.sites) rdSites;

  validatorMes = {
    StartTime: null,
    EndTime: null
  }

  constructor(
    private rosteringService: RosteringService,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService,
  ) { }

  ngOnInit() {
    this.responseStatus = this.configService.get('status');
    this.shiftChange = new AdHocChange();
    this.customFromChangeTime();
    this.loadStoreData();
  }

  customFromChangeTime() {
    this.formChangeTime = this.rosteringService.renderFormChangeTime(this.shiftChange);
  }

  shiftTypeChange(value) {
    this.isPermanent = false;
    this.formChangeTime.controls['ShiftType'].setValue(ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT);

    if (value === ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT) {
      this.formChangeTime.controls['ShiftType'].setValue(ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT);
      this.isPermanent = true;
    }
    console.log(this.formChangeTime.get('ShiftType'));
  }


  saveChangeShiftTime() {
    console.log(this.formChangeTime);

    if (this.isErrors.startTime || this.isErrors.endTime) {
      return;
    }

    //let dateSave = this.calculateShiftDuration();
    let individualShiftList = [];
    this.shiftDatas.forEach(element => {
      let templateID = element.SourceTemplate.split(':');
      let dateSave = this.calculateShiftDuration(element);
      let item: any = {
        ShiftTemplateID: parseInt(templateID[1]),
        EffectiveFromDate: moment(element.Date).utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
        StartTime: moment(dateSave.startTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]'),
        EndTime: moment(dateSave.endTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]')
      }


      if (!this.isPermanent) {
        item.EffectiveUntilDate = moment(element.ShiftTemplateObject.EffectiveUntilDate).utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      }

      individualShiftList.push(item);
    });

    let params = {
      IndividualShiftList: individualShiftList
    }
    // console.log(individualShiftList);
    // return;
    // this.shiftChange.EffectiveFromDate = this.formChangeTime.value.EffectiveFromDate;
    // if (!this.isPermanent) {
    //   this.shiftChange.EffectiveUntilDate = this.formChangeTime.value.EffectiveUntilDate;
    // }

    // if (this.formChangeTime.value.StartTime) {
    //   this.shiftChange.StartTime = moment(dateSave.startTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    // }
    // if (this.formChangeTime.value.EndTime) {
    //   this.shiftChange.EndTime = moment(dateSave.endTime).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    // }

    this.helperService.showLoading();
    this.rosteringService.saveShiftChange(params, this.isPermanent).subscribe(res => {
      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperService.hideLoading();
        return;
      }
      this.errorMessages = null;
      this.emitChangeValue();
      //this.helperService.hideLoading();
      this.hide();
    }, error => {
      this.errorMessages = error.error.errorDetails;
      this.helperService.hideLoading();
    });
  }

  calculateShiftDuration(data: any) {
    let startTime = null;
    let endTime = null;
    let breakStart = null;
    let breakEnd = null;

    if (data.StartTime) {
      startTime = moment(data.StartTime, 'hh:mm').toDate();
      console.log(startTime);
    }

    if (data.EndTime) {
      endTime = moment(data.EndTime, 'hh:mm').toDate();
    }

    if (endTime < startTime) {
      endTime = moment(endTime).add(1, 'days').toDate();
    }

    console.log('startTime', startTime);
    console.log('endTime', endTime);

    return {
      startTime: startTime,
      endTime: endTime,
    }
  }

  validatorFromAddShift() {
    let timeWork = 0;

    if (this.formChangeTime.value.StartTime && this.formChangeTime.value.EndTime) {
      timeWork = parseFloat(moment(this.formChangeTime.value.EndTime).diff(this.formChangeTime.value.StartTime, 'minutes', true).toFixed(1));
      if (timeWork < 0) {
        this.validatorMes.EndTime = 'End time must be after Start time';
        this.isErrors.endTime = true;
      } else {
        this.validatorMes.EndTime = null;
        this.isErrors.endTime = false;
      }
    }

    if (this.formChangeTime.value.StartTime) {
      let countStartTime = this.shiftDatas.filter(s => {
        let startTime = moment(this.formChangeTime.value.StartTime).format('HH:mm');
        let endTime = moment(s.ShiftDetailsObject.BreakStartTime).utc().format('HH:mm');
        if (!s.ShiftDetailsObject.BreakStartTime) {
          endTime = '23:59';
        }
        return startTime > endTime;
      });

      if (countStartTime.length) {
        this.validatorMes.StartTime = 'Start time must be before Break from time';
        this.isErrors.startTime = true;
      } else {
        countStartTime = this.shiftDatas.filter(s => {
          let startTime = moment(this.formChangeTime.value.StartTime).format('HH:mm');
          let endTime = moment(s.ShiftDetailsObject.EndTime).utc().format('HH:mm');
          return startTime > endTime;
        });

        if (countStartTime.length) {
          this.validatorMes.StartTime = 'Start time must be before End time';
          this.isErrors.startTime = true;
        } else {
          this.validatorMes.StartTime = null;
          this.isErrors.startTime = false;
        }
      }
      console.log(countStartTime);
    }

    if (this.formChangeTime.value.EndTime) {
      let countEndTime = this.shiftDatas.filter(s => {
        let startTime = moment(this.formChangeTime.value.EndTime).format('HH:mm');
        let endTime = moment(s.ShiftDetailsObject.BreakEndTime).utc().format('HH:mm');
        if (!s.ShiftDetailsObject.BreakEndTime) {
          endTime = '00:00';
        }
        return startTime < endTime;
      });

      if (countEndTime.length) {
        this.validatorMes.EndTime = 'End time must be after Break to';
        this.isErrors.endTime = true;
      } else {
        countEndTime = this.shiftDatas.filter(s => {
          let startTime = moment(this.formChangeTime.value.EndTime).format('HH:mm');
          let endTime = moment(s.ShiftDetailsObject.StartTime).utc().format('HH:mm');
          return startTime < endTime;
        });

        if (countEndTime.length) {
          this.validatorMes.EndTime = 'End time must be after Start time';
          this.isErrors.endTime = true;
        } else {
          this.validatorMes.EndTime = null;
          this.isErrors.endTime = false;
        }
      }
    }

  }

  updateTime(event, item, type = 'startTime') {
    if (type === 'startTime') {
      item.StartTime = event;
    } else {
      item.EndTime = event;
    }
  }

  /**
   * 
   * @param data 
   * @param typeShow . true = show Button Ad hoc, False -> disable button Ad hoc
   * @param fromPage .
   */

  show(data: any, typeShow = false, fromPage = 'roster') {
    this.showAdHocBtn = typeShow;
    this.isPermanent = false;
    this.errorMessages = null;
    if (fromPage === 'roster') {
      this.shiftChange.ShiftType = ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT;
    } else {
      this.shiftChange.ShiftType = ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT;
      this.isPermanent = true;
    }

    this.validatorMes = {
      StartTime: null,
      EndTime: null
    }

    let firstShift: any = _.minBy(data, 'Date');
    let shiftTemplateIDs = [];
    data.forEach(element => {
      element.EmployeeDetail = _.find(this.employess, obj => obj.ObjectID === element.Employee);
      element.DayOfWeekStr = moment(element.Date).format('dddd');
      element.StartTime = moment(element.ShiftDetailsObject.StartTime).utc().format('HH:mm');
      element.EndTime = moment(element.ShiftDetailsObject.EndTime).utc().format('HH:mm');
      element.ShiftTemplateObject.EffectiveUntilDate = _.clone(element.Date);
      let templateID = element.SourceTemplate.split(':');
      shiftTemplateIDs.push(parseInt(templateID[1]));
    });
    this.shiftDatas = _.sortBy(data, ['Date']);
    this.shiftChange.ShiftTemplatesToChange = shiftTemplateIDs;
    this.shiftChange.EffectiveFromDate = moment(firstShift.Date).utc().format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.customFromChangeTime();
    console.log(data);
    console.log(this.shiftChange);
    this.modalChangeShiftTime.show();
  }

  hide() {
    this.modalChangeShiftTime.hide();
  }

  loadStoreData() {

    this.rdShiftTypes.subscribe(data => {
      if (data) {
        this.shiftTypes = data;
      }
    });

    this.rdEmployees.subscribe(data => {
      if (data) {
        this.employess = data;
      }
    });

    this.rdSites.subscribe(data => {
      if (data) {
        this.sites = data;
      }
    });
  }

  emitChangeValue() {
    let params = {
      isAddTemplate: false,
      employee: ''
    }
    this.change.emit(params);
  }
}
