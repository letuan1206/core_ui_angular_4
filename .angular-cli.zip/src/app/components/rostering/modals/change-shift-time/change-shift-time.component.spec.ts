import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeShiftTimeComponent } from './change-shift-time.component';

describe('ChangeShiftTimeComponent', () => {
  let component: ChangeShiftTimeComponent;
  let fixture: ComponentFixture<ChangeShiftTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeShiftTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeShiftTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
