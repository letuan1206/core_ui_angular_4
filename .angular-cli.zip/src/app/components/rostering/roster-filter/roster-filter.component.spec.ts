import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RosterFilterComponent } from './roster-filter.component';

describe('RosterFilterComponent', () => {
  let component: RosterFilterComponent;
  let fixture: ComponentFixture<RosterFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RosterFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RosterFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
