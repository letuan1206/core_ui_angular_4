import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roster-filter',
  templateUrl: './roster-filter.component.html',
  styleUrls: ['./roster-filter.component.scss']
})
export class RosterFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
