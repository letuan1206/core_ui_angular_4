import { UserInformationService } from './../../user-information/user-information.service';
import { ModalDirective } from 'ng2-bootstrap';
import { AddShiftComponent } from './../modals/add-shift/add-shift.component';
import { ShiftTemplate } from './../../../models/rostering';
import { AssignEmployeeComponent } from './../modals/assign-employee/assign-employee.component';
import {
  ROSTERING_SAVE_POSITIONS,
  ROSTERING_SAVE_INDUSTRIES,
  ROSTERING_SAVE_EMPLOYEES,
  ROSTERING_SAVE_SHIFT_TYPES,
  ROSTERING_SAVE_DAY_OF_WEEK,
  ROSTERING_SAVE_SHIFT_STATUS,
  ROSTERING_SAVE_RATING,
  ROSTERING_SAVE_SITES,
  ROSTERING_SAVE_FILTER_CALENDER
} from './../actions';
import { ActivatedRoute } from '@angular/router';
import { ConfigService } from './../../../services/config.service';
import { HelperService } from './../../../services/helper.service';
import { ApiService } from './../../../services/api.service';
import { RosteringService } from './../rostering.service';
import { ConfigurationService } from './../../configuration/configuration.service';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import * as moment from 'moment';
import * as _ from 'lodash';
import { ROSTERING_SELECT_TYPE, ROSTER_TEMPLATE_TYPE } from '../../common/constants';
import { IMultiSelectTexts, IMultiSelectSettings } from 'angular-2-dropdown-multiselect';
import { IShContextMenuItem, BeforeMenuEvent } from 'ng2-right-click-menu/src/sh-context-menu.models';
import { DragulaService } from 'drag-drop-angular2';
import { ChangeShiftTimeComponent } from '../modals/change-shift-time/change-shift-time.component';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-roster-template',
  templateUrl: './roster-template.component.html',
  styleUrls: ['./roster-template.component.scss']
})
export class RosterTemplateComponent implements OnInit, AfterViewInit {
  @ViewChild('modalQuickAssign') modalQuickAssign: AssignEmployeeComponent;
  @ViewChild('modalAddShift') modalAddShift: AddShiftComponent;
  @ViewChild('modalChangeShiftTime') modalChangeShiftTime: ChangeShiftTimeComponent;
  @ViewChild('modalSelectChangeTime') public modalSelectChangeTime: ModalDirective;
  @ViewChild('modalSelectQuickAssign') public modalSelectQuickAssign: ModalDirective;
  @select(s => s.rostering.filterModel) rdFilterModel;

  employees: any;
  ratingList: any;
  positionList: any;
  unassignSlots: any;
  filterDataModel = {
    dateRange: [
      moment().startOf('isoWeek').format('YYYY-MM-DD'),
      moment().endOf('isoWeek').format('YYYY-MM-DD')
    ],
    selectType: ROSTERING_SELECT_TYPE.WEEK,
    typeShow: ROSTERING_SELECT_TYPE.WEEK,
    isAllSite: false,
    isFilter: false,
    stateChooseIndex: null,
    stateOptions: null,
    divisionChooseIndex: null,
    divisionOptions: null,
    divisionOptionsOrigin: null,
    siteChooseIndex: null,
    siteOptions: null,
    haveData: false,
  }

  shiftModel = {
    shiftType: ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT,
    effectiveFrom: null,
    effectiveUntil: null
  };


  numberWeek = 'Week';
  siteChoose: number[];
  siteOptions: any;
  siteOptionsData: any;

  stateChoose: number[];
  stateOptions: any;

  divisionChoose: number[];
  divisionOptions: any;
  divisionOptionsOrigin: any;

  templateDataTable = [];
  shiftTemplates: any;
  // Settings configuration
  mySettings: IMultiSelectSettings = {
    enableSearch: true,
    dynamicTitleMaxItems: 1,
    // showCheckAll: true,
    // showUncheckAll: true,
    closeOnSelect: true,
    selectionLimit: 1,
    autoUnselect: true
  };

  // Text configuration
  cfTextSite: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find site',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select Site',
    allSelected: 'All selected',
  };

  cfTextState: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find state',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select State',
    allSelected: 'All selected',
  };

  cfTextDivision: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find division',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select Division',
    allSelected: 'All selected',
  };

  rightItems: IShContextMenuItem[];
  rightShiftItems: IShContextMenuItem[];
  rosterEditList = [];
  rosterEmployeList = [];
  shiftTypes: any;
  eventClickContext: any;
  pageShow: number = 2;

  constructor(
    private configurationService: ConfigurationService,
    private rosterService: RosteringService,
    private apiService: ApiService,
    private helperService: HelperService,
    private configService: ConfigService,
    private userInfoService: UserInformationService,
    private ngRedux: NgRedux<any>,
    private _activatedRoute: ActivatedRoute,
    private dragulaService: DragulaService
  ) {
    dragulaService.onDrop.subscribe((value: any) => {
      console.log(value.indexOfTarget);
      if (value.status === 'success') {
        this.dragSlotTemplate(value);

      }
    });
  }

  ngOnInit() {
    setTimeout(() => {
      this.loadOption()
    });
    this.rightItems = [
      {
        label: '<span class="menu-icon">Edit</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Change Time</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Quick Assign</span>',
        onClick: this.openModalSelectQuickAssign.bind(this)
      },
      {
        label: '<span class="menu-icon">Unconfirm Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Apply Leave</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Unassign Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Comment on Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Award Override</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Copy Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Delete Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      }
    ];

    this.rightShiftItems = this.changeRightClickMenu();

    $(document).on('scroll', () => {
      $("sh-context-overlay").remove();
      $("sh-context-menu").remove();

      var onScrollY = $(document).scrollTop();
      var boxListSize = $('.card.box-list-edi').outerHeight();

      if (this.filterDataModel.selectType === ROSTERING_SELECT_TYPE.MONTH) {
        boxListSize *= 4;
      }

      console.log(this.filterDataModel.selectType);

      if (this.pageShow < this.templateDataTable.length && onScrollY > (this.pageShow - 1) * boxListSize) {
        this.pageShow++;
        this.reRenderTable();
      }
    });
  }

  onBeforeRightItem = (event: BeforeMenuEvent) => {
    event.open(this.rightItems);
    setTimeout(() => {
      var outerHeight = $(document).outerHeight();
      var diffHeight = outerHeight - event.event.pageY;

      if (diffHeight < 340) {
        $("div.sh-context--container").css('top', event.event.y - (340 - diffHeight));
      }
    }, 0);
  };

  onBeforeRightShiftItem = (event: BeforeMenuEvent) => {
    event.open(this.rightShiftItems);
    setTimeout(() => {
      var outerHeight = $(document).outerHeight();
      var diffHeight = outerHeight - event.event.pageY;

      if (diffHeight < 340) {
        $("div.sh-context--container").css('top', event.event.y - (340 - diffHeight));
      }
    }, 0);
  };

  ngAfterViewInit() {
    this.helperService.setThemeDefault();

  }

  dragSlotTemplate(dataTarget) {
    console.log(this.shiftTemplates);
    console.log(dataTarget);
    let shiftTemplate = new ShiftTemplate();
    shiftTemplate.ObjectID = dataTarget.idOfDropElm;
    shiftTemplate.UnassignedSlot = parseInt(dataTarget.indexOfTarget);

    const params = {
      create: {},
      update: {
        'Update:0': shiftTemplate
      },
      delete: {},
    };

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      console.log('res save', res);
      this.helperService.hideLoading();
      this.filterShiftTemplate2();

    });
  }

  rightClickNoEvent($event) {
    console.log($event);
  }

  filterAfterClose() {
    if (this.siteChoose && this.siteChoose.length) {
      this.filterShiftTemplate2();
    }
  }

  openModalChangeShiftTime($event: any) {
    console.log($event)
    if (!this.rosterEditList.length) {
      this.selectShift($event.dataContext);
    }
    this.modalChangeShiftTime.show(this.rosterEditList, false, 'template');
    // this.modalSelectChangeTime.hide();
  }


  opemModalQuickAssignMultiShift($event: any) {
    console.log($event);
    this.shiftModel = this.rosterService.resetAssignEmployeeModel();
    // this.modalSelectQuickAssign.hide();
    let dataSend = [];
    if (this.rosterEditList.length) {
      this.rosterEditList.forEach(item => {
        if (!item.Employee) {
          dataSend.push(item);
        }
      });
      // dataSend.push(this.rosterEditList);
    } else {
      if (!$event.dataContext.Employee) {
        dataSend.push($event.dataContext);
      }
    }

    if (!dataSend.length) {
      return;
    }

    console.log(dataSend);
    this.eventClickContext = [dataSend];
    let dateCurrent: any = _.minBy(dataSend, 'Date');
    this.shiftModel.effectiveFrom = moment(dateCurrent.Date).format('YYYY-MM-DD');

    console.log(this.eventClickContext);
    this.openModalQuickAssign(this.shiftModel);
    // this.modalSelectQuickAssign.show();
  };

  openModalSelectQuickAssign($event) {
    this.shiftModel = this.rosterService.resetAssignEmployeeModel();

    if (this.rosterEmployeList.length > 1) {
      return;
    }

    let slotContext = $event.dataContext;

    if (typeof slotContext.slotName !== 'number') {
      return;
    }

    console.log(slotContext);

    let dateListData = this.templateDataTable[0].TemplateData[slotContext.slotWeek].listDate;
    let dataSend = [];
    dateListData.forEach(item => {
      let listRoster = _.find(item.listDragDrop, element => element.value === slotContext.slotName);
      if (listRoster.items.length) {
        dataSend = _.concat(dataSend, listRoster.items);
      }
    });

    if (!dataSend.length) {
      return;
    }

    let dateCurrent = dataSend[0];
    this.shiftModel.effectiveFrom = moment(dateCurrent.Date).format('YYYY-MM-DD');
    this.eventClickContext = [dataSend];

    this.openModalQuickAssign(this.shiftModel);
  }

  openModalQuickAssign(data) {
    // this.modalSelectQuickAssign.hide();
    let params = {
      Site: this.siteOptions[this.siteChoose[0]],
      ShiftAction: data.shiftType,
      EffectiveFrom: data.effectiveFrom,
      EffectiveUntil: data.effectiveUntil,
      ShiftData: this.eventClickContext
    };

    this.modalQuickAssign.show(params, false);
  };

  selectShift(rosterShift) {
    if (this.filterDataModel.isAllSite) {
      return;
    }
    console.log(rosterShift);

    rosterShift.Selected = !rosterShift.Selected;
    if (rosterShift.Selected) {
      this.rosterEditList.push(_.clone(rosterShift));
    } else {
      _.remove(this.rosterEditList, obj => obj.ObjectID === rosterShift.ObjectID)
    }
    // this.changeRightClickMenu();
    console.log(this.rosterEditList);
  }

  changeRightClickMenu() {
    // if (this.rosterEditList.length > 1) {
    //   this.rightShiftItems = [
    //     {
    //       label: '<span class="menu-icon">Change Time</span>',
    //       onClick: this.openModalChangeShiftTime.bind(this)
    //     }
    //   ];
    // } else {
    //   this.rightShiftItems = [
    //     {
    //       label: '<span class="menu-icon">Edit</span>',
    //       onClick: this.editSingleShift.bind(this)
    //     }
    //   ];
    // }

    // this.rightShiftItems = [
    //   {
    //     label: '<span class="menu-icon">Quick Assign</span>',
    //     onClick: this.opemModalQuickAssignMultiShift.bind(this)
    //   }
    // ];
    return [
      {
        label: '<span class="menu-icon">Edit</span>',
        onClick: this.editSingleShift.bind(this)
      },
      {
        label: '<span class="menu-icon">Change Time</span>',
        onClick: this.openModalChangeShiftTime.bind(this)
      },
      {
        label: '<span class="menu-icon">Quick Assign</span>',
        onClick: this.opemModalQuickAssignMultiShift.bind(this)
      },
      {
        label: '<span class="menu-icon">Unconfirm Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Apply Leave</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Unassign Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Comment on Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Award Override</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Copy Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Delete Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      }
    ];
  }

  editSingleShift($event: any) {
    console.log('clicked ', $event);
    if (this.rosterEditList.length > 1) {
      return;
    }

    this.openModalAddShift($event.dataContext, 'AddTemplate');
  };

  openModalAddShift(shift: any, action: any) {
    this.modalAddShift.show(shift, action, this.filterDataModel);
  }

  selectDateRange(type) {
    this.numberWeek = 'Week';
    if (type === ROSTERING_SELECT_TYPE.DAY) {
      this.filterDataModel.dateRange = [
        moment().format('YYYY-MM-DD'),
        moment().add(0, 'days').format('YYYY-MM-DD')
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.DAY;
    } else if (type === ROSTERING_SELECT_TYPE.WEEK) {
      this.filterDataModel.dateRange = [
        moment().startOf('isoWeek').format('YYYY-MM-DD'),
        moment().endOf('isoWeek').format('YYYY-MM-DD')
        // moment().add(7, 'days').format('YYYY-MM-DD')
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.WEEK;
    } else {
      let startDate = moment().startOf('isoWeek').format('YYYY-MM-DD');
      let endDate = moment(startDate).add(4, 'weeks').format('YYYY-MM-DD');
      endDate = moment(endDate).subtract(1, 'days').format('YYYY-MM-DD');

      this.filterDataModel.dateRange = [
        startDate,
        endDate
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.MONTH;
    }

    if (this.filterDataModel.haveData) {
      this.filterShiftTemplate2();
    }
    console.log(this.filterDataModel)
  }

  onChangeState(stateChoose) {
    this.divisionChoose = [];
    this.divisionOptions = [];

    stateChoose.forEach(sIndex => {
      if (sIndex === 0) {
        this.divisionOptions = _.cloneDeep(this.divisionOptionsOrigin);
      } else {
        this.divisionOptions = this.divisionOptions.concat(this.divisionOptionsOrigin.filter(division => division.State === this.stateOptions[sIndex].ObjectID));
      }
    });
    console.log('change state');
  }

  onChangeSite(siteChoose) {
    console.log(this.siteOptions);
    console.log(this.siteChoose);
  }

  filterSites(event) {
    if (event.length) {

      console.log('event', event)
      let stateID = null;
      let divisionID = null;
      console.log(this.stateChoose)
      if (this.stateChoose && this.stateChoose.length) {
        stateID = this.stateOptions[this.stateChoose[0]].ObjectID;
      }

      divisionID = this.divisionOptionsOrigin[event[0]].ObjectID;

      let params = {
        State: stateID,
        Division: divisionID
      }
      this.siteChoose = [];
      this.siteOptions = [];

      if (divisionID) {
        this.siteOptions = this.siteOptionsData.filter(obj => {
          if (stateID) {
            return obj.Information.State === stateID && obj.Information.Division === divisionID
          } else {
            return obj.Information.Division === divisionID
          }
        });
      } else {
        this.siteOptions = _.cloneDeep(this.siteOptionsData);
      }

      if (this.siteOptions.length > 1) {
        this.siteOptions.unshift({ id: 0, name: 'All Sites', ObjectID: null });
      }

      this.helperService.dispatchToRedux(ROSTERING_SAVE_SITES, this.siteOptions);
    }
  }

  closeDateRange() {
    this.numberWeek = 'Week';
    if (this.filterDataModel.dateRange[1]) {
      console.log(moment(this.filterDataModel.dateRange[0]).isoWeek());
      console.log(moment(this.filterDataModel.dateRange[1]).isoWeek());

      let dayDist = moment(this.filterDataModel.dateRange[1]).diff(moment(this.filterDataModel.dateRange[0]), 'days');

      if (dayDist < 1) {
        this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.DAY;
      } else {
        this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.WEEK;
        let weekDist = moment(this.filterDataModel.dateRange[1]).isoWeek() - moment(this.filterDataModel.dateRange[0]).isoWeek();

        if (weekDist > 0) {
          this.numberWeek = (weekDist + 1) + ' Weeks';
        }
      }
    }
  }

  getFilterModel() {
    this.rdFilterModel.subscribe(data => {
      if (data && data.haveData) {
        this.filterDataModel = data;

        this.stateOptions = data.stateOptions;
        this.divisionOptions = data.divisionOptions;
        this.divisionOptionsOrigin = data.divisionOptionsOrigin;
        this.siteOptions = data.siteOptions;

        setTimeout(() => {
          this.stateChoose = data.stateChooseIndex;
          this.onChangeState(this.stateChoose);
          this.divisionChoose = data.divisionChooseIndex;
          this.siteChoose = data.siteChooseIndex;
          if (data.isFilter) {
            this.filterShiftTemplate2();
          }
        }, 500);
      }
    });
  }

  setFilterModel() {
    this.filterDataModel.stateChooseIndex = this.stateChoose;
    this.filterDataModel.divisionChooseIndex = this.divisionChoose;
    this.filterDataModel.siteChooseIndex = this.siteChoose;
    this.filterDataModel.stateOptions = this.stateOptions;
    this.filterDataModel.divisionOptions = this.divisionOptions;
    this.filterDataModel.divisionOptionsOrigin = this.divisionOptionsOrigin;
    this.filterDataModel.siteOptions = this.siteOptions;
    this.ngRedux.dispatch({
      type: ROSTERING_SAVE_FILTER_CALENDER,
      payload: this.filterDataModel
    });
  }

  autoSelectDateRange() {
    this.filterDataModel.dateRange = this.rosterService.autoSelectDateRange(this.filterDataModel.selectType, this.filterDataModel.dateRange[0]);
  }

  filterShiftTemplate() {
    let stateID = null;
    let divisionID = null;
    let siteID = null;
    this.rosterEditList = [];
    this.dragulaService.destroyAll();
    if (this.stateChoose.length) {
      stateID = this.stateOptions[this.stateChoose[0]].ObjectID;
    }

    if (this.divisionChoose.length) {
      divisionID = this.divisionOptionsOrigin[this.divisionChoose[0]].ObjectID;
    }

    if (this.siteChoose.length) {
      siteID = this.siteOptions[this.siteChoose[0]].ObjectID;
    }

    let queryParams = {
      'FromDate': moment(this.filterDataModel.dateRange[0]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'ToDate': moment(this.filterDataModel.dateRange[1]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'State': stateID,
      'Division': divisionID,
      'Site': siteID
    }

    this.setFilterModel();

    let shiftTemplates = [];
    let startDateCopy = _.clone(this.filterDataModel.dateRange[0]);
    let endDateCopy = _.clone(this.filterDataModel.dateRange[1]);
    let startWeekOfYear = moment(startDateCopy).week();
    let endWeekOfYear = moment(endDateCopy).week() + 1;
    let weekDist = endWeekOfYear - startWeekOfYear;
    let maxUnassignSlot = 1;

    this.helperService.showLoading();
    this.rosterService.getShiftTemplatesWithParams(queryParams).then(res => {
      this.shiftTemplates = res;
      let siteChooses = [];
      this.siteChoose.forEach(sIndex => {
        if (sIndex === 0) {
          this.siteOptions.forEach(element => {
            if (element.id !== 0) {
              siteChooses.push(element.id);
            }
          });
        } else {
          siteChooses.push(sIndex);
        }
      });

      console.log(siteChooses);
      this.templateDataTable = [];
      siteChooses.forEach(siteIndex => {
        let site = this.siteOptions[siteIndex];
        let siteRosters: any;
        let siteData = [];

        res.results.forEach(element => {
          let shiftTpl = _.get(res.references, element);

          if (shiftTpl.ShiftType.Value === ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT) {
            return;
          }

          shiftTpl.ShiftDetailsObject = _.get(res.references, shiftTpl.ShiftDetails);
          shiftTpl.Position = _.find(this.positionList, s => s.ObjectID === shiftTpl.ShiftDetailsObject.Position) || null;
          let timeWork = parseFloat(moment(shiftTpl.ShiftDetailsObject.EndTime).diff(shiftTpl.ShiftDetailsObject.StartTime, 'hours', true).toFixed(1));
          let timeBreak = parseFloat(moment(shiftTpl.ShiftDetailsObject.BreakEndTime).diff(shiftTpl.ShiftDetailsObject.BreakStartTime, 'hours', true).toFixed(1));
          let workHours = 0;

          if (!Number.isNaN(timeWork)) {
            if (!Number.isNaN(timeBreak)) {
              workHours = timeWork - timeBreak;
            } else {
              workHours = timeWork;
            }
          }

          shiftTpl.WorkHours = workHours.toFixed(1);

          if (shiftTpl.UnassignedSlot === null) {
            shiftTpl.UnassignedSlot = 1;
          } else {
            if (shiftTpl.UnassignedSlot >= maxUnassignSlot) {
              maxUnassignSlot = shiftTpl.UnassignedSlot + 1;
            }
          }

          let effectiveWeekDay = moment(shiftTpl.EffectiveFromDate).isoWeekday();
          if (shiftTpl.ShiftDetailsObject.DayOfWeek === null) {
            return;
          }

          let activeDay = moment(moment().isoWeekday(shiftTpl.ShiftDetailsObject.DayOfWeek.Value).format('YYYY-MM-DD')).isoWeekday();

          // Find lastest day
          if (activeDay < effectiveWeekDay) {
            shiftTpl.DateFormat = moment(shiftTpl.EffectiveFromDate).add(7 - effectiveWeekDay + activeDay, 'days').format('YYYY-MM-DD');
          } else {
            shiftTpl.DateFormat = moment(shiftTpl.EffectiveFromDate).add(activeDay - effectiveWeekDay, 'days').format('YYYY-MM-DD');
          }
          // console.log(shiftTpl);

          let shiftTplWeekOfYear = moment(shiftTpl.DateFormat).week();
          // Begin calculate week cycle
          if (shiftTpl.CycleWeek === 1) {
            shiftTpl.DateFormat = moment(shiftTpl.DateFormat).add(startWeekOfYear - shiftTplWeekOfYear, 'weeks').format('YYYY-MM-DD');
          } else {
            let weekAdd = (startWeekOfYear - shiftTplWeekOfYear);
            if (weekAdd <= shiftTpl.CycleWeek) {
              shiftTpl.DateFormat = moment(shiftTpl.DateFormat).add(shiftTpl.CycleWeek, 'weeks').format('YYYY-MM-DD');
            } else {
              let numWeekAdd = parseInt((weekAdd / shiftTpl.CycleWeek).toFixed(0)) * shiftTpl.CycleWeek + shiftTpl.CycleWeek;
              shiftTpl.DateFormat = moment(shiftTpl.DateFormat).add(numWeekAdd, 'weeks').format('YYYY-MM-DD');
            }

          }
          shiftTemplates.push(_.clone(shiftTpl));

          for (var i = 0; i < weekDist; i++) {
            let dateAddTemp = moment(shiftTpl.DateFormat).add(shiftTpl.CycleWeek, 'weeks').format('YYYY-MM-DD');
            if (moment(dateAddTemp).week() > endWeekOfYear) {
              break;
            }

            if (shiftTpl.ShiftType.Value === ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT && moment(dateAddTemp).week() > moment(shiftTpl.EffectiveUntilDate).week()) {
              break;
            }

            // console.log('aaaa', shiftTpl);
            shiftTpl.DateFormat = dateAddTemp;
            shiftTemplates.push(_.clone(shiftTpl));
          }
        });

        _.remove(shiftTemplates, s => {
          return moment(s.DateFormat).week() < moment(s.EffectiveFromDate).week() || s.ShiftDetailsObject.Employee;
        });

        console.log('res', shiftTemplates);
        let startDateNew = moment(startDateCopy).subtract(moment(this.filterDataModel.dateRange[0]).isoWeekday() - 1, 'days').format('YYYY-MM-DD');
        if (moment(this.filterDataModel.dateRange[1]).isoWeekday() !== 7) {
          endDateCopy = moment(endDateCopy).add(7 - moment(this.filterDataModel.dateRange[1]).isoWeekday(), 'days').format('YYYY-MM-DD');
        }

        let dayNumb = Math.abs(moment(endDateCopy).diff(startDateNew, 'days'));

        let shiftDates = [];
        let listDayStr = [];
        let unassignData = [];

        for (var i = 0; i <= dayNumb; i++) {
          let dayStr = moment(startDateNew).add(i, 'days').format('YYYY-MM-DD');
          let dayOfWeekStr = moment(dayStr).format('ddd').toLocaleUpperCase();

          let dayFormatData = {
            dayFormatStr: moment(dayStr).format('YYYY/MM/DD'),
            dayFormat2Str: moment(dayStr).format('YYYY-MM-DD'),
            dayOfWeekStr: moment(dayStr).format('dddd'),
          };

          if (siteChooses.length === 1) {
            try {
              this.dragulaService.setOptions(dayFormatData.dayFormat2Str, null);
            } catch (e) {
              console.log(e)
            }
          }

          listDayStr.push(dayFormatData);
          // format week
          if (i !== 0 && (i + 1) % 7 === 0) {
            let weekData = [];
            let listData = [];
            let listSlot = [];

            for (var slot = 1; slot <= maxUnassignSlot + 1; slot++) {
              weekData = [];
              let slotName = '';

              if (slot !== (maxUnassignSlot + 1)) {
                slotName = 'Unassigned ' + (slot);
              } else {
                slotName = 'Blank';
              }

              let slotData = {
                slotIndex: slot,
                slotName: slotName,
                slotWeek: shiftDates.length
              }

              listSlot.push(slotData);
              listDayStr.forEach(element => {
                let dayData = shiftTemplates.filter(obj => obj.DateFormat === element.dayFormat2Str && obj.UnassignedSlot === slot);
                weekData.push(dayData);
              });
              listData.push(weekData);
            }

            listDayStr.forEach(element => {
              weekData = [];
              for (var slot = 0; slot <= maxUnassignSlot; slot++) {
                let dayData = shiftTemplates.filter(obj => obj.DateFormat === element.dayFormat2Str && obj.UnassignedSlot === slot);
                dayData.forEach(element => {
                  element.Selected = false;
                });

                let dataTmp = {
                  indexParent: slot,
                  type: element.dayFormat2Str,
                  value: '',
                  items: dayData
                }
                weekData.push(dataTmp);
              }
              element.listData = weekData;
            });
            let weekRosterText = '';
            let lengthWeek = shiftDates.length + 1;

            weekRosterText = this.rosterService.ordinalSuffixOf(lengthWeek);

            let shiftData = {
              weekRosterText: weekRosterText,
              listDate: listDayStr,
              listData: listData,
              listSlot: listSlot
            }

            shiftDates.push(shiftData);
            listDayStr = [];
          }
        }

        let templateDt = {
          SiteName: site.SiteName,
          TemplateData: shiftDates
        }

        this.templateDataTable.push(templateDt);
      });

      console.log(this.templateDataTable);
      this.filterDataModel.isFilter = true;
      this.filterDataModel.haveData = true;
      this.helperService.hideLoading();
    });
  }

  getColorStatus(shift) {
    return this.rosterService.getColorStatus(shift);
  }

  selectEmployee(user) {
    if (this.filterDataModel.isAllSite) {
      return;
    }

    user.selected = !user.selected;

    if (user.selected) {
      this.rosterEmployeList.push(_.clone(user));
    } else {
      _.remove(this.rosterEmployeList, obj => obj.slotName === user.slotName)
    }

    console.log(this.rosterEmployeList);
  }

  filterShiftTemplate2() {
    let stateID = null;
    let divisionID = null;
    let siteID = null;
    this.rosterEditList = [];
    this.dragulaService.destroyAll();
    if (this.stateChoose && this.stateChoose.length) {
      stateID = this.stateOptions[this.stateChoose[0]].ObjectID;
    }

    if (this.divisionChoose && this.divisionChoose.length) {
      divisionID = this.divisionOptionsOrigin[this.divisionChoose[0]].ObjectID;
    }

    if (this.siteChoose && this.siteChoose.length) {
      siteID = this.siteOptions[this.siteChoose[0]].ObjectID;
    }

    let queryParams = {
      'FromDate': moment(this.filterDataModel.dateRange[0]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'ToDate': moment(this.filterDataModel.dateRange[1]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'State': stateID,
      'Division': divisionID,
      'Site': siteID,
      'TemplatesOnly': true
    }

    this.setFilterModel();

    let shiftTemplates = [];
    let startDateCopy = _.clone(this.filterDataModel.dateRange[0]);
    let endDateCopy = _.clone(this.filterDataModel.dateRange[1]);

    this.helperService.showLoading();
    this.rosterService.getRosteredDatesWithParams(queryParams).then(res => {
      this.shiftTemplates = res;

      let shiftTemplates = [];
      let siteChooses = [];

      this.siteChoose.forEach(sIndex => {
        if (sIndex === 0) {
          this.siteOptions.forEach(element => {
            if (element.id !== 0) {
              siteChooses.push(element.id);
            }
          });
          this.filterDataModel.isAllSite = true;
          this.rightShiftItems = [];
        } else {
          this.filterDataModel.isAllSite = false;
          this.rightShiftItems = this.changeRightClickMenu();
          siteChooses.push(sIndex);
        }
      });

      this.templateDataTable = [];
      siteChooses.forEach((siteIndex, index) => {

        if (index > 0) {
          return;
        }

        let site = this.siteOptions[siteIndex];
        let objUsers = [];

        res.results.forEach(element => {
          let shiftTpl = _.get(res.references, element);
          shiftTpl.ShiftDetailsObject = _.get(res.references, shiftTpl.ShiftDetails);
          shiftTpl.ShiftTemplateObject = _.get(res.references, shiftTpl.ShiftTemplate);
          shiftTpl.Position = _.find(this.positionList, s => s.ObjectID === shiftTpl.ShiftDetailsObject.Position) || null;
          shiftTpl.Employee = shiftTpl.ShiftDetailsObject.Employee;
          shiftTpl.Selected = false;
          shiftTpl.SiteDetail = _.find(this.siteOptions, obj => obj.ObjectID === site.ObjectID);
          shiftTpl.DifferentSite = false;
          if (shiftTpl.ShiftTemplateObject.Site !== site.ObjectID) {
            shiftTpl.DifferentSite = true;
          }

          let timeWork = parseFloat(moment(shiftTpl.ShiftDetailsObject.EndTime).diff(shiftTpl.ShiftDetailsObject.StartTime, 'hours', true).toFixed(1));
          let timeBreak = parseFloat(moment(shiftTpl.ShiftDetailsObject.BreakEndTime).diff(shiftTpl.ShiftDetailsObject.BreakStartTime, 'hours', true).toFixed(1));
          let workHours = 0;

          if (!Number.isNaN(timeWork)) {
            if (!Number.isNaN(timeBreak)) {
              workHours = timeWork - timeBreak;
            } else {
              workHours = timeWork;
            }
          }

          shiftTpl.WorkHours = workHours.toFixed(1);

          // INIT EMPLOYEE

          let employeeFilter = null;
          let employeeRating = null;
          let employeePosition = null;
          // console.log('a', element);
          if (shiftTpl.Employee) {
            employeeFilter = this.employees.filter(employee => employee.ObjectID === shiftTpl.Employee);
            employeeRating = _.find(this.ratingList, s => s.ObjectID === employeeFilter[0].Rating) || null;
            employeePosition = _.find(this.positionList, s => s.ObjectID === employeeFilter[0].Position) || null;
          }

          let ratingDes = null;
          let positionDes = null;

          if (employeeRating) {
            ratingDes = employeeRating.Description;
          }

          if (employeePosition) {
            positionDes = employeePosition.Description;
          }

          let user = {
            ObjectID: shiftTpl.Employee ? shiftTpl.Employee : (shiftTpl.UnassignedRowNumber ? shiftTpl.UnassignedRowNumber : 1),
            UserName: employeeFilter !== null ? employeeFilter[0].UserName : null,
            Rating: ratingDes,
            Position: positionDes
          }

          objUsers.push(user);
          // END
          shiftTemplates.push(shiftTpl);
        });

        objUsers = _.uniqBy(objUsers, 'ObjectID');
        objUsers = _.sortBy(objUsers, ['ObjectID']);

        objUsers = this.rosterService.sortUserData(objUsers);
        let maxUnassignSlot = objUsers.length;

        let startDateNew = moment(startDateCopy).subtract(moment(this.filterDataModel.dateRange[0]).isoWeekday() - 1, 'days').format('YYYY-MM-DD');
        if (moment(this.filterDataModel.dateRange[1]).isoWeekday() !== 7) {
          endDateCopy = moment(endDateCopy).add(7 - moment(this.filterDataModel.dateRange[1]).isoWeekday(), 'days').format('YYYY-MM-DD');
        }

        let dayNumb = Math.abs(moment(endDateCopy).diff(startDateNew, 'days'));

        if (this.filterDataModel.selectType === ROSTERING_SELECT_TYPE.DAY) {
          dayNumb = 0;
        }

        let shiftDates = [];
        let listDayStr = [];
        let unassignData = [];

        for (var i = 0; i <= dayNumb; i++) {
          let dayStr = moment(startDateNew).add(i, 'days').format('YYYY-MM-DD');

          if (this.filterDataModel.selectType === ROSTERING_SELECT_TYPE.DAY) {
            dayStr = moment(startDateCopy).add(i, 'days').format('YYYY-MM-DD');
          }

          let dayOfWeekStr = moment(dayStr).format('ddd').toLocaleUpperCase();

          let dayFormatData = {
            dayFormatStr: moment(dayStr).format('YYYY/MM/DD'),
            dayFormat2Str: moment(dayStr).format('YYYY-MM-DD'),
            dayOfWeekStr: moment(dayStr).format('dddd'),
          };

          if (siteChooses.length === 1) {
            try {
              this.dragulaService.setOptions(dayFormatData.dayFormat2Str, null);
            } catch (e) {
              console.log(e)
            }
          }

          listDayStr.push(dayFormatData);

          // format week
          if (this.filterDataModel.selectType !== ROSTERING_SELECT_TYPE.DAY) {
            if (i !== 0 && (i + 1) % 7 === 0) {
              let weekData = [];
              let dragData = [];
              let listData = [];
              let listSlot = [];

              for (let slot = 0; slot <= maxUnassignSlot; slot++) {
                let slotData = {
                  slotIndex: slot,
                  slotName: slot !== maxUnassignSlot ? objUsers[slot].ObjectID : this.rosterService.getMaxUnassignedRow(objUsers),
                  slotEmployeeName: slot !== maxUnassignSlot ? objUsers[slot].UserName : null,
                  slotWeek: shiftDates.length,
                  slotRating: slot !== maxUnassignSlot ? objUsers[slot].Rating : null
                }

                listSlot.push(slotData);
              }

              listDayStr.forEach(element => {
                listSlot.forEach(slotItem => {
                  let dayData = shiftTemplates.filter(obj => {
                    if (typeof slotItem.slotName !== 'number') {
                      return moment(obj.Date).format('YYYY-MM-DD') === element.dayFormat2Str && slotItem.slotName === obj.Employee;
                    } else if (typeof slotItem.slotName === 'number') {
                      return moment(obj.Date).format('YYYY-MM-DD') === element.dayFormat2Str && slotItem.slotName === obj.UnassignedRowNumber && !obj.Employee;
                    }
                  });

                  if (slotItem.slotIndex === maxUnassignSlot) {
                    dayData = [];
                  }

                  let dataTmp = {
                    indexParent: slotItem.slotIndex,
                    indexWeek: slotItem.slotWeek,
                    type: element.dayFormat2Str,
                    value: slotItem.slotName,
                    items: _.uniq(dayData)
                  }

                  if (typeof slotItem.slotName !== 'number') {
                    weekData.push(dataTmp);
                  } else {
                    dragData.push(dataTmp);
                  }
                });

                element.listData = weekData;
                element.listDragDrop = dragData;

                weekData = [];
                dragData = [];
              });

              let weekRosterText = '';
              let lengthWeek = shiftDates.length + 1;

              weekRosterText = this.rosterService.ordinalSuffixOf(lengthWeek);

              listSlot.forEach(slotItem => {
                slotItem.totalHours = this.rosterService.calculateTotalTimeShiftTemplate(slotItem.slotName, listDayStr);
                slotItem.selected = false;
              });

              let shiftData = {
                weekRosterText: weekRosterText,
                listDate: listDayStr,
                listSlot: listSlot
              }

              shiftDates.push(shiftData);
              listDayStr = [];
            }
            this.filterDataModel.typeShow = ROSTERING_SELECT_TYPE.WEEK;
          } else {
            let weekData = [];
            let dragData = [];
            let listData = [];
            let listSlot = [];

            for (let slot = 0; slot <= maxUnassignSlot; slot++) {
              console.log(slot);
              let slotData = {
                slotIndex: slot,
                slotName: slot !== maxUnassignSlot ? objUsers[slot].ObjectID : this.rosterService.getMaxUnassignedRow(objUsers),
                slotEmployeeName: slot !== maxUnassignSlot ? objUsers[slot].UserName : null,
                slotWeek: shiftDates.length,
                slotRating: slot !== maxUnassignSlot ? objUsers[slot].Rating : null
              }

              listSlot.push(slotData);
            }

            console.log(listSlot);
            listDayStr.forEach(element => {
              listSlot.forEach(slotItem => {
                let dayData = shiftTemplates.filter(obj => {
                  if (typeof slotItem.slotName !== 'number') {
                    return moment(obj.Date).format('YYYY-MM-DD') === element.dayFormat2Str && slotItem.slotName === obj.Employee;
                  } else if (typeof slotItem.slotName === 'number') {
                    return moment(obj.Date).format('YYYY-MM-DD') === element.dayFormat2Str && slotItem.slotName === obj.UnassignedRowNumber && !obj.Employee;
                  }
                });

                if (slotItem.slotIndex === maxUnassignSlot) {
                  dayData = [];
                }

                let dataTmp = {
                  indexParent: slotItem.slotIndex,
                  indexWeek: slotItem.slotWeek,
                  type: element.dayFormat2Str,
                  value: slotItem.slotName,
                  items: _.uniq(dayData)
                }

                if (typeof slotItem.slotName !== 'number') {
                  weekData.push(dataTmp);
                } else {
                  dragData.push(dataTmp);
                }
              });

              element.listData = weekData;
              element.listDragDrop = dragData;

              weekData = [];
              dragData = [];
            });

            let weekRosterText = '';
            let lengthWeek = shiftDates.length + 1;

            weekRosterText = this.rosterService.ordinalSuffixOf(lengthWeek);

            listSlot.forEach(slotItem => {
              slotItem.totalHours = this.rosterService.calculateTotalTimeShiftTemplate(slotItem.slotName, listDayStr);

              slotItem.totalHours = slotItem.totalHours.toFixed(1);
              slotItem.selected = false;
              console.log(slotItem.totalHours);
            });


            let shiftData = {
              weekRosterText: weekRosterText,
              listDate: listDayStr,
              listSlot: listSlot
            }

            shiftDates.push(shiftData);
            listDayStr = [];
            this.filterDataModel.typeShow = ROSTERING_SELECT_TYPE.DAY;

          }
        }

        let templateDt = {
          SiteId: site.ObjectID,
          SiteName: site.SiteName,
          TemplateData: shiftDates
        }

        this.templateDataTable.push(templateDt);
      });

      if (siteChooses.length > 1) {
        let templateDt = _.cloneDeep(this.templateDataTable[0]);
        siteChooses.forEach((siteIndex, index) => {
          if (index === 0) {
            return;
          }
          let site = this.siteOptions[siteIndex];
          templateDt.SiteId = site.ObjectID;
          templateDt.SiteName = site.SiteName;

          templateDt.TemplateData.forEach(oneWeekData => {
            oneWeekData.listDate.forEach(oneDayData => {
              // List Data repeat
              oneDayData.listData.forEach(element => {
                element.items.forEach(item => {
                  item.SiteDetail = site;
                  item.DifferentSite = false;
                  if (item.ShiftTemplateObject.Site !== site.ObjectID) {
                    item.DifferentSite = true;
                  }
                });
              });

              // List Drag Drop repeat
              oneDayData.listDragDrop.forEach(element => {
                element.items.forEach(item => {
                  item.SiteDetail = site;
                  item.DifferentSite = false;
                  if (item.ShiftTemplateObject.Site !== site.ObjectID) {
                    item.DifferentSite = true;
                  }
                });
              });

            });
          });

          this.templateDataTable.push(_.cloneDeep(templateDt));
        });

      }
      //console.log('objUsers', objUsers);
      console.log('this.templateDataTable', this.templateDataTable);
      this.filterDataModel.isFilter = true;
      this.filterDataModel.haveData = true;
      window.scrollTo(0, 0);
      setTimeout(() => {
        this.reRenderTable();
        $('body').removeClass('modal-open');
      }, 0);
    });
  }

  loadOption() {
    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getAllSite().toPromise(),
        this.userInfoService.getEnvironmentInformation(),
        this.configurationService.getAllState().toPromise(),
        this.configurationService.getAllDivisionByState().toPromise(),
        this.configurationService.getAllPosition().toPromise(),
        this.configurationService.getAllIndustry().toPromise(),
        this.configurationService.getAllRating().toPromise(),
        this.configurationService.getAllProsekEmployee().toPromise(),
        // this.rosterService.getShiftStatuses(),
        this.rosterService.getDayOfWeekTypes(),
        this.rosterService.getShiftTypes(),
      ]).then(
        ([sites, user, states, divisions, positions, industries, rating, employees, dayOfWeeks, shiftTypes]) => {
          if (user.UserID === 'noprivauthtoken') {
            console.error('User not found');
            alert('User not found');
            this.helperService.hideLoading();
            return;
          }

          let siteArr = [];
          sites.results.forEach(element => {
            let item = _.get(sites.references, element);
            item.Information = _.get(sites.references, item.Information);
            siteArr.push(item);
          });

          siteArr.forEach((element, index) => {
            element.id = index + 1;
            element.name = element.SiteName;
          });

          this.siteOptionsData = siteArr;

          let positionArr = [];
          positions.results.forEach(element => {
            positionArr.push(_.get(positions.references, element));
          });

          this.positionList = positionArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_POSITIONS, positionArr);

          let industryArr = [];
          industries.results.forEach(element => {
            industryArr.push(_.get(industries.references, element));
          });

          this.helperService.dispatchToRedux(ROSTERING_SAVE_INDUSTRIES, industryArr);

          let ratingArr = [];
          rating.results.forEach(element => {
            ratingArr.push(_.get(rating.references, element));
          });

          this.ratingList = ratingArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_RATING, ratingArr);

          dayOfWeeks.results.forEach(element => {
            element.isCheck = false;
          });

          this.helperService.dispatchToRedux(ROSTERING_SAVE_DAY_OF_WEEK, dayOfWeeks.results);
          this.helperService.dispatchToRedux(ROSTERING_SAVE_SHIFT_TYPES, shiftTypes.results);
          this.shiftTypes = shiftTypes.results;

          let employeeArr = [];
          employees.results.forEach(element => {
            let employee = _.get(employees.references, element);
            employee.UserDetails = _.get(employees.references, employee.User);
            employee.RatingDetails = _.get(employees.references, employee.Rating);
            if (employee.UserDetails.FirstName) {
              if (employee.UserDetails.LastName) {
                employee.UserName = employee.UserDetails.FirstName + ' ' + employee.UserDetails.LastName;
              } else {
                employee.UserName = employee.UserDetails.FirstName;
              }
            }
            employeeArr.push(employee);
          });

          this.employees = employeeArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_EMPLOYEES, employeeArr);

          this.rdFilterModel.subscribe(data => {
            if (!data || !data.haveData) {
              console.log('call API - template');
              // Call API Get UserInformation
              this.userInfoService.getProsekUserInformationByUser(user.UserID).then(res => {
                if (!res.results.length) {
                  console.error('User not found');
                  alert('User not found');
                  this.helperService.hideLoading();
                }

                let userInformation = _.find(_.toArray(res.references), item => item.User === user.UserID);

                console.log('call API - template', userInformation);

                if (userInformation) {
                  let divisionArr = [];
                  divisions.results.forEach(element => {
                    let dIndex = userInformation.Divisions.indexOf(element);
                    if (dIndex !== -1) {
                      divisionArr.push(_.get(divisions.references, element));
                    }
                  });

                  divisionArr.forEach((element, index) => {
                    element.id = index + 1;
                    element.name = element.Description;
                  });

                  divisionArr.unshift({ id: 0, name: 'All Divisions', ObjectID: null });

                  this.divisionOptions = _.cloneDeep(divisionArr);
                  this.divisionOptionsOrigin = _.cloneDeep(divisionArr);

                  let stateArr = [];
                  states.results.forEach(element => {
                    let sIndex = _.findIndex(divisionArr, { 'State': element });
                    if (sIndex !== -1) {
                      stateArr.push(_.get(states.references, element));
                    }
                  });
                  stateArr.forEach((element, index) => {
                    element.id = index + 1;
                    element.name = element.Name;
                  });

                  stateArr.unshift({ id: 0, name: 'All States', ObjectID: null });

                  this.stateOptions = stateArr;
                  this.helperService.hideLoading();
                } else {
                  this.helperService.hideLoading();
                }
              });
            } else {
              console.log('get Data - template');
              this.getFilterModel();
              // this.helperService.hideLoading();
            }
          });

          resolve();
        }, () => {
          this.helperService.hideLoading();
          reject();
        });
    });
  }

  reRenderTable() {
    this.templateDataTable.forEach(element => {
      element.TemplateData.forEach(elementTemplateWeek => {
        elementTemplateWeek.listSlot.forEach(elementSlot => {
          var tmpHeight = 0;
          $(`div[data-sectionday="${element.SiteId}week${elementSlot.slotWeek}-${elementSlot.slotIndex}"]`).each(function () {
            var tblHeight = $(this).outerHeight();
            if (tblHeight > tmpHeight) {
              tmpHeight = tblHeight;
            }
          });

          $(`div[data-sectionday="${element.SiteId}week${elementSlot.slotWeek}-${elementSlot.slotIndex}"]`).css("height", tmpHeight);
        });
      });
    });

    this.helperService.hideLoading();
  }

  shiftTypeChange(value) {
    console.log(value);
    this.shiftModel.shiftType = value;
  }

  shiftChangeEvent(data) {
    this.filterShiftTemplate2();
    console.log(data);
  }
}
