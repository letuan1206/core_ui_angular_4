import { ROSTER_TEMPLATE_TYPE } from './../common/constants';
import { UserInformationService } from './../user-information/user-information.service';
import { AssignEmployeeComponent } from './modals/assign-employee/assign-employee.component';
import { ChangeShiftTimeComponent } from './modals/change-shift-time/change-shift-time.component';
import { ModalDirective } from 'ng2-bootstrap';
import { element } from 'protractor';
import {
  ROSTERING_SAVE_SITES,
  ROSTERING_SAVE_POSITIONS,
  ROSTERING_SAVE_INDUSTRIES,
  ROSTERING_SAVE_RATING,
  ROSTERING_SAVE_EMPLOYEES,
  ROSTERING_SAVE_SHIFT_STATUS,
  ROSTERING_SAVE_DAY_OF_WEEK,
  ROSTERING_SAVE_SHIFT_TYPES,
  ROSTERING_SAVE_FILTER_CALENDER
} from './actions';
import { AddShiftComponent } from './modals/add-shift/add-shift.component';
import { ApiService } from './../../services/api.service';
import { RosteringService } from './rostering.service';
import { ConfigurationService } from './../configuration/configuration.service';
import { HelperService } from './../../services/helper.service';
import { ConfigService } from './../../services/config.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, AfterViewInit, ViewChild, NgZone } from '@angular/core';
import * as moment from 'moment';
import * as _ from 'lodash';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from 'angular-2-dropdown-multiselect';
import { ROSTERING_SELECT_TYPE } from '../common/constants';
import { NgRedux, select } from 'ng2-redux';
import { IShContextMenuItem, BeforeMenuEvent } from 'ng2-right-click-menu/src/sh-context-menu.models';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-rostering',
  templateUrl: './rostering.component.html',
  styleUrls: ['./rostering.component.scss']
})
export class RosteringComponent implements OnInit, AfterViewInit {
  @ViewChild('modalQuickAssign') modalQuickAssign: AssignEmployeeComponent;
  @ViewChild('modalAddShift') modalAddShift: AddShiftComponent;
  @ViewChild('modalChangeShiftTime') modalChangeShiftTime: ChangeShiftTimeComponent;
  @ViewChild('modalSelectChangeTime') public modalSelectChangeTime: ModalDirective;
  @ViewChild('modalSelectQuickAssign') public modalSelectQuickAssign: ModalDirective;

  @select(s => s.rostering.filterModel) rdFilterModel;

  rosterDataDateTable = [];
  rosterDataWeekTable = [];
  rosterDataDayTable = [];
  employees: any;
  startDate = moment().format('YYYY-MM-DD');
  endDate = moment().endOf('isoWeek').format('YYYY-MM-DD');
  numberWeek = 'Week';
  filterDataModel = {
    dateRange: [
      moment().startOf('isoWeek').format('YYYY-MM-DD'),
      moment().endOf('isoWeek').format('YYYY-MM-DD')
    ],
    selectType: ROSTERING_SELECT_TYPE.WEEK,
    typeShow: ROSTERING_SELECT_TYPE.WEEK,
    isAllSite: false,
    isFilter: false,
    stateChooseIndex: null,
    stateOptions: null,
    divisionChooseIndex: null,
    divisionOptions: null,
    divisionOptionsOrigin: null,
    siteChooseIndex: null,
    siteOptions: null,
    haveData: false,
  }

  shiftModel = {
    shiftType: ROSTER_TEMPLATE_TYPE.PERMANENT_SHIFT,
    effectiveFrom: null,
    effectiveUntil: null
  };

  shiftTypes: any;

  rosterEditList = [];
  rosterEmployeList = [];

  siteChoose: number[];
  siteOptions: any;
  siteOptionsData: any;

  stateChoose: number[];
  stateOptions: any;

  divisionChoose: number[];
  divisionOptions: any;
  divisionOptionsOrigin: any;

  ratingList: any;
  positionList: any;

  // Settings configuration
  mySettings: IMultiSelectSettings = {
    enableSearch: true,
    dynamicTitleMaxItems: 1,
    // showCheckAll: true,
    // showUncheckAll: true,
    closeOnSelect: true,
    selectionLimit: 1,
    autoUnselect: true
  };

  // Text configuration
  cfTextSite: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find site',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select Site',
    allSelected: 'All selected',
  };

  cfTextState: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find state',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select State',
    allSelected: 'All selected',
  };

  cfTextDivision: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find division',
    searchEmptyResult: 'Nothing found...',
    searchNoRenderText: 'Type in search box to see results...',
    defaultTitle: 'Select Division',
    allSelected: 'All selected',
  };

  rightItems: IShContextMenuItem[];
  rightShiftItems: IShContextMenuItem[];
  eventClickContext: any;
  onLoadCalender = false;
  scrollPosition = 0;

  constructor(
    private configurationService: ConfigurationService,
    private rosterService: RosteringService,
    private apiService: ApiService,
    private userInfoService: UserInformationService,
    private helperService: HelperService,
    private configService: ConfigService,
    private ngRedux: NgRedux<any>,
    private zone: NgZone,
    private router: Router,
    private _activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    setTimeout(() => {
      this.loadOption()
    });

    this.rightItems = [
      {
        label: '<span class="menu-icon">Edit</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Change Time</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Quick Assign</span>',
        onClick: this.openModalSelectQuickAssign.bind(this)
      },
      {
        label: '<span class="menu-icon">Unconfirm Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Apply Leave</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Unassign Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Comment on Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Award Override</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Copy Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Delete Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      }
    ];

    this.rightShiftItems = this.changeRightClickMenu()

    $('body').removeClass('sidebar-minimized brand-minimized');
    $(document).on('scroll', () => {
      if (!this.onLoadCalender) {
        this.scrollPosition = $(document).scrollTop();
        console.log($(document).scrollTop());
      }
      $("sh-context-overlay").remove();
      $("sh-context-menu").remove();
    });
  }

  onBeforeRightItem = (event: BeforeMenuEvent) => {
    event.open(this.rightItems);
    setTimeout(() => {
      var outerHeight = $(document).outerHeight();
      var diffHeight = outerHeight - event.event.pageY;

      if (diffHeight < 340) {
        $("div.sh-context--container").css('top', event.event.y - (340 - diffHeight));
      }
    }, 0);
  };

  onBeforeRightShiftItem = (event: BeforeMenuEvent) => {
    event.open(this.rightShiftItems);
    setTimeout(() => {
      var outerHeight = $(document).outerHeight();
      var diffHeight = outerHeight - event.event.pageY;

      if (diffHeight < 340) {
        $("div.sh-context--container").css('top', event.event.y - (340 - diffHeight));
      }
    }, 0);
  };

  selectEditDayShift(data) {
    // console.log(data);
  }

  rightClickNoEvent($event) {
    console.log($event);
  }

  openModalSelectQuickAssign($event) {
    this.shiftModel = this.rosterService.resetAssignEmployeeModel();
    if (this.rosterEmployeList.length > 1) {
      return;
    }

    let slotContext = $event.dataContext;
    console.log($event);

    if (typeof slotContext.userID !== 'number') {
      return;
    }

    let dataSend = [];

    slotContext.userData.forEach(item => {
      if (item.length) {
        dataSend = _.concat(dataSend, item);
      }
    });
    //  else {
    //   if (this.rosterEditList.length) {
    //     this.rosterEditList.forEach(item => {
    //       if (!item.Employee) {
    //         dataSend.push(item);
    //       }
    //     });
    //   } else {
    //     if (slotContext.Employee) {
    //       dataSend.push(slotContext);
    //     }
    //   }
    // }

    console.log('dataSend', dataSend);
    if (!dataSend.length) {
      return;
    }

    // let dateCurrent = dataSend[0];
    let dateCurrent: any = _.minBy(dataSend, 'Date');

    this.shiftModel.effectiveFrom = moment(dateCurrent.Date).format('YYYY-MM-DD');
    this.eventClickContext = dataSend;

    // this.modalSelectQuickAssign.show();
    this.openModalQuickAssign();
  }

  openModalSelectMultiQuickAssign($event) {
    this.shiftModel = this.rosterService.resetAssignEmployeeModel();
    let slotContext = $event.dataContext;
    console.log($event);

    let dataSend = [];

    if (this.rosterEditList.length) {
      this.rosterEditList.forEach(item => {
        if (!item.Employee) {
          dataSend.push(item);
        }
      });
    } else {
      if (!slotContext.Employee) {
        dataSend.push(slotContext);
      }
    }

    console.log('dataSend', dataSend);
    if (!dataSend.length) {
      return;
    }

    // let dateCurrent = dataSend[0];
    let dateCurrent: any = _.minBy(dataSend, 'Date');

    this.shiftModel.effectiveFrom = moment(dateCurrent.Date).format('YYYY-MM-DD');
    this.eventClickContext = dataSend;

    // this.modalSelectQuickAssign.show();
    this.openModalQuickAssign();
  }

  openModalQuickAssign() {
    let params = {
      Site: this.siteOptions[this.siteChoose[0]],
      ShiftAction: ROSTER_TEMPLATE_TYPE.AD_HOC_SHIFT,
      EffectiveFrom: this.shiftModel.effectiveFrom,
      EffectiveUntil: this.shiftModel.effectiveUntil,
      ShiftData: [this.eventClickContext],
      IsRostering: true
    };
    // setTimeout(() => this.modalSelectQuickAssign.hide());
    this.modalQuickAssign.show(params, true);
  }

  selectShift(rosterShift) {
    if (this.filterDataModel.isAllSite) {
      return;
    }

    rosterShift.Selected = !rosterShift.Selected;
    if (rosterShift.Selected) {
      this.rosterEditList.push(_.clone(rosterShift));
    } else {
      _.remove(this.rosterEditList, obj => obj.ObjectID === rosterShift.ObjectID)
    }
    //this.rosterEditList = _.uniqBy(this.rosterEditList, 'ShiftTemplate');
    // this.changeRightClickMenu();
    console.log(this.rosterEditList);
  }

  selectEmployee(user) {
    if (this.filterDataModel.isAllSite) {
      return;
    }

    user.selected = !user.selected;

    if (user.selected) {
      this.rosterEmployeList.push(_.clone(user));
    } else {
      _.remove(this.rosterEmployeList, obj => obj.userID === user.userID)
    }

    console.log(this.rosterEmployeList)
  }

  changeRightClickMenu() {
    // if (this.rosterEditList.length > 1) {
    //   this.rightShiftItems = [
    //     {
    //       label: '<span class="menu-icon">Change Time</span>',
    //       onClick: this.openModalChangeShiftTime.bind(this)
    //     }
    //   ];
    // } else {
    //   this.rightShiftItems = [
    //     {
    //       label: '<span class="menu-icon">Edit</span>',
    //       onClick: this.editSingleShift.bind(this)
    //     },
    //     {
    //       label: '<span class="menu-icon">Change Time</span>',
    //       onClick: this.openModalChangeShiftTime.bind(this)
    //     }
    //   ];
    // }

    return [
      {
        label: '<span class="menu-icon">Edit</span>',
        onClick: this.editSingleShift.bind(this)
      },
      {
        label: '<span class="menu-icon">Change Time</span>',
        onClick: this.openModalChangeShiftTime.bind(this)
      },
      {
        label: '<span class="menu-icon">Quick Assign</span>',
        onClick: this.openModalSelectMultiQuickAssign.bind(this)
      },
      {
        label: '<span class="menu-icon">Unconfirm Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Apply Leave</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Unassign Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Comment on Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Award Override</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Copy Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      },
      {
        label: '<span class="menu-icon">Delete Shift</span>',
        onClick: this.rightClickNoEvent.bind(this)
      }
    ];
  }

  editSingleShift($event: any) {
    console.log('clicked ', $event);
    if (this.rosterEditList.length > 1) {
      return;
    }

    this.openModalAddShift($event.dataContext, null);
  };

  selectShiftChangeTime($event: any) {
    this.modalSelectChangeTime.show();
  }

  openModalChangeShiftTime($event: any) {
    console.log($event)
    if (!this.rosterEditList.length) {
      this.selectShift($event.dataContext);
    }
    this.modalChangeShiftTime.show(this.rosterEditList, true, 'roster');
    // this.modalSelectChangeTime.hide();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  getColorStatus(shift) {
    return this.rosterService.getColorStatus(shift);
  }

  onChangeState(stateChoose) {
    this.divisionChoose = [];
    this.divisionOptions = [];

    stateChoose.forEach(sIndex => {
      if (sIndex === 0) {
        this.divisionOptions = _.cloneDeep(this.divisionOptionsOrigin);
      } else {
        this.divisionOptions = this.divisionOptions.concat(this.divisionOptionsOrigin.filter(division => division.State === this.stateOptions[sIndex].ObjectID));
      }
    });
  }

  onChangeSite(siteChoose) {
    // siteChoose.forEach(sIndex => {
    //   if (sIndex === 0) {
    //     this.siteOptions.forEach(element => {
    //       if (element.id !== 0) {
    //         this.siteChoose.push(element.id);
    //       }
    //     });
    //   }
    // });

    console.log(this.siteChoose);

  }

  filterSites(event) {
    if (event.length) {

      let stateID = null;
      let divisionID = null;
      if (this.stateChoose && this.stateChoose.length) {
        stateID = this.stateOptions[this.stateChoose[0]].ObjectID;
      }

      divisionID = this.divisionOptionsOrigin[event[0]].ObjectID;

      let params = {
        State: stateID,
        Division: divisionID
      }
      this.siteChoose = [];
      this.siteOptions = [];

      if (divisionID) {
        this.siteOptions = this.siteOptionsData.filter(obj => {
          if (stateID) {
            return obj.Information.State === stateID && obj.Information.Division === divisionID
          } else {
            return obj.Information.Division === divisionID
          }
        });
      } else {
        this.siteOptions = _.cloneDeep(this.siteOptionsData);
      }

      if (this.siteOptions.length > 1) {
        this.siteOptions.unshift({ id: 0, name: 'All Sites', ObjectID: null });
      }

      this.helperService.dispatchToRedux(ROSTERING_SAVE_SITES, this.siteOptions);
    }

    console.log('this.siteChoose', this.siteChoose)
  }

  selectDateRange(type) {
    this.numberWeek = 'Week';
    if (type === ROSTERING_SELECT_TYPE.DAY) {
      this.filterDataModel.dateRange = [
        moment().format('YYYY-MM-DD'),
        moment().add(0, 'days').format('YYYY-MM-DD')
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.DAY;
    } else if (type === ROSTERING_SELECT_TYPE.WEEK) {
      this.filterDataModel.dateRange = [
        moment().startOf('isoWeek').format('YYYY-MM-DD'),
        moment().endOf('isoWeek').format('YYYY-MM-DD')
        // moment().add(7, 'days').format('YYYY-MM-DD')
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.WEEK;
    } else {
      let startDate = moment().startOf('isoWeek').format('YYYY-MM-DD');
      let endDate = moment(startDate).add(4, 'weeks').format('YYYY-MM-DD');
      endDate = moment(endDate).subtract(1, 'days').format('YYYY-MM-DD');

      this.filterDataModel.dateRange = [
        startDate,
        endDate
      ];

      this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.MONTH;
    }

    if (this.filterDataModel.haveData) {
      this.filterLegend();
    }
  }

  openModalAddShift(shift: any, action: any) {
    this.modalAddShift.show(shift, action, this.filterDataModel);
  }

  closeDateRange() {
    this.numberWeek = 'Week';
    if (this.filterDataModel.dateRange[1]) {
      console.log(moment(this.filterDataModel.dateRange[0]).isoWeek());
      console.log(moment(this.filterDataModel.dateRange[1]).isoWeek());

      let dayDist = moment(this.filterDataModel.dateRange[1]).diff(moment(this.filterDataModel.dateRange[0]), 'days');

      if (dayDist < 1) {
        this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.DAY;
      } else {
        this.filterDataModel.selectType = ROSTERING_SELECT_TYPE.WEEK;
        let weekDist = moment(this.filterDataModel.dateRange[1]).isoWeek() - moment(this.filterDataModel.dateRange[0]).isoWeek();

        if (weekDist > 0) {
          this.numberWeek = (weekDist + 1) + ' Weeks';
        }
      }
    }
  }

  getFilterModel() {
    this.rdFilterModel.subscribe(data => {
      if (data && data.haveData) {
        this.filterDataModel = data;

        this.stateOptions = data.stateOptions;
        this.divisionOptions = data.divisionOptions;
        this.divisionOptionsOrigin = data.divisionOptionsOrigin;
        this.siteOptions = data.siteOptions;

        setTimeout(() => {
          this.stateChoose = data.stateChooseIndex;
          this.onChangeState(this.stateChoose);
          this.divisionChoose = data.divisionChooseIndex;
          this.siteChoose = data.siteChooseIndex;
          if (data.isFilter) {
            this.filterLegend();
          }
        }, 500);
      }
    });
  }

  filterAfterClose() {
    if (this.siteChoose && this.siteChoose.length) {
      this.filterLegend();
    }
  }

  setFilterModel() {
    this.filterDataModel.stateChooseIndex = this.stateChoose;
    this.filterDataModel.divisionChooseIndex = this.divisionChoose;
    this.filterDataModel.siteChooseIndex = this.siteChoose;
    this.filterDataModel.stateOptions = this.stateOptions;
    this.filterDataModel.divisionOptions = this.divisionOptions;
    this.filterDataModel.divisionOptionsOrigin = this.divisionOptionsOrigin;
    this.filterDataModel.siteOptions = this.siteOptions;
    this.ngRedux.dispatch({
      type: ROSTERING_SAVE_FILTER_CALENDER,
      payload: this.filterDataModel
    });
  }

  autoSelectDateRange() {
    this.filterDataModel.dateRange = this.rosterService.autoSelectDateRange(this.filterDataModel.selectType, this.filterDataModel.dateRange[0]);
  }

  filterLegend() {
    this.rosterEditList = [];
    // this.changeRightClickMenu();

    let stateID = null;
    let divisionID = null;
    let siteID = null;

    if (this.stateChoose && this.stateChoose.length) {
      stateID = this.stateOptions[this.stateChoose[0]].ObjectID;
    }

    if (this.divisionChoose && this.divisionChoose.length) {
      divisionID = this.divisionOptionsOrigin[this.divisionChoose[0]].ObjectID;
    }

    if (this.siteChoose && this.siteChoose.length) {
      siteID = this.siteOptions[this.siteChoose[0]].ObjectID;
    }

    let dataParams = {
      'FromDate': moment(this.filterDataModel.dateRange[0]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'ToDate': moment(this.filterDataModel.dateRange[1]).format('YYYY-MM-DD') + 'T00:00:00.000Z',
      'State': stateID,
      'Division': divisionID,
      'Site': siteID
    }
    this.setFilterModel();
    console.log(dataParams);
    this.helperService.showLoading();
    this.onLoadCalender = true;
    this.rosterService.getRosteredDatesWithParams(dataParams).then(rosterdDateData => {
      let rosterDatas = _.toArray(rosterdDateData.references);

      let shiftTemplates = [];

      rosterdDateData.results.forEach(element => {
        let shiftTpl = _.get(rosterdDateData.references, element);
        shiftTpl.ShiftDetailsObject = _.get(rosterdDateData.references, shiftTpl.ShiftDetails);
        shiftTpl.ShiftTemplateObject = _.get(rosterdDateData.references, shiftTpl.ShiftTemplate);
        // shiftTpl.ShiftDetailsObject.StartTimeFormat = moment(shiftTpl.ShiftDetailsObject.StartTime).utc().format('HH:mm');
        // shiftTpl.ShiftDetailsObject.EndTimeFormat = moment(shiftTpl.ShiftDetailsObject.EndTime).utc().format('HH:mm');
        shiftTpl.Employee = shiftTpl.ShiftDetailsObject.Employee;
        shiftTpl.Position = _.find(this.positionList, s => s.ObjectID === shiftTpl.ShiftDetailsObject.Position) || null;
        shiftTemplates.push(shiftTpl);
      });

      console.log(shiftTemplates);
      // Get All UserID
      let objUsers = [];
      shiftTemplates.forEach(element => {
        let employeeFilter = null;
        let employeeRating = null;
        let employeePosition = null;
        // console.log('a', element);
        if (element.Employee) {
          employeeFilter = this.employees.filter(employee => employee.ObjectID === element.Employee);
          employeeRating = _.find(this.ratingList, s => s.ObjectID === employeeFilter[0].Rating) || null;
          employeePosition = _.find(this.positionList, s => s.ObjectID === employeeFilter[0].Position) || null;
        }

        let ratingDes = null;
        let positionDes = null;

        if (employeeRating) {
          ratingDes = employeeRating.Description;
        }

        if (employeePosition) {
          positionDes = employeePosition.Description;
        }

        let user = {
          ObjectID: element.Employee ? element.Employee : (element.UnassignedRowNumber ? element.UnassignedRowNumber : 1),
          UserName: employeeFilter !== null ? employeeFilter[0].UserName : null,
          Rating: ratingDes,
          Position: positionDes
        }

        objUsers.push(user);
      });

      objUsers = _.uniqBy(objUsers, 'ObjectID');
      objUsers = _.sortBy(objUsers, ['ObjectID']);

      objUsers = this.rosterService.sortUserData(objUsers);

      console.log('objUsers', objUsers);

      // Copy startDate and endDate
      let startDateCopy = _.clone(this.filterDataModel.dateRange[0]);
      let endDateCopy = _.clone(this.filterDataModel.dateRange[1]);

      this.rosterDataWeekTable = [];
      this.rosterDataDayTable = [];

      let siteChooses = [];

      this.siteChoose.forEach(sIndex => {
        if (sIndex === 0) {
          this.siteOptions.forEach(element => {
            if (element.id !== 0) {
              siteChooses.push(element.id);
            }
          });
          this.filterDataModel.isAllSite = true;
          this.rightShiftItems = [];
        } else {
          this.filterDataModel.isAllSite = false;
          this.rightShiftItems = this.changeRightClickMenu()
          siteChooses.push(sIndex);
        }
      });

      if (this.filterDataModel.selectType !== ROSTERING_SELECT_TYPE.DAY) {
        // Format startDate and endDate
        let startDateNew = moment(startDateCopy).subtract(moment(this.filterDataModel.dateRange[0]).isoWeekday() - 1, 'days').format('YYYY-MM-DD');
        if (moment(this.filterDataModel.dateRange[1]).isoWeekday() !== 7) {
          endDateCopy = moment(endDateCopy).add(7 - moment(this.filterDataModel.dateRange[1]).isoWeekday(), 'days').format('YYYY-MM-DD');
        }

        let dayNumb = moment(endDateCopy).diff(startDateNew, 'days');
        let listDayStr = [];
        this.rosterDataDateTable = [];
        for (var i = 0; i <= dayNumb; i++) {
          let dayStr = moment(startDateNew).add(i, 'days').format('YYYY-MM-DD');
          let dayOfWeekStr = moment(dayStr).format('dddd');

          let dayFormatData = {
            dayFormatStr: moment(dayStr).format('YYYY/MM/DD'),
            dayFormat2Str: moment(dayStr).format('YYYY-MM-DD'),
            dayOfWeekStr: dayOfWeekStr
          };

          listDayStr.push(dayFormatData);
          // format week
          if (i !== 0 && (i + 1) % 7 === 0) {
            this.rosterDataDateTable.push(listDayStr);
            listDayStr = [];
          }
        }

        siteChooses.forEach(siteIndex => {
          let site = this.siteOptions[siteIndex];
          let siteRosters: any;
          let siteData = [];

          this.rosterDataDateTable.forEach(rosterDateData => {
            let dataUser = [];
            objUsers.forEach(user => {
              // console.log('user', user);
              let dataUserWeek = [];
              // For a day in list day in week
              rosterDateData.forEach(element => {
                let dataTmp = _.cloneDeep(shiftTemplates.filter(shift => {
                  if (shift.ShiftTemplateObject.UnassignedSlot === null) {
                    shift.ShiftTemplateObject.UnassignedSlot = 1;
                  }

                  if (Number.isInteger(user.ObjectID)) {
                    return moment(shift.Date).format('YYYY-MM-DD') === moment(element.dayFormat2Str).format('YYYY-MM-DD') && shift.ShiftTemplateObject.UnassignedSlot === user.ObjectID && shift.Employee === null;
                  } else {
                    return moment(shift.Date).format('YYYY-MM-DD') === moment(element.dayFormat2Str).format('YYYY-MM-DD') && shift.Employee === user.ObjectID && shift.Employee !== null;
                  }
                }));

                if (dataTmp) {
                  dataTmp.map(item => {
                    item.DifferentSite = false;
                    item.Selected = false;
                    if (item.ShiftTemplateObject.Site !== site.ObjectID) {
                      item.DifferentSite = true;
                    }
                  });
                }

                dataUserWeek.push(dataTmp);
              });

              // console.log('dataUserWeek', dataUserWeek);
              // Start calculate total hours
              let totalHours = 0;
              dataUserWeek.map(value => {
                if (value.length) {
                  value.map(result => {
                    result.SiteDetail = _.find(this.siteOptions, obj => obj.ObjectID === result.ShiftTemplateObject.Site);
                    let timeWork = parseFloat(moment(result.ShiftDetailsObject.EndTime).diff(result.ShiftDetailsObject.StartTime, 'hours', true).toFixed(1));
                    let timeBreak = parseFloat(moment(result.ShiftDetailsObject.BreakEndTime).diff(result.ShiftDetailsObject.BreakStartTime, 'hours', true).toFixed(1));
                    let workHours = 0;

                    if (!Number.isNaN(timeWork)) {
                      if (!Number.isNaN(timeBreak)) {
                        workHours = timeWork - timeBreak;
                      } else {
                        workHours = timeWork;
                      }
                    }

                    result.WorkHours = workHours.toFixed(1);
                    totalHours += parseFloat(result.WorkHours);
                  });
                }
              });
              // End calculate

              let dataTmp = {
                userID: user.ObjectID,
                userName: user.UserName,
                rating: user.Rating,
                position: user.Position,
                selected: false,
                userData: dataUserWeek,
                totalHours: totalHours.toFixed(1)
              }

              if (totalHours) {
                // if (dataTmp.userID) {
                // dataUser.unshift(dataTmp);
                // } else {
                dataUser.push(dataTmp);
                // }
              }
            });

            let weekRosterText = '';
            let lengthWeek = siteData.length + 1;

            weekRosterText = this.rosterService.ordinalSuffixOf(lengthWeek);

            let dataTmp = {
              weekRosterText: weekRosterText,
              rosterData: dataUser,
              rosterDate: rosterDateData
            };

            if (dataUser.length) {
              siteData.push(dataTmp);
            }

          });

          siteRosters = {
            siteName: site.SiteName,
            siteID: site.ObjectID,
            siteData: siteData
          }

          if (siteRosters.siteData.length) {
            this.rosterDataWeekTable.push(siteRosters);
          }
          this.filterDataModel.typeShow = ROSTERING_SELECT_TYPE.WEEK;
          window.scrollTo(0, 0);
          setTimeout(() => {
            $('body').removeClass('modal-open');
          }, 500);
          this.helperService.hideLoading();
        });
      } else {
        // Format startDate and endDate
        let dayNumb = moment(endDateCopy).diff(startDateCopy, 'days');

        let listDayStr = [];
        this.rosterDataDateTable = [];
        for (var i = 0; i <= dayNumb; i++) {
          let dayStr = moment(startDateCopy).add(i, 'days').format('YYYY-MM-DD');
          let dayOfWeekStr = moment(dayStr).format('dddd');

          let dayFormatData = {
            dayFormatStr: moment(dayStr).format('YYYY/MM/DD'),
            dayFormat2Str: moment(dayStr).format('YYYY-MM-DD'),
            dayOfWeekStr: dayOfWeekStr
          };

          this.rosterDataDateTable.push(dayFormatData);
        }

        siteChooses.forEach(siteIndex => {
          let site = this.siteOptions[siteIndex];
          let siteRosters: any;
          let siteData = [];

          console.log(shiftTemplates);
          this.rosterDataDateTable.forEach(rosterDateData => {
            let dataUser = [];
            objUsers.forEach(user => {
              let dataUserWeek = [];
              // For a day in list day in week
              let dataUserFilter = _.cloneDeep(shiftTemplates.filter(shift => {
                if (shift.ShiftTemplateObject.UnassignedSlot === null) {
                  shift.ShiftTemplateObject.UnassignedSlot = 1;
                }

                if (Number.isInteger(user.ObjectID)) {
                  return moment(shift.Date).format('YYYY-MM-DD') === moment(rosterDateData.dayFormat2Str).format('YYYY-MM-DD') && shift.ShiftTemplateObject.UnassignedSlot === user.ObjectID && shift.Employee === null;
                } else {
                  return moment(shift.Date).format('YYYY-MM-DD') === moment(rosterDateData.dayFormat2Str).format('YYYY-MM-DD') && shift.Employee === user.ObjectID && shift.Employee !== null;
                }

                // return moment(shift.Date).format('YYYY-MM-DD') === moment(rosterDateData.dayFormat2Str).format('YYYY-MM-DD') && shift.Employee === user.ObjectID;
              }));
              console.log('dataUserFilter', dataUserFilter);

              if (dataUserFilter) {
                dataUserFilter.forEach(item => {
                  item.DifferentSite = false;
                  if (item.ShiftTemplateObject.Site !== site.ObjectID) {
                    item.DifferentSite = true;
                  }
                });
              }

              dataUserWeek.push(dataUserFilter);

              // Start calculate total hours
              let totalHours = 0;
              dataUserWeek.map(value => {
                if (value) {
                  value.map(result => {
                    let timeWork = parseFloat(moment(result.ShiftDetailsObject.EndTime).diff(result.ShiftDetailsObject.StartTime, 'hours', true).toFixed(1));
                    let timeBreak = parseFloat(moment(result.ShiftDetailsObject.BreakEndTime).diff(result.ShiftDetailsObject.BreakStartTime, 'hours', true).toFixed(1));
                    let workHours = 0;

                    if (!Number.isNaN(timeWork)) {
                      if (!Number.isNaN(timeBreak)) {
                        workHours = timeWork - timeBreak;
                      } else {
                        workHours = timeWork;
                      }
                    }

                    result.WorkHours = workHours.toFixed(1);
                    totalHours += parseFloat(result.WorkHours);
                  });
                }
              });
              // End calculate

              let dataTmp = {
                userID: user.ObjectID,
                userName: user.UserName,
                rating: user.Rating,
                position: user.Position,
                userData: dataUserWeek,
                totalHours: totalHours
              }

              // if (totalHours && user.UserName) {
              dataUser.push(dataTmp);
              // }
            });

            let dataTmp = {
              rosterData: dataUser,
              rosterDate: rosterDateData
            };

            if (dataUser.length) {
              siteData.push(dataTmp);
            }

          });

          siteRosters = {
            siteName: site.SiteName,
            siteID: site.ObjectID,
            siteData: siteData
          }

          if (siteRosters.siteData.length) {
            this.rosterDataDayTable.push(siteRosters);
          }

          console.log(this.rosterDataDayTable);
          this.filterDataModel.typeShow = ROSTERING_SELECT_TYPE.DAY;
          window.scrollTo(0, 0);
          setTimeout(() => {
            $('body').removeClass('modal-open');
          }, 500);
          this.helperService.hideLoading();
        });
      }
      this.helperService.hideLoading();
      this.filterDataModel.isFilter = true;
      this.filterDataModel.haveData = true;
      console.log(this.rosterDataWeekTable)
    }).catch((e) => {
      this.helperService.hideLoading();
      console.error(e);
    })
  }

  loadOption() {
    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.configurationService.getAllSite().toPromise(),
        this.userInfoService.getEnvironmentInformation(),
        this.configurationService.getAllState().toPromise(),
        this.configurationService.getAllDivisionByState().toPromise(),
        this.configurationService.getAllPosition().toPromise(),
        this.configurationService.getAllIndustry().toPromise(),
        this.configurationService.getAllRating().toPromise(),
        this.configurationService.getAllProsekEmployee().toPromise(),
        // this.rosterService.getShiftStatuses(),
        this.rosterService.getDayOfWeekTypes(),
        this.rosterService.getShiftTypes(),
      ]).then(
        ([sites, user, states, divisions, positions, industries, rating, employees, dayOfWeeks, shiftTypes]) => {

          if (user.UserID === 'noprivauthtoken') {
            console.error('User not found');
            alert('User not found');
            this.helperService.hideLoading();
            return;
          }

          let siteArr = [];
          sites.results.forEach(element => {
            let item = _.get(sites.references, element);
            item.Information = _.get(sites.references, item.Information);
            siteArr.push(item);
          });

          siteArr.forEach((element, index) => {
            element.id = index + 1;
            element.name = element.SiteName;
          });

          this.siteOptionsData = siteArr;

          let positionArr = [];
          positions.results.forEach(element => {
            positionArr.push(_.get(positions.references, element));
          });

          this.positionList = positionArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_POSITIONS, positionArr);

          let industryArr = [];
          industries.results.forEach(element => {
            industryArr.push(_.get(industries.references, element));
          });

          this.helperService.dispatchToRedux(ROSTERING_SAVE_INDUSTRIES, industryArr);

          let ratingArr = [];
          rating.results.forEach(element => {
            ratingArr.push(_.get(rating.references, element));
          });

          this.ratingList = ratingArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_RATING, ratingArr);

          dayOfWeeks.results.forEach(element => {
            element.isCheck = false;
          });

          this.helperService.dispatchToRedux(ROSTERING_SAVE_DAY_OF_WEEK, dayOfWeeks.results);
          this.helperService.dispatchToRedux(ROSTERING_SAVE_SHIFT_TYPES, shiftTypes.results);
          this.shiftTypes = shiftTypes.results;

          let employeeArr = [];
          employees.results.forEach(element => {
            let employee = _.get(employees.references, element);
            employee.UserDetails = _.get(employees.references, employee.User);
            employee.RatingDetails = _.get(employees.references, employee.Rating);
            if (employee.UserDetails.FirstName) {
              if (employee.UserDetails.LastName) {
                employee.UserName = employee.UserDetails.FirstName + ' ' + employee.UserDetails.LastName;
              } else {
                employee.UserName = employee.UserDetails.FirstName;
              }
            }
            employeeArr.push(employee);
          });

          this.employees = employeeArr;
          this.helperService.dispatchToRedux(ROSTERING_SAVE_EMPLOYEES, employeeArr);

          this.rdFilterModel.subscribe(data => {
            if (!data || !data.haveData) {
              // Call API Get UserInformation
              console.log('call API');
              this.userInfoService.getProsekUserInformationByUser(user.UserID).then(res => {
                if (!res.results.length) {
                  console.error('User not found');
                  alert('User not found');
                  this.helperService.hideLoading();
                }

                let userInformation = _.find(_.toArray(res.references), item => item.User === user.UserID);
                if (userInformation) {
                  let divisionArr = [];
                  divisions.results.forEach(element => {
                    let dIndex = userInformation.Divisions.indexOf(element);
                    if (dIndex !== -1) {
                      divisionArr.push(_.get(divisions.references, element));
                    }
                  });

                  divisionArr.forEach((element, index) => {
                    element.id = index + 1;
                    element.name = element.Description;
                  });

                  divisionArr.unshift({ id: 0, name: 'All Divisions', ObjectID: null });

                  this.divisionOptions = _.cloneDeep(divisionArr);
                  this.divisionOptionsOrigin = _.cloneDeep(divisionArr);
                  let stateArr = [];
                  states.results.forEach(element => {
                    let sIndex = _.findIndex(divisionArr, { 'State': element });
                    if (sIndex !== -1) {
                      stateArr.push(_.get(states.references, element));
                    }
                  });
                  stateArr.forEach((element, index) => {
                    element.id = index + 1;
                    element.name = element.Name;
                  });

                  stateArr.unshift({ id: 0, name: 'All States', ObjectID: null });

                  this.stateOptions = stateArr;

                  this.helperService.hideLoading();
                } else {
                  this.helperService.hideLoading();
                }
              });
            } else {
              this.getFilterModel();
              // this.helperService.hideLoading();
            }
          });

          resolve();
        }, () => {
          this.helperService.hideLoading();
          reject();
        });
    });
  }

  shiftChangeEvent(data) {
    if (!data.isAddTemplate || data.employee) {
      this.filterLegend();
    } else {
      this.router.navigate(['/roster-template']);
    }
    console.log(data);
  }

  shiftTypeChange(value) {
    console.log(value);
    this.shiftModel.shiftType = value;
  }
}
