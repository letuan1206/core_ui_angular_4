import { TimePickerModule } from './../time-picker/time-picker.module';
import { MomentModule } from 'angular2-moment';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalModule } from 'ngx-bootstrap';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { TextMaskModule } from 'angular2-text-mask';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ShContextMenuModule } from 'ng2-right-click-menu';
import { DragulaModule, DragulaService } from 'drag-drop-angular2';
import { AppRoutingModule } from './../../app.routing';

// Components
import { ChangeShiftTimeComponent } from './modals/change-shift-time/change-shift-time.component';
import { AssignEmployeeComponent } from './modals/assign-employee/assign-employee.component';
import { AddShiftComponent } from './modals/add-shift/add-shift.component';
import { RosteringComponent } from './rostering.component';
import { RosterTemplateComponent } from './roster-template/roster-template.component';
import { RosterFilterComponent } from './roster-filter/roster-filter.component';

// Services
import { RosteringService } from './rostering.service';
import { RosteringCenterContentDirective } from './rostering.content.center.directive';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    MultiselectDropdownModule,
    DateTimePickerModule,
    BrowserAnimationsModule,
    ShContextMenuModule,
    DragulaModule,
    MomentModule,
    TimePickerModule,
    ModalModule.forRoot(), 
  ],
  declarations: [
    RosteringComponent,
    AddShiftComponent,
    AssignEmployeeComponent,
    RosterTemplateComponent,
    ChangeShiftTimeComponent,
    RosterFilterComponent,
    RosteringCenterContentDirective
    
  ],
  providers: [
    RosteringService,
    DragulaService
  ]
})
export class RosteringModule { }
