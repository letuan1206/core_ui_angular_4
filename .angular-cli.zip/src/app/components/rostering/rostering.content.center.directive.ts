import { Directive, AfterViewChecked, ElementRef, AfterViewInit } from '@angular/core';
declare var jquery: any;
declare var $: any;
@Directive({
  selector: '[appMyDrtDemo]'
})
export class RosteringCenterContentDirective implements AfterViewChecked, AfterViewInit{

  constructor(private el:ElementRef) {
  }
    ngAfterViewChecked(){

    }
    ngAfterViewInit() {
       $('.table-edi.drt tbody tr').each(function () {
          $(this).find('.info-employee-day-inner').css("height",$(this).height());  
       });
    }
}
