import { MomentModule } from 'angular2-moment';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ng2-bootstrap';
import { FileUploadModule } from 'ng2-file-upload';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';

// Components
import { AttachmentsComponent } from './attachments.component';

// Services
import { AttachmentsService } from './attachments.service';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    FileUploadModule,
    ModalModule.forRoot(),
    FormsModule,
    MomentModule,
  ],
  declarations: [
    AttachmentsComponent
  ],
  bootstrap: [
    AttachmentsComponent
  ],
  exports: [
    AttachmentsComponent
  ],
  providers: [
    AttachmentsService
  ]
})
export class AttachmentsModule { }
