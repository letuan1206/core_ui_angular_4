import { ModalDirective } from 'ng2-bootstrap';
import { ApiService } from './../../../services/api.service';
import { Attachment } from './../../../models/attachment';
import { Component, OnInit, Input, ViewChild, ElementRef, NgZone, AfterViewInit } from '@angular/core';
// Services
import { AttachmentsService } from './attachments.service';
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';
import { FileUploader } from 'ng2-file-upload';
import * as _ from 'lodash';
declare var jquery: any;
declare var $: any;

// Redux
import { } from '../../common/common-actions';

@Component({
  selector: 'app-attachments',
  templateUrl: './attachments.component.html',
  styleUrls: ['./attachments.component.scss']
})
export class AttachmentsComponent implements OnInit, AfterViewInit {
  @ViewChild('openModal') openModal: ElementRef;
  @ViewChild('closeModal') closeModal: ElementRef;
  @ViewChild('modalAddAttachment') public modalAddAttachment: ModalDirective;

  @Input() type: string;
  @Input() objectId: string;

  editAttachment = false;
  enableBtnEdit = true;

  modalTitleText = 'Add';
  fileName = '';
  attachmentCurrent: Attachment = new Attachment();

  dataClients: any = [];
  dataClientsOrigin = [];
  dataClientTmp = [];
  dataDelete = [];

  public uploader: FileUploader;
  webRoot: string;
  validators = {
    uploadFile: null,
    fileName: null
  }

  constructor(
    private zone: NgZone,
    private attachmentsService: AttachmentsService,
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService,
    private apiService: ApiService,
  ) {
    this.webRoot = configService.get('webRoot');
    this.uploader = new FileUploader({ url: configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => {
      if (this.uploader.queue.length > 1) {
        this.uploader.queue.splice(0, 1);
      }
      file.withCredentials = true;
      this.attachmentCurrent.FileName = file.file.name;
      this.validators = {
        uploadFile: null,
        fileName: null
      }
    };
  }

  public openModalAddAttachment() {
    this.openModal.nativeElement.click();
  }

  public closeModalAddAttachment() {
    this.closeModal.nativeElement.click();
  }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['contacts']: {
        let queryParams = {
          Contact: this.objectId
        }
        this.getAttachments(queryParams);
        break;
      }

      case this.configService.get('menuType')['clients']: {
        let queryParams = {
          Client: this.objectId
        }
        this.getAttachments(queryParams);
        break;
      }

      case this.configService.get('menuType')['sites']: {
        let queryParams = {
          Site: this.objectId
        }
        this.getAttachments(queryParams);
        break;
      }

      case this.configService.get('menuType')['employees']: {
        let queryParams = {
          Employee: this.objectId
        }
        this.getAttachments(queryParams);
        break;
      }
      default: {
        break;
      }
    }
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  changeStatusEdit() {
    this.enableBtnEdit = !this.enableBtnEdit;
  }

  deleteAttachment(attachment) {
    let itemRemove = _.remove(this.dataClientTmp, (s: any) => s.ObjectID === attachment.ObjectID);
    this.dataDelete = _.concat(this.dataDelete, itemRemove);
    this.dataClients = _.cloneDeep(this.dataClientTmp);
  }

  cancelDeleteAttachment() {
    this.dataClients = _.cloneDeep(this.dataClientsOrigin);
    this.dataClientTmp = _.cloneDeep(this.dataClientsOrigin);
    this.dataDelete = [];
    this.changeStatusEdit();
  }

  saveAttachment() {
    let deleteData = Object.assign({}, this.dataDelete);
    let params = {
      create: {},
      update: {},
      delete: deleteData
    }
    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      if (this.configService.successStatus === res.result) {
        this.changeStatusEdit();
      }

      this.dataClientsOrigin = _.cloneDeep(this.dataClients);
      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  getAttachments(params) {
    let attachments = [];
    this.attachmentsService.getAttachments(params).then(res => {
      res.results.forEach(element => {
        let attachment = _.get(res.references, element);
        if (attachment.Contact && attachment.Contact === this.objectId) {
          attachments.push(attachment);
        } else if (attachment.Client && attachment.Client === this.objectId) {
          attachments.push(attachment);
        } else if (attachment.Site && attachment.Site === this.objectId) {
          attachments.push(attachment);
        } else if (attachment.Employee && attachment.Employee === this.objectId) {
          attachments.push(attachment);
        }
      });

      this.dataClients = attachments;
      this.dataClientsOrigin = _.cloneDeep(attachments);
      this.dataClientTmp = _.cloneDeep(attachments);
      // this.helperService.hideLoading();
    }, error => {
      // this.helperService.hideLoading();
    });
  }

  handleRowClick(event) {
    this.attachmentCurrent = _.clone(event.data);
    this.fileName = this.attachmentCurrent.FileName;
    this.show(true);
  }

  saveFileAttachment(responsePath) {
    let attachment = new Attachment();
    attachment.FileName = responsePath.files[0].fileName;
    attachment.Attachment = {
      FileToken: responsePath.files[0].token
    }

    if (this.type === this.configService.get('menuType')['contacts']) {
      attachment.Contact = this.objectId;
    } else if (this.type === this.configService.get('menuType')['clients']) {
      attachment.Client = this.objectId;
    } else if (this.type === this.configService.get('menuType')['sites']) {
      attachment.Site = this.objectId;
    } else if (this.type === this.configService.get('menuType')['employees']) {
      attachment.Employee = this.objectId;
    }

    if (this.attachmentCurrent.FileName) {
      attachment.FileName = this.attachmentCurrent.FileName;
    }

    if (this.editAttachment) {
      attachment.ObjectID = this.attachmentCurrent.ObjectID;

      let params = {
        'create': {},
        'update': {
          'UPDATE:1': attachment
        },
        'delete': {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        this.uploader.clearQueue();

        this.modalAddAttachment.hide();

        if (this.type === this.configService.get('menuType')['contacts']) {
          let queryParams = {
            Contact: this.objectId
          }
          this.getAttachments(queryParams);

        } else if (this.type === this.configService.get('menuType')['clients']) {
          let queryParams = {
            Client: this.objectId
          }
          this.getAttachments(queryParams);
        } else if (this.type === this.configService.get('menuType')['sites']) {
          let queryParams = {
            Site: this.objectId
          }
          this.getAttachments(queryParams);
        } else if (this.type === this.configService.get('menuType')['employees']) {
          let queryParams = {
            Employee: this.objectId
          }
          this.getAttachments(queryParams);
        }
        this.helperService.hideLoading();
      }, error => {
        this.helperService.hideLoading();
      });
    } else {
      let params = {
        'create': {
          'NEW:1': attachment
        },
        'update': {},
        'delete': {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        this.uploader.clearQueue();
        this.modalAddAttachment.hide();
        this.getAttachments({});
        this.helperService.hideLoading();
      }, error => {
        this.helperService.hideLoading();
      });
    }
  }

  saveEditFileName() {
    let attachment = new Attachment();

    attachment.FileName = this.attachmentCurrent.FileName;
    attachment.ObjectID = this.attachmentCurrent.ObjectID;

    let params = {
      'create': {},
      'update': {
        'UPDATE:1': attachment
      },
      'delete': {}
    };

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      this.uploader.clearQueue();
      $('#fileControl').val('');
      this.modalAddAttachment.hide();
      this.getAttachments({});
      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  uploadAttachment() {
    this.validators = {
      fileName: null,
      uploadFile: null
    }

    if (!this.attachmentCurrent.FileName) {
      this.validators.fileName = true;
    }

    if (!this.editAttachment && !this.uploader.queue.length) {
      this.validators.uploadFile = true;
    }

    if (this.validators.fileName || this.validators.uploadFile) {
      return;
    }

    if (this.uploader.queue.length) {
      this.uploader.queue.forEach(item => {
        if (!item.isUploaded) {
          item.upload();
        }
      });

      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          const responsePath = JSON.parse(response);
          this.zone.run(() => {
            this.saveFileAttachment(responsePath);
          });
        }
      };
    } else {
      this.saveEditFileName();
    }
  }

  show(isEdit = false) {
    this.editAttachment = isEdit;
    this.validators = {
      fileName: null,
      uploadFile: null
    }

    if (!this.editAttachment) {
      this.modalTitleText = 'Add';
      this.attachmentCurrent = new Attachment();
    } else {
      this.modalTitleText = 'Edit';
    }
    this.modalAddAttachment.show();
    $('#fileControl').val('');
  }

  downloadFile(urlLink) {
    var blob = new Blob([urlLink], {});
    var url = window.URL.createObjectURL(blob);
    window.open(url);
  }

}
