import { Injectable } from '@angular/core';
import { ISubscription } from "rxjs/Subscription";

// Services
import { ApiService } from '../../../services/api.service';
import { ConfigService } from '../../../services/config.service';

@Injectable()
export class AttachmentsService {

  constructor(
    private apiService: ApiService,
    private configService: ConfigService
  ) {

  }

  getAttachments(querrParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params = {
        queryType: 'All',
        queryParams: querrParams,
        assocs: []
      };

      this.apiService.post(`/Attachments`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }
}
