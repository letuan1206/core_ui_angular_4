import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';

// Components
import { NotesComponent } from './notes.component';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule
  ],
  declarations: [
    NotesComponent
  ],
  bootstrap: [
    NotesComponent
  ],
  exports: [
    NotesComponent
  ]
})
export class NotesModule { }
