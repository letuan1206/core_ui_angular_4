import { Component, OnInit, Input } from '@angular/core';
import get = require('lodash/get');

// Services
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';

// Redux
import { NgRedux, select } from 'ng2-redux';
import { STORE_SUB_NOTES_CLIENTS } from '../../common/common-actions';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {

  @Input() type: string;
  @Input() objectId: string;

  subNotesClientsData: any;

  // Redux store
  @select(s => s.common.subNotesClients) subNotesClients;

  constructor(
    private configService: ConfigService,
    private commonService: CommonService,
    private helperService: HelperService
  ) { 
    this.subNotesClients.subscribe(data => {
      this.subNotesClientsData = data;
    })
  }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.getNotes('/Notes', 'ID:223834');
        break;
      }
      case this.configService.get('menuType')['sites']: {
        
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        
        break;
      }
      default: {
        break;
      }
    }
  }

  async getNotes(url, objectId) {
    
    try {

      let dataNotes = await this.commonService.queryById(url, objectId);

      if (dataNotes.result === this.configService.successStatus) {

        let result = get(dataNotes.references, objectId);

        switch (this.type) {
          case this.configService.get('menuType')['clients']: {
            let arr = [];
            arr.push({
              subject: result.Subject !== null ? result.Subject : '',
              description: result.Description !== null ? result.Description : '',
              employee: result.Employee !== null ? result.Employee : '',
              externalContact: (result.ExternalContact !== undefined && result.ExternalContact !== null) ? result.ExternalContact : '', 
              site: result.Site !== null ? result.Site : ''
            });
            this.helperService.dispatchToRedux(STORE_SUB_NOTES_CLIENTS, arr);
            break;
          }
          case this.configService.get('menuType')['sites']: {
            
            break;
          }
          case this.configService.get('menuType')['contacts']: {
            
            break;
          }
          default: {
            break;
          }
        }

      } else {
        throw Error('error');
      }

    } catch (e) {
      this.helperService.handleError(e);
    }

  }

}
