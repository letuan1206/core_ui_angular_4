import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-activities',
  templateUrl: './task-activities.component.html',
  styleUrls: ['./task-activities.component.scss']
})
export class TaskActivitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
