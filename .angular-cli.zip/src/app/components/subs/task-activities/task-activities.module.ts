import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { TaskActivitiesComponent } from './task-activities.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    TaskActivitiesComponent
  ],
  bootstrap: [
    TaskActivitiesComponent
  ],
  exports: [
    TaskActivitiesComponent
  ]
})
export class TaskActivitiesModule { }
