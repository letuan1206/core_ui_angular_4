import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DueActivitiesComponent } from './due-activities.component';

describe('DueActivitiesComponent', () => {
  let component: DueActivitiesComponent;
  let fixture: ComponentFixture<DueActivitiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DueActivitiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DueActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
