import { ModalDirective } from 'ng2-bootstrap';
import { ApiService } from './../../../services/api.service';
import { CommonService } from './../../../services/common.service';
import { ConfigService } from './../../../services/config.service';
import { HelperService } from './../../../services/helper.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-due-activities',
  templateUrl: './due-activities.component.html',
  styleUrls: ['./due-activities.component.scss']
})
export class DueActivitiesComponent implements OnInit {
  @ViewChild('modalActivityReminders') public modalActivityReminders: ModalDirective;
  dataClients = [];
  isSelectAll = false;
  constructor(
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService,
    private apiService: ApiService,
  ) { }

  ngOnInit() {
  }

  selectActivities(item) {
    item.Selected = !item.Selected;

    let countSelect = this.dataClients.filter(value => value.Selected === true);

    this.isSelectAll = false;

    if (countSelect.length === this.dataClients.length) {
      this.isSelectAll = true;
    }
  }

  selectAll() {
    this.isSelectAll = !this.isSelectAll;
    this.dataClients.forEach(element => {
      element.Selected = this.isSelectAll;
    });
  }

  show() {
    var interval;
    if (!interval) {
      interval = setInterval(() => {
        if (moment().minute() % 5 === 0) {
          let params = {
            queryType: 'All',
            queryParams: {
              ReminderType: 'POP_UP',
              Date: moment().format('YYYY-MM-DDTHH') + ':00:00.000Z'
            },
            assocs: []
          };

          this.apiService.getDueActivities(params).subscribe(res => {
            if (res.result === this.configService.successStatus) {
              let data = [];
              res.results.forEach(element => {
                let item = _.get(res.references, element);
                item.Selected = false;
                data.push(item);
              });
              this.dataClients = data;
              this.modalActivityReminders.show();
            }
          });
        }
      }, 60000);
    }
  }

  hide() {
    this.modalActivityReminders.onHidden
    setTimeout(() => {
      $('body').removeClass('modal-open');
    }, 100);
  }
}
