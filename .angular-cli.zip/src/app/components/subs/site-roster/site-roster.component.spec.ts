import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiteRosterComponent } from './site-roster.component';

describe('SiteRosterComponent', () => {
  let component: SiteRosterComponent;
  let fixture: ComponentFixture<SiteRosterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiteRosterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiteRosterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
