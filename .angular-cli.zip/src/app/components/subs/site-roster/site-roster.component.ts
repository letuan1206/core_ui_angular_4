import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-roster',
  templateUrl: './site-roster.component.html',
  styleUrls: ['./site-roster.component.scss']
})
export class SiteRosterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
