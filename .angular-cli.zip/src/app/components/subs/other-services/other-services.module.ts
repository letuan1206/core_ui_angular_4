import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { OtherServicesComponent } from './other-services.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    OtherServicesComponent
  ],
  bootstrap: [
    OtherServicesComponent
  ],
  exports: [
    OtherServicesComponent
  ]
})
export class OtherServicesModule { }
