import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';

// Components
import { ContactsComponent } from './contacts.component';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule
  ],
  declarations: [
    ContactsComponent
  ],
  bootstrap: [
    ContactsComponent
  ],
  exports: [
    ContactsComponent
  ]
})
export class ContactsModule { }
