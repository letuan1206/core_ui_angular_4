import { Router } from '@angular/router';
import { Contact } from './../../../models/configuration';
import { Component, OnInit, Input } from '@angular/core';
import get = require('lodash/get');

// Services
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';

// Redux
import { NgRedux, select } from 'ng2-redux';
import { STORE_SUB_CONTACTS_CLIENTS } from '../../common/common-actions';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss']
})
export class ContactsComponent implements OnInit {

  @Input() type: string;
  @Input() clientId: string;
  @Input() siteId: string;

  subContactsClientsData: any;

  // Redux store
  @select(s => s.common.subContactsClients) subContactsClients;

  constructor(
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService,
    private router: Router,
  ) {
    this.subContactsClients.subscribe(data => {
      this.subContactsClientsData = data;
    })
  }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['sites']: {
      }
      case this.configService.get('menuType')['clients']: {
        this.getContacts();
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        break;
      }
      default: {
        break;
      }
    }
  }

  addNewContact() {
    this.router.navigate(['/contact/add'], { queryParams: { clientId: this.clientId, siteId: this.siteId } });
  }

  handleRowClick(event) {
    this.router.navigate(['/contact', event.data.ObjectID], { queryParams: { clientId: this.clientId, siteId: this.siteId } });
  }

  async getContacts() {
    try {
      this.subContactsClientsData=[];
      let url = '/Contact';
      let dataContacts = await this.commonService.query(url, {
        Client: this.clientId,
        Site: this.siteId
      }, [
          'Position', 'Division', 'State'
        ]);
      if (dataContacts.result !== this.configService.successStatus) {
        throw Error('error');
      }

      if (!dataContacts.results || !dataContacts.results.length) {
        return;
      }
      switch (this.type) {
        case this.configService.get('menuType')['sites']: {
        }
        case this.configService.get('menuType')['clients']: {
          let arr = [];
          dataContacts.results.forEach(element => {
            let contactDetail: Contact;

            contactDetail = get(dataContacts.references, element);
            contactDetail.FullName = contactDetail.FirstName + ' ' + contactDetail.LastName;
            contactDetail.PositionDetails = get(dataContacts.references, contactDetail.Position);
            contactDetail.ActiveString = 'Active';
            if (!contactDetail.Active) {
              contactDetail.ActiveString = 'Deactive';
            }

            arr.push(contactDetail);
          });
          this.subContactsClientsData = arr;
          this.helperService.dispatchToRedux(STORE_SUB_CONTACTS_CLIENTS, arr);
          break;
        }

        case this.configService.get('menuType')['contacts']: {
          break;
        }
        default: {
          break;
        }
      }
    } catch (e) {
      this.helperService.handleError(e);
    }

  }

  async getPositionDescription(objectId) {
    let data = await this.helperService.getPositionDetailById(objectId);
    return data.Description !== null ? data.Description : '';
  }

}
