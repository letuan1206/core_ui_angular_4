import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { ClientLoginDetailComponent } from './client-login-detail.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ClientLoginDetailComponent
  ],
  bootstrap: [
    ClientLoginDetailComponent
  ],
  exports: [
    ClientLoginDetailComponent
  ]
})
export class ClientLoginDetailModule { }
