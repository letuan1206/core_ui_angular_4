import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-login-detail',
  templateUrl: './client-login-detail.component.html',
  styleUrls: ['./client-login-detail.component.scss']
})
export class ClientLoginDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
