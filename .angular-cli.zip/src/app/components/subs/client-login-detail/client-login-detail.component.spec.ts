import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientLoginDetailComponent } from './client-login-detail.component';

describe('ClientLoginDetailComponent', () => {
  let component: ClientLoginDetailComponent;
  let fixture: ComponentFixture<ClientLoginDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientLoginDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientLoginDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
