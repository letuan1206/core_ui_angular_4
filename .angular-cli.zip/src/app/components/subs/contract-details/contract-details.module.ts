import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DateTimePickerModule } from 'ng-pick-datetime';
// Components
import { ContractDetailsComponent } from './contract-details.component';

@NgModule({
  imports: [
    CommonModule,
    DateTimePickerModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DateTimePickerModule,
    TextMaskModule,
  ],
  declarations: [
    ContractDetailsComponent
  ],
  bootstrap: [
    ContractDetailsComponent
  ],
  exports: [
    ContractDetailsComponent
  ]
})
export class ContractDetailsModule { }
