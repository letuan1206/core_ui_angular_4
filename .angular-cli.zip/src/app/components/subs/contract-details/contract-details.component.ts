import { ClientsService } from './../../clients/clients.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from './../../../services/api.service';
import { CommonService } from './../../../services/common.service';
import { ConfigService } from './../../../services/config.service';
import { HelperService } from './../../../services/helper.service';
import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { ClientInformation } from '../../../models/user';

@Component({
  selector: 'app-contract-details',
  templateUrl: './contract-details.component.html',
  styleUrls: ['./contract-details.component.scss']
})
export class ContractDetailsComponent implements OnInit {
  @Input() type: string;
  @Input() objectId: string;
  contractDetail: ClientInformation;
  contractDetailOrigin: ClientInformation;
  formContractDetail: FormGroup;
  enableBtnEdit = true;
  contractExtendedTypes = [];
  contractPeriods = [];

  constructor(
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService,
    private apiService: ApiService,
    private fb: FormBuilder,
    private clientService: ClientsService,
  ) {
    this.contractDetail = new ClientInformation();
    this.formContractDetail = this.renderFormContractDetail(this.contractDetail);
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    new Promise((resolve, reject) => {
      Promise.all([
        this.clientService.getContractPeriods(),
        this.clientService.getContractExtendedTypes(),
      ]).then(
        ([contractPeriods, contractExtendedTypes]) => {
          this.contractPeriods = contractPeriods.results;
          this.contractExtendedTypes = contractExtendedTypes.results;

        }).catch(e => {

        })
    });

    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.getContractDetail(this.objectId);
        break;
      }
      case this.configService.get('menuType')['sites']: {
        this.getContractDetail(this.objectId);
        break;
      }
      default: {
        break;
      }
    }
  }

  changeStatusEdit() {
    this.enableBtnEdit = !this.enableBtnEdit;

    this.setDisableForm();
  }

  setDisableForm() {
    if (this.enableBtnEdit) {
      setTimeout(() => {
        this.formContractDetail.disable();
      });
    } else {
      setTimeout(() => {
        this.formContractDetail.enable();
      });
    }
  }

  saveContractDetail() {
    if (!this.formContractDetail.valid) {
      this.helperService.markFormGroupTouched(this.formContractDetail);
      return;
    }

    let contractUpdate = {
      ObjectID: this.contractDetail.ObjectID,
      ObjectClass: 'prosek.orm.Information',
      StartDate: this.formContractDetail.value.StartDate ? moment(this.formContractDetail.value.StartDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      ContractExpiry: this.formContractDetail.value.ContractExpiry ? moment(this.formContractDetail.value.ContractExpiry).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      OptionExpiry: this.formContractDetail.value.OptionExpiry ? moment(this.formContractDetail.value.OptionExpiry).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      TerminationDate: this.formContractDetail.value.TerminationDate ? moment(this.formContractDetail.value.TerminationDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null,
      TerminationReason: this.formContractDetail.value.Reason,
      Description: this.formContractDetail.value.Description,
      ContractExtended: this.formContractDetail.value.ContractExtended,
      ContractOption: this.formContractDetail.value.ContractOption,
      ContractTerm: this.formContractDetail.value.ContractTerm,
    };

    let params = {
      create: {},
      update: {
        'UPDATE:1': contractUpdate
      },
      delete: {}
    };

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      if (res.result === this.configService.successStatus) {
        this.contractDetailOrigin = _.cloneDeep(this.contractDetail);
        this.changeStatusEdit();
      }

      this.helperService.hideLoading();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  cancelContractDetail() {
    this.contractDetail = _.cloneDeep(this.contractDetailOrigin);
    this.formContractDetail = this.renderFormContractDetail(this.contractDetail);
    this.changeStatusEdit();

  }

  getContractDetail(clientId) {
    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.clientService.getDetailClient(this.objectId).then(res => {
          let clientDetail = _.get(res.references, res.results[0]);
          this.contractDetail = _.get(res.references, clientDetail.Information);
          this.contractDetailOrigin = _.cloneDeep(this.contractDetail);
          this.formContractDetail = this.renderFormContractDetail(this.contractDetail);
          this.setDisableForm();
        })
        break;
      }
      case this.configService.get('menuType')['sites']: {
        this.commonService.query('/Sites', {
          id: this.objectId
        }, [
            'Information', 'Information.Address', 'Information.Services', 'Information.State', 'Information.PostalAddress', 'Information.Industry', 'Information.Rating', 'Information.Division', 'Information.Address.GoogleAddress', 'Information.PostalAddress.GoogleAddress'
          ], 'ByID'
        ).then(res => {
          let site = _.get(res.references, res.results[0]);
          this.contractDetail = _.get(res.references, site.Information);
          this.contractDetailOrigin = _.cloneDeep(this.contractDetail);
          this.formContractDetail = this.renderFormContractDetail(this.contractDetail);
          this.setDisableForm();
        })
        break;
      }
      default: {
        break;
      }
    }
  }

  renderFormContractDetail(contractDetail: ClientInformation) {
    let form = this.fb.group({
      StartDate: [contractDetail.StartDate],
      ContractExpiry: [contractDetail.ContractExpiry],
      ContractTerm: [contractDetail.ContractTerm ? contractDetail.ContractTerm.Value : null],
      ContractOption: [contractDetail.ContractOption ? contractDetail.ContractOption.Value : null],
      ContractExtended: [contractDetail.ContractExtended ? contractDetail.ContractExtended.Value : null],
      OptionExpiry: [contractDetail.OptionExpiry],
      TerminationDate: [contractDetail.TerminationDate],
      Reason: [contractDetail.TerminationReason],
      Description: [contractDetail.Description],
    });

    form.controls['StartDate'].valueChanges.subscribe(s => {
      if (form.value.ContractTerm) {
        let item = _.find(this.contractPeriods, obj => obj.Value === form.value.ContractTerm);
        if (item) {
          form.controls['ContractExpiry'].setValue(moment(s).add(item.Period, 'months').format('YYYY-MM-DD'));
        }
      }
    });

    form.controls['ContractTerm'].valueChanges.subscribe(s => {
      if (form.value.StartDate) {
        let item = _.find(this.contractPeriods, obj => obj.Value === s);
        if (item) {
          form.controls['ContractExpiry'].setValue(moment(form.value.StartDate).add(item.Period, 'months').format('YYYY-MM-DD'));
        }
      }
    });

    form.controls['ContractOption'].valueChanges.subscribe(s => {
      if (form.value.ContractExpiry) {
        let item = _.find(this.contractPeriods, obj => obj.Value === s);
        if (item) {
          form.controls['OptionExpiry'].setValue(moment(form.value.ContractExpiry).add(item.Period, 'months').format('YYYY-MM-DD'));
        }
      }
    });

    return form;
  }
}
