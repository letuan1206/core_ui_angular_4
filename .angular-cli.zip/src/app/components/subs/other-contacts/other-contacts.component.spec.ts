import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherContactsComponent } from './other-contacts.component';

describe('OtherContactsComponent', () => {
  let component: OtherContactsComponent;
  let fixture: ComponentFixture<OtherContactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtherContactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
