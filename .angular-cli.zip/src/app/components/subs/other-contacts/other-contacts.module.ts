import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { OtherContactsComponent } from './other-contacts.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    OtherContactsComponent
  ],
  bootstrap: [
    OtherContactsComponent
  ],
  exports: [
    OtherContactsComponent
  ]
})
export class OtherContactsModule { }
