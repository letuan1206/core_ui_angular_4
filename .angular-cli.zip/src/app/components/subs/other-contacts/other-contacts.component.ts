import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-contacts',
  templateUrl: './other-contacts.component.html',
  styleUrls: ['./other-contacts.component.scss']
})
export class OtherContactsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
