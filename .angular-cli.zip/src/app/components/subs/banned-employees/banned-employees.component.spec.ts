import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BannedEmployeesComponent } from './banned-employees.component';

describe('BannedEmployeesComponent', () => {
  let component: BannedEmployeesComponent;
  let fixture: ComponentFixture<BannedEmployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BannedEmployeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BannedEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
