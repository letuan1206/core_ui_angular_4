import { ModalDirective } from 'ng2-bootstrap';
import { ConfigurationService } from './../../configuration/configuration.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { BannedEmployee } from './../../../models/bannedEmployee';
import { ContactService } from './../../contact/contact.service';
import { ApiService } from './../../../services/api.service';
import { CommonService } from './../../../services/common.service';
import { ConfigService } from './../../../services/config.service';
import { HelperService } from './../../../services/helper.service';
import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
declare var jquery: any;
declare var $: any;

import { textMask } from '../../common/constants';
import createAutoCorrectedDatePipe from 'text-mask-addons/dist/createAutoCorrectedDatePipe';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'app-banned-employees',
  templateUrl: './banned-employees.component.html',
  styleUrls: ['./banned-employees.component.scss']
})
export class BannedEmployeesComponent implements OnInit, AfterViewInit {
  @ViewChild('modalAddBannedEmployee') public modalAddBannedEmployee: ModalDirective;

  @Input() type: string;
  @Input() objectId: string;
  public maskTimeFormat = textMask.maskTimeFormat;
  public maskOnlyNumber = textMask.maskOnlyNumber;
  autoCorrectedDatePipe: any = createAutoCorrectedDatePipe('HH:MM');

  secUsers = [];
  sites = [];
  contacts = [];
  reminderType = [];
  bannedPeriod = [];
  notificationType = [];

  filteredClientManagerSingle: any[];
  filteredSiteSingle: any[];
  filteredContactSingle: any[];

  dataClients: any = [];
  formAddBannedEmployee: FormGroup;
  bannedEmployee: BannedEmployee;
  bannedLifted: string;
  isEditBanned = 'Add';

  constructor(
    private configuarationService: ConfigurationService,
    private contactService: ContactService,
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService,
    private apiService: ApiService,
    private fb: FormBuilder
  ) {
    this.bannedEmployee = new BannedEmployee();
    this.formAddBannedEmployee = this.renderFormAddBannedEmployee(this.bannedEmployee);
  }

  ngOnInit() {
    this.loadData();
    this.loadBannedEmployees();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  loadBannedEmployees() {
    switch (this.type) {
      case this.configService.get('menuType')['contacts']: {
        let queryParams = {
          Contact: this.objectId
        }
        this.getBannedEmployees(queryParams);
        break;
      }
      case this.configService.get('menuType')['clients']: {
        break;
      }
      case this.configService.get('menuType')['sites']: {
        let queryParams = {
          Site: this.objectId
        }
        this.getBannedEmployees(queryParams);
        break;
      }
      default: {
        break;
      }
    }
  }

  handleRowClick(event) {
  }

  calculateBannedLifted() {
    let bannedPeriodSelect = _.find(this.bannedPeriod, s => s.Value === this.formAddBannedEmployee.value.BannedPeriod);
    if (bannedPeriodSelect && bannedPeriodSelect.Period !== -1 && this.formAddBannedEmployee.value.BannedDate) {
      this.bannedLifted = moment(this.formAddBannedEmployee.value.BannedDate).add(bannedPeriodSelect.Period, 'months').format('DD/MM/YYYY');
    } else {
      this.bannedLifted = null;
    }
  }

  saveBannedEmployee() {
    if (!this.formAddBannedEmployee.valid) {
      this.helperService.markFormGroupTouched(this.formAddBannedEmployee);
      return;
    }

    // Contact Model
    this.bannedEmployee.ActionedBy = this.formAddBannedEmployee.value.ActionedBy ? this.formAddBannedEmployee.value.ActionedBy.ObjectID : null;
    this.bannedEmployee.ActionsTakingDetails = this.formAddBannedEmployee.value.ActionsTakingDetails;
    this.bannedEmployee.BannedBy = this.formAddBannedEmployee.value.BannedBy ? this.formAddBannedEmployee.value.BannedBy.ObjectID : null;
    this.bannedEmployee.BannedByOther = this.formAddBannedEmployee.value.BannedByOther;

    this.bannedEmployee.BannedDate = moment(this.formAddBannedEmployee.value.BannedDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
    this.bannedEmployee.BannedEmployee = this.formAddBannedEmployee.value.BannedEmployee.ObjectID;
    this.bannedEmployee.BannedFromAllClientSites = this.formAddBannedEmployee.value.BannedFromAllClientSites;
    this.bannedEmployee.BannedPeriod = this.formAddBannedEmployee.value.BannedPeriod;
    this.bannedEmployee.ClosedDate = this.formAddBannedEmployee.value.ClosedDate ? moment(this.formAddBannedEmployee.value.ClosedDate).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]') : null;
    this.bannedEmployee.ClosedTime = this.formAddBannedEmployee.value.ClosedTime ? (moment(this.bannedEmployee.ClosedDate).format('YYYY-MM-DDT') + this.formAddBannedEmployee.value.ClosedTime + ':00.000Z') : null;
    switch (this.type) {
      case this.configService.get('menuType')['contacts']: {
        this.bannedEmployee.Contact = this.objectId ? this.objectId : null;
        this.bannedEmployee.Site = this.formAddBannedEmployee.value.Site ? this.formAddBannedEmployee.value.Site.ObjectID : null;
        break;
      }
      case this.configService.get('menuType')['clients']: {
        break;
      }
      case this.configService.get('menuType')['sites']: {
        this.bannedEmployee.Site = this.objectId ? this.objectId : null;
        break;
      }
      default: {
        break;
      }
    }

    this.bannedEmployee.NotificationTime = parseInt(this.formAddBannedEmployee.value.NotificationTime);
    this.bannedEmployee.NotificationType = this.formAddBannedEmployee.value.NotificationType;
    this.bannedEmployee.ReasonForBanning = this.formAddBannedEmployee.value.ReasonForBanning;
    this.bannedEmployee.ReminderType = this.formAddBannedEmployee.value.ReminderType;

    if (this.bannedEmployee.ObjectID) {
      let params = {
        create: {},
        update: {
          'UPDATE:1': this.bannedEmployee
        },
        delete: {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        this.loadBannedEmployees();
        this.helperService.hideLoading();
        this.modalAddBannedEmployee.hide();
      }, error => {
        this.helperService.hideLoading();
      });
    } else {
      let params = {
        create: {
          'NEW:1': this.bannedEmployee
        },
        update: {},
        delete: {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        this.loadBannedEmployees();
        this.helperService.hideLoading();
        this.modalAddBannedEmployee.hide();
      }, error => {
        this.helperService.hideLoading();
      });
    }

  }

  filterClientManagerSingle(event) {
    let query = event.query;
    this.filteredClientManagerSingle = this.contactService.filterClientManager(query, this.secUsers);

  }

  filterSitesSingle(event) {
    let query = event.query;
    this.filteredSiteSingle = this.contactService.filterSitesSingle(query, this.sites);
  }

  filterContactSingle(event) {
    let query = event.query;
    this.filteredContactSingle = this.contactService.filterContactSingle(query, this.contacts);
  }

  getBannedEmployees(params) {
    let bannedEmployees = [];
    this.contactService.getBannedEmployees(params).then(res => {
      res.results.forEach(element => {
        let bannedEmployee = _.get(res.references, element);
        bannedEmployee.BannedEmployeeDetail = _.get(res.references, bannedEmployee.BannedEmployee);

        if (bannedEmployee.BannedEmployeeDetail && bannedEmployee.BannedEmployeeDetail.FirstName) {
          bannedEmployee.BannedEmployeeDetail.UserName = bannedEmployee.BannedEmployeeDetail.FirstName + ' ' + bannedEmployee.BannedEmployeeDetail.LastName;
        }

        bannedEmployee.BannedByDetail = _.get(res.references, bannedEmployee.BannedBy);
        bannedEmployee.BannedByDetail.fullName = bannedEmployee.BannedByDetail.FirstName + ' ' + bannedEmployee.BannedByDetail.LastName;
        bannedEmployee.ContactDetail = _.get(res.references, bannedEmployee.Contact);
        bannedEmployee.ActionedByDetail = _.get(res.references, bannedEmployee.ActionedBy);

        if (bannedEmployee.ActionedByDetail && bannedEmployee.ActionedByDetail.FirstName) {
          bannedEmployee.ActionedByDetail.UserName = bannedEmployee.ActionedByDetail.FirstName + ' ' + bannedEmployee.ActionedByDetail.LastName;
        }

        bannedEmployee.SiteDetail = _.get(res.references, bannedEmployee.Site);

        bannedEmployees.push(bannedEmployee);
      });

      this.dataClients = bannedEmployees;
    }, error => {
    });
  }

  downloadPDF() {
    this.helperService.showLoading();
    try {
      let data = this.contactService.downnloadPDF(this.bannedEmployee.ObjectID);
      const file = new Blob([data], { type: 'application/pdf' });
      FileSaver.saveAs(file, `${new Date().toISOString()}.pdf`);
      this.helperService.hideLoading();
    } catch (e) {
      this.helperService.hideLoading();
    }
  }

  renderFormAddBannedEmployee(bannedEmployee: BannedEmployee) {
    let form = this.fb.group({
      Site: [bannedEmployee.SiteDetail],
      ActionsTakingDetails: [bannedEmployee.ActionsTakingDetails],
      BannedPeriod: [bannedEmployee.BannedPeriod ? bannedEmployee.BannedPeriod.Value : null, [Validators.required]],
      BannedBy: [bannedEmployee.BannedByDetail, [Validators.required]],
      NotificationTime: [bannedEmployee.NotificationTime],
      BannedDate: [bannedEmployee.BannedDate, [Validators.required]],
      BannedFromAllClientSites: [bannedEmployee.BannedFromAllClientSites],
      Contact: [bannedEmployee.ContactDetail],
      ClosedTime: [bannedEmployee.ClosedTime ? moment(bannedEmployee.ClosedTime).utc().format('hh:mm') : null],
      BannedEmployee: [bannedEmployee.BannedEmployeeDetail, [Validators.required]],
      ActionedBy: [bannedEmployee.ActionedByDetail],
      NotificationType: [bannedEmployee.NotificationType ? bannedEmployee.NotificationType.Value : null],
      ReasonForBanning: [bannedEmployee.ReasonForBanning],
      ClosedDate: [bannedEmployee.ClosedDate],
      ReminderType: [bannedEmployee.ReminderType ? bannedEmployee.ReminderType.Value : null],
      BannedByOther: [bannedEmployee.BannedByOther],
    });

    form.valueChanges.subscribe(s => {
      this.calculateBannedLifted();
    })
    return form;
  }

  loadData() {
    // this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.contactService.getClientManager(), // Users
        this.configuarationService.getAllSiteByQueryParams({}).toPromise(),
        this.contactService.getContacts({}),
        this.contactService.getReminderTypes(),
        this.contactService.getBannedPeriods(),
        this.contactService.getNotificationTypes(),

        // this.configuarationService.getAllClient().toPromise()
      ]).then(
        ([secUsers, sites, contacts, reminderType, bannedPeriods, notifications]) => {
          this.secUsers = this.contactService.getReferencesData(secUsers);
          this.secUsers.forEach(element => {
            if (element.FirstName) {
              element.UserName = element.FirstName + ' ' + element.LastName;
            }
          })
          this.sites = this.contactService.getReferencesData(sites);
          this.contacts = this.contactService.getReferencesData(contacts);
          this.reminderType = reminderType.results;
          this.bannedPeriod = bannedPeriods.results;
          this.notificationType = notifications.results;
        }).catch(e => {
        })
    });
  }

  showDetailBannedEmployee(event: any) {
    if (event) {
      this.bannedEmployee = event.data;
      this.isEditBanned = 'Edit';
    } else {
      this.bannedEmployee = new BannedEmployee();
      this.isEditBanned = 'Add';
    }

    this.formAddBannedEmployee = this.renderFormAddBannedEmployee(this.bannedEmployee);
    this.calculateBannedLifted();
    this.modalAddBannedEmployee.show();
  }
}
