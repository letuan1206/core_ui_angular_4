import { ModalModule } from 'ng2-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MomentModule } from 'angular2-moment';
import { DataTableModule } from 'primeng/datatable';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoCompleteModule } from 'primeng/autocomplete';
// Components
import { BannedEmployeesComponent } from './banned-employees.component';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { TextMaskModule } from 'angular2-text-mask';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    MomentModule,
    FormsModule,
    ReactiveFormsModule,
    AutoCompleteModule,
    DateTimePickerModule,
    TextMaskModule,
    ModalModule.forRoot(),
  ],
  declarations: [
    BannedEmployeesComponent
  ],
  bootstrap: [
    BannedEmployeesComponent
  ],
  exports: [
    BannedEmployeesComponent
  ]
})
export class BannedEmployeesModule { }
