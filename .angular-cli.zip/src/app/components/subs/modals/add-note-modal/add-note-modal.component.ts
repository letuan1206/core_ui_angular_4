import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable'
// Services
import { HelperService } from '../../../../services/helper.service';
import { ApiService } from '../../../../services/api.service';
import { ConfigService } from '../../../../services/config.service';
import { CommonService } from '../../../../services/common.service';

import * as _ from 'lodash';


interface Notes {
  Subject: string;
  HasExternalContact: string | null;
  ExternalContact: string | null;
  Description: string | null;
  ModifiedTime: string | null;
  ObjectClass: string | null;
  ObjectID: string | null;
  AllocatedTo: string | null;
  ModifiedBy: string | null;
}

@Component({
  selector: 'app-add-note-modal',
  templateUrl: './add-note-modal.component.html',
  styleUrls: ['./add-note-modal.component.scss']
})
export class AddNoteModalComponent implements OnInit {
  @ViewChild('addNotesModal') public addNotesModal: ModalDirective;
  @Output() saveNoteSuccessed = new EventEmitter<boolean>();

  actionType: string = 'create';
  disableForm: boolean = false;

  clientId: string;
  contactId: string;
  siteId: string;
  employeeId: string;

  allocateds: any = [];
  filteredAllocateds: any = [];
  currentNote: any = {};

  dataNotes: Notes = {
    Subject: null,
    HasExternalContact: null,
    ExternalContact: null,
    Description: null,
    ModifiedTime: null,
    ObjectClass: "prosek.orm.Note",
    ObjectID: null,
    AllocatedTo: null,
    ModifiedBy: null
  };
  private addNoteForm: FormGroup;

  constructor(
    private configService: ConfigService,
    private commonService: CommonService,
    private helperService: HelperService,
    private apiService: ApiService
  ) { }

  ngOnInit() {
    this.initForm();
  }

  private initForm() {
    let noteData: any = {
      subject: null,
      allocatedTo: null,
      other: null,
      description: null
    }

    this.addNoteForm = new FormGroup({
      subject: new FormControl(noteData.subject, Validators.required),
      allocatedTo: new FormControl(noteData.allocatedTo),
      other: new FormControl(noteData.other),
      description: new FormControl(noteData.description)
    })
  }

  initParams(clientId, noteId: any = null, contactId: any = null, siteId: any = null, employeeId: string = null) {
    this.clientId = clientId;
    this.contactId = contactId;
    this.siteId = siteId;
    this.employeeId = employeeId;

    this.getContact()
      .subscribe(res => {
        if (!noteId) {
          this.disableForm = false;
          this.actionType = 'create';
          this.initForm();
        } else {
          this.actionType = 'edit';
          this.getNote(noteId);
        }
      }, err => {
      })
  }

  async getNote(noteId) {
    let data = await this.commonService.queryById('/Notes', noteId);

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }

    let note = _.get(data.references, data.results[0]);
    this.currentNote = note;
    let allocatedTo = _.find(this.allocateds, item => {
      return item.ObjectID === note.AllocatedTo;
    });


    this.addNoteForm = new FormGroup({
      subject: new FormControl(note.Subject, Validators.required),
      allocatedTo: new FormControl(allocatedTo),
      other: new FormControl(note.Other),
      description: new FormControl(note.Description)
    })
    this.disableForm = true;
  }

  show() {
    this.addNotesModal.show();
  }
  hide() {
    this.addNotesModal.hide();
    this.initForm();
  }

  generateData(formValue) {
    let note = {
      "ObjectClass": "prosek.orm.Note",
      "Subject": formValue.subject,
      "Description": formValue.description,
      "Client": this.clientId,
      "Contact": this.contactId,
      "Site": this.siteId,
      "Employee": this.employeeId,
      "AllocatedTo": formValue.allocatedTo ? formValue.allocatedTo.ObjectID : null,
      "AllocatedToStr": formValue.allocatedTo ? formValue.allocatedTo.Name : null,
    }
    if (this.actionType === 'edit') {
      note["ObjectCreated"] = this.currentNote.ObjectCreated;
      note["ObjectID"] = this.currentNote.ObjectID;
      note["ObjectLastModified"] = moment();
    }
    return note;
  }

  enableForm() {
    this.disableForm = false;
  }

  addOrEditNote(form) {
    if (form.valid == false) {
      this.helperService.markFormGroupTouched(form);
      return;
    }
    this.helperService.showLoading();
    if (this.actionType === 'create') {
      this.addNote(form.value);
    } else {
      this.updateNote(form.value);
    }
  }

  async addNote(formValue) {
    let note = this.generateData(formValue);
    let params = {
      create: {
        "NEW:1": note
      }
    }
    this.apiService.saveService(params).subscribe(res => {
      this.helperService.hideLoading();
      if (res.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveSuccess();
      this.hide();
    }, err => {
      this.helperService.hideLoading();
    })
  }

  async updateNote(formValue) {
    let note = this.generateData(formValue);
    let params = {
      update: {
      }
    }
    params.update[this.currentNote.ObjectID] = note;

    this.apiService.saveService(params).subscribe(res => {
      this.helperService.hideLoading();
      if (res.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveSuccess();
      this.hide();
    }, err => {
      this.helperService.hideLoading();
    })
  }

  saveSuccess() {
    this.saveNoteSuccessed.emit(true);
  }

  // async getContact() {
  //   let dataContacts = await this.commonService.queryAllData('/Contact');

  //   if (dataContacts.result !== this.configService.successStatus) {
  //     throw Error('error');
  //   }

  //   if (!dataContacts.results || !dataContacts.results.length) {
  //     return;
  //   }

  //   // dataContacts.results.forEach(element => {
  //   //   let item = _.get(dataContacts.references, element);
  //   //   if (_.find(this.allocateds, { ObjectID: item.ObjectID }) == null) {
  //   //     this.allocateds.push({
  //   //       ObjectID: item.ObjectID,
  //   //       ObjectClass: item.ObjectClass,
  //   //       Name: `${item.FirstName} ${item.LastName}`
  //   //     })
  //   //   }

  //   // });
  //   this.allocateds = dataContacts.references.map(x => {
  //     return {
  //       ObjectID: x.ObjectID,
  //       ObjectClass: x.ObjectClass,
  //       Name: `${x.FirstName} ${x.LastName}`
  //     }
  //   })
  // }

  getContact() {
    let obsObj = new Observable(obs => {
      this.commonService.queryAllData('/Contact')
        .then(dataContacts => {
          if (dataContacts.result !== this.configService.successStatus) {
            throw Error('error');
          }

          if (!dataContacts.results || !dataContacts.results.length) {
            return;
          }

          this.allocateds = _.map(dataContacts.results, (x: any) => {
            return _.get(dataContacts.references, x);
          }).map(x => {
            return {
              ObjectID: x.ObjectID,
              ObjectClass: x.ObjectClass,
              Name: `${x.FirstName} ${x.LastName}`
            }
          })
          obs.next(null);
          obs.complete();
        }, err => {
          obs.error(err);
        })
    })

    return obsObj;
  }

  private checkAutoCompleteAllocatedTo(event, allocateds: any[]) {
    let inputText = event.query;
    this.filteredAllocateds = _.filter(allocateds, item => {
      return item.Name.toLowerCase().indexOf(inputText.toLowerCase()) == 0;
    })
  }
}
