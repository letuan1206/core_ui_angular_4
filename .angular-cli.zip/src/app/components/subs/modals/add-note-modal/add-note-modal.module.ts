import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';
import { CalendarModule } from 'primeng/calendar';

// Components

import { ModalModule } from 'ng2-bootstrap';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddNoteModalComponent } from './add-note-modal.component';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    CalendarModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule.forRoot()
  ],
  declarations: [
    AddNoteModalComponent
  ],
  bootstrap: [
    AddNoteModalComponent
  ],
  exports: [
    AddNoteModalComponent
  ]
})
export class AddNoteModalModule { }
