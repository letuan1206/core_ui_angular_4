import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddOrEditTimelineComponent } from './add-or-edit-timeline.component';

describe('AddOrEditTimelineComponent', () => {
  let component: AddOrEditTimelineComponent;
  let fixture: ComponentFixture<AddOrEditTimelineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddOrEditTimelineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOrEditTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
