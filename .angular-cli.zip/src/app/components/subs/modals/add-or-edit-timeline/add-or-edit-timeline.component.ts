import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { ModalDirective } from 'ng2-bootstrap';
import { CommonService } from '../../../../services/common.service';
import { ConfigService } from '../../../../services/config.service';
import * as _ from 'lodash';
import * as moment from 'moment';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HelperService } from '../../../../services/helper.service';
import { ApiService } from '../../../../services/api.service';
import { Observable } from 'rxjs/Observable';

import { ObjectAddress, ObjectGoogleAddress } from '../../../../interfaces/clients-interface';
@Component({
  selector: 'app-add-or-edit-timeline',
  templateUrl: './add-or-edit-timeline.component.html',
  styleUrls: ['./add-or-edit-timeline.component.scss']
})


export class AddOrEditTimelineComponent implements OnInit {
  @ViewChild('addOrEditTimelineModal') public addOrEditTimelineModal: ModalDirective;
  @Output() saveTimelineSuccessed = new EventEmitter<boolean>();

  actionType: string = 'create';
  types: any = [];
  client: any = {};
  clientId: string;
  contact: any = {};
  contactId: string;
  site: any = {};
  siteId: string;
  employeeId: string;

  activityStatuses: any = [];
  priorities: any = [];
  timelineForm: FormGroup;
  currentActivity: any;
  loaded: boolean = false;

  reminderTypes: any = [];
  notificationTypes: any = [];

  isClosedActivity: boolean = false;

  private addressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };

  // Variable for represent Follow up task/activity
  listParentActivity = [];
  enableFollowUp = false;

  // Object address
  objectAddress: ObjectAddress = null;
  nobjectAddress: ObjectAddress = null;
  objectGoogleAddress: ObjectGoogleAddress = null;
  nobjectGoogleAddress: ObjectGoogleAddress = null;

  //autocomplete
  secUsers: any = [];
  filteredSecUsers: any = [];
  allocateds: any = [];
  filteredAllocateds: any = [];
  contacts: any = [];
  filteredContacts: any = [];
  disableForm: boolean = false;

  constructor(
    private configService: ConfigService,
    private commonService: CommonService,
    private helperService: HelperService,
    private apiService: ApiService
  ) {
  }

  ngOnInit() {
    this.initForm();
  }

  initParams(clientId, selectedType: any = null, activityId: any = null, contactId: any = null, siteId: any = null, employeeId: string = null) {
    this.clientId = clientId;
    this.contactId = contactId;
    this.siteId = siteId;
    this.employeeId = employeeId;

    this.enableFollowUp = false;
    this.listParentActivity = [];
    this.currentActivity = null;
    // if (!this.loaded) {
    // this.loaded = true;
    this.getActivityTypes(selectedType);
    this.getPriorities();
    this.getSecUsers();
    this.getAllocateds();
    this.getContacts();
    this.getNotificationTypes();
    this.getReminderTypes();
    // }
    if (!activityId) {
      this.disableForm = false;
      this.actionType = 'create';

      // Init object address when create timeline
      this.objectAddress = {
        GoogleAddress: null,
        ObjectClass: 'prosek.orm.Address',
        ObjectCreated: null,
        ObjectID: null,
        ObjectLastModified: null,
        PostcodeSuburb: null,
        Street: null,
      }

      this.initForm();
    } else {
      this.actionType = 'edit';
      this.getActivity(activityId);

    }
  }

  async getActivity(activityId) {
    let params = {
      id: activityId
    }
    let data = await this.commonService.query('/Activities', params, ['Address', 'Address.GoogleAddress'], 'ByID');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }

    let activity = _.get(data.references, data.results[0]);
    this.currentActivity = activity;
    // Set status of activity. It may be "ACTIVE" or "INACTIVE"
    this.isClosedActivity = this.currentActivity && this.currentActivity.ActivityStatus && this.currentActivity.ActivityStatus.Value === 'CLOSED' ? true : false;

    this.getParentActivity(activity.ParentActivity);
    let assignedTo = _.find(this.secUsers, item => {
      return item.ObjectID === activity.AssignedTo;
    });

    let allocatedTo = _.find(this.allocateds, item => {
      return item.Name === activity.AllocatedToStr;
    });

    let contact = _.find(this.contacts, item => {
      return item.ObjectID === activity.ContactName;
    });

    // Update object address

    // Clone object address. CANT BE NULL
    let objectEmptyGoogleAddress: ObjectGoogleAddress = {
      ObjectClass: 'prosek.orm.GoogleAddress',
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      City: null,
      Country: null,
      GoogleAddressText: null,
      Latitude: null,
      Longitude: null,
      State: null,
      StreetAddress: null,
      StreetNumber: null,
      ZipCode: null
    };

    let objectEmptyAddress: ObjectAddress = {
      ObjectClass: 'prosek.orm.Address',
      GoogleAddress: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      PostcodeSuburb: null,
      Street: null
    }

    this.objectAddress = activity.Address !== null ? _.get(data.references, activity.Address) : null;
    this.objectGoogleAddress = activity && activity.Address && this.objectAddress && this.objectAddress.GoogleAddress ? _.get(data.references, this.objectAddress.GoogleAddress) : null

    this.nobjectAddress = this.objectAddress ? Object.assign({}, this.objectAddress) : Object.assign({}, objectEmptyAddress);
    this.nobjectGoogleAddress = this.objectGoogleAddress ? Object.assign({}, this.objectGoogleAddress) : Object.assign({}, objectEmptyGoogleAddress);

    this.addressGeolocationSetting = Object.assign({}, this.addressGeolocationSetting, { inputString: this.objectAddress.Street });

    this.timelineForm = new FormGroup({
      subject: new FormControl(activity.Subject, Validators.required),
      assignedTo: new FormControl(assignedTo, Validators.required),
      dueDate: new FormControl(new Date(activity.DueDate), Validators.required),
      dueTime: new FormControl(new Date(activity.DueTime), Validators.required),
      allocatedTo: new FormControl(allocatedTo),
      contactName: new FormControl(contact),
      activityType: new FormControl(activity.ActivityType.Value, Validators.required),
      priority: new FormControl(activity.Priority.Value, Validators.required),
      reminder: new FormControl(activity.ReminderType ? activity.ReminderType.Value : ""),
      notification: new FormControl(activity.NotificationTime),
      notificationType: new FormControl(activity.NotificationType ? activity.NotificationType.Value : ""),
      description: new FormControl(activity.Description),
      actionDetails: new FormControl(activity.ActionDetails),
      invitations: new FormControl(activity.Invitations),
      address: new FormControl(this.objectAddress ? this.objectAddress.Street : null),
    })
    this.disableForm = true;
  }

  enableForm() {
    this.disableForm = false;
  }

  initForm() {
    const defaultDate = new Date("01/01/2018 08:00");
    this.timelineForm = new FormGroup({
      subject: new FormControl("", Validators.required),
      assignedTo: new FormControl("", Validators.required),
      dueDate: new FormControl("", Validators.required),
      dueTime: new FormControl(defaultDate, Validators.required),
      allocatedTo: new FormControl(""),
      contactName: new FormControl(""),
      activityType: new FormControl("", Validators.required),
      priority: new FormControl("", Validators.required),
      reminder: new FormControl(""),
      notification: new FormControl(15),
      notificationType: new FormControl(),
      description: new FormControl(""),
      actionDetails: new FormControl(""),
      invitations: new FormControl(""),
      address: new FormControl(""),
    })
  }

  //#region get form detail
  getAllocateds() {
    this.allocateds = [];
    if (this.clientId) {
      this.client = this.getClient();
    }
    if (this.contactId) {
      this.contact = this.getContact();
    }
    if (this.siteId) {
      this.site = this.getSite();
    }
    this.getSites();
  }

  async getSite(siteId: string = null) {
    let id;
    if (!siteId) {
      id = this.siteId;
    } else {
      id = siteId;
    }

    let data = await this.commonService.queryById('/Sites', id);

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    let site = _.get(data.references, data.results[0]);

    if (!siteId && site.SiteName) {
      this.allocateds.push({
        ObjectID: site.ObjectID,
        ObjectClass: site.ObjectClass,
        Name: site.SiteName
      });
      this.timelineForm.patchValue({ "allocatedTo": this.allocateds[0] })
    }
    return site;
  }

  async getContact(contactId: string = null) {
    let id;
    if (!contactId) {
      id = this.contactId;
    } else {
      id = contactId;
    }

    let data = await this.commonService.queryById('/Contact', id);

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    let contact = _.get(data.references, data.results[0]);

    if (!contactId && contact.CompanyName) {
      this.allocateds.push({
        ObjectID: contact.ObjectID,
        ObjectClass: contact.ObjectClass,
        Name: contact.CompanyName
      });
      this.timelineForm.patchValue({ "allocatedTo": this.allocateds[0] })
    }
    return contact;
  }

  async getClient(clientID: string = null) {
    let id;
    if (!clientID) {
      id = this.clientId;
    } else {
      id = clientID;
    }

    let data = await this.commonService.queryById('/Clients', id);

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    let client = _.get(data.references, data.results[0]);

    if (!clientID && client.CompanyName) {
      this.allocateds.push({
        ObjectID: client.ObjectID,
        ObjectClass: client.ObjectClass,
        Name: client.CompanyName
      });
      this.timelineForm.patchValue({ "allocatedTo": this.allocateds[0] })
    }
    return client;
  }

  async getSites() {
    let dataSites = await this.commonService.queryAllData('/Sites');

    if (dataSites.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!dataSites.results || !dataSites.results.length) {
      return;
    }
    let sites = _.filter(dataSites.references, ref => {
      return ref.Client === this.clientId;
    })
    _.each(sites, site => {
      this.allocateds.push({
        ObjectID: site.ObjectID,
        ObjectClass: site.ObjectClass,
        Name: site.SiteName
      })
    })
  }

  async getSecUsers() {
    let dataUsers = await this.commonService.queryAllData('/Users');

    if (dataUsers.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!dataUsers.results || !dataUsers.results.length) {
      return;
    }
    this.secUsers = _.filter(dataUsers.references, x =>
      dataUsers.results.indexOf(x.ObjectID) !== -1
    );
    _.forEach(this.secUsers, item => {
      item.FullName = item.FirstName + ' ' + item.LastName;
    })

  }

  async getActivityStatuses() {
    let dataStatus = await this.commonService.queryAllData('/ActivityStatuses');

    if (dataStatus.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!dataStatus.results || !dataStatus.results.length) {
      return;
    }
    this.activityStatuses = dataStatus.results;
  }

  async getActivityTypes(type) {
    let data = await this.commonService.queryAllData('/ActivityTypes');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    this.types = _.filter(data.results, item => {
      return !item.disabled && item.Description.indexOf(type) > -1;
    });


    if (!this.types || !this.types.length) {
      this.types = _.filter(data.results, item => {
        return !item.disabled;
      })
    } else {
      this.timelineForm.patchValue({ "activityType": this.types[0].Value })
    }
  }

  async getNotificationTypes() {
    let data = await this.commonService.queryAllData('/NotificationTypes');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }

    this.notificationTypes = data.results;
    this.timelineForm.patchValue({ "notificationType": this.notificationTypes[0].Value })
  }

  async getReminderTypes() {
    let data = await this.commonService.queryAllData('/ReminderTypes');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }

    this.reminderTypes = data.results;
    this.timelineForm.patchValue({ "reminder": this.reminderTypes[0].Value })

  }

  async getPriorities() {
    let data = await this.commonService.queryAllData('/Priorities');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    this.priorities = data.results;
  }

  async getContacts() {
    let data = await this.commonService.queryAllData('/Contact');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    this.contacts = _.filter(data.references, x =>
      data.results.indexOf(x.ObjectID) !== -1
    );
    _.forEach(this.contacts, item => {
      item.FullName = item.FirstName + ' ' + item.LastName;
    })
  }

  private checkAutoCompleteAssignedTo(event, secUsers: any[]) {
    let inputText = event.query;
    this.filteredSecUsers = _.filter(secUsers, item => {
      return item.FullName.toLowerCase().indexOf(inputText.toLowerCase()) == 0;
    })
  }

  private checkAutoCompleteAllocatedTo(event, allocateds: any[]) {
    let inputText = event.query;
    this.filteredAllocateds = _.filter(allocateds, item => {
      return item.Name.toLowerCase().indexOf(inputText.toLowerCase()) == 0;
    })
  }

  private checkAutoCompleteContact(event, contacts: any[]) {
    let inputText = event.query;
    this.filteredContacts = _.filter(contacts, item => {
      return item.FullName.toLowerCase().indexOf(inputText.toLowerCase()) == 0;
    })
  }
  //#endregion

  //#region  actions
  addOrEditTimeline(form) {
    if (!form || !form.valid) {
      this.helperService.markFormGroupTouched(form);
      return;
    }
    this.helperService.showLoading();
    if (this.enableFollowUp == true) {
      this.saveFollowTaskActivity();
      return;
    }
    if (this.actionType === 'create') {
      this.addTimeline(form.value);
    } else {
      this.updateTimeline(form.value);
    }
  }

  generateData(formValue) {
    let reminder = _.find(this.reminderTypes, item => {
      return item.Value === formValue.reminder;
    });

    let notificationType = _.find(this.notificationTypes, item => {
      return item.Value === formValue.notificationType;
    });

    let time = moment(formValue.dueTime, 'HH:mm');
    let date = moment(formValue.dueDate, 'DD-MM-YYYY');
    let dueDate = moment(date + " " + time, 'DD-MM-YYYY HH:mm');
    let activity = {
      "ObjectClass": "prosek.orm.Activity",
      "Subject": formValue.subject,
      "DueDate": date,
      "DueTime": time,
      "ActivityType": formValue.activityType,
      "Priority": formValue.priority,
      "ActivityStatus": "OPEN",
      // "Invitations": formValue.invitations,
      "Address": this.objectAddress && this.objectAddress.ObjectID ? this.objectAddress.ObjectID : null,
      "Description": formValue.description,
      "ActionDetails": formValue.actionDetails,
      "ModifiedDate": moment(),
      "AllocatedToStr": formValue.allocatedTo ? formValue.allocatedTo.Name : null,
      "AssignedTo": formValue.assignedTo ? formValue.assignedTo.ObjectID : null,
      "AssignedToStr": formValue.assignedTo ? formValue.assignedTo.FullName : null,
      // "ActionedBy": null,
      // "ParentActivity": null,
      "Client": this.clientId,
      "NotificationTime": parseInt(formValue.notification),
      "NotificationType": notificationType,
      "ReminderType": reminder,
      "Site": this.siteId,
      "Employee": this.employeeId,
      "ContactName": formValue.contactName ? formValue.contactName.ObjectID : null,
      "Contact": this.contactId,
      "ContactNameStr": formValue.contactName ? formValue.contactName.FullName : null,
    }
    if (this.actionType === 'edit') {
      activity["ObjectCreated"] = this.currentActivity.ObjectCreated;
      activity["ObjectID"] = this.currentActivity.ObjectID;
      activity["ObjectLastModified"] = moment();

    }
    return activity;
  }

  generateDataFollowUp(formValue, idParentActivity: string) {
    let reminder = _.find(this.reminderTypes, item => {
      return item.Value === formValue.reminder;
    });

    let notificationType = _.find(this.notificationTypes, item => {
      return item.Value === formValue.notificationType;
    });

    let time = moment(formValue.dueTime).format('HH:mm');
    let date = moment(formValue.dueDate).format('DD-MM-YYYY');
    let dueDate = moment(date + " " + time, 'DD-MM-YYYY HH:mm');

    let activity = {
      "ObjectClass": "prosek.orm.Activity",
      "ObjectCreated": null,
      "ObjectID": null,
      "ObjectLastModified": null,
      "Subject": formValue.subject,
      "DueDate": dueDate,
      "ActivityType": formValue.activityType,
      "Priority": formValue.priority,
      "ActivityStatus": "OPEN",
      // "Invitations": formValue.invitations,
      "Address": this.objectAddress && this.objectAddress.ObjectID ? this.objectAddress.ObjectID : null,
      "Description": formValue.description,
      "ActionDetails": formValue.actionDetails,
      "ModifiedDate": moment(),
      "AllocatedToStr": formValue.allocatedTo ? formValue.allocatedTo.Name : null,
      "AssignedTo": formValue.assignedTo ? formValue.assignedTo.ObjectID : null,
      "AssignedToStr": formValue.assignedTo ? formValue.assignedTo.FullName : null,
      // "ActionedBy": null,
      "ParentActivity": idParentActivity,
      "Client": this.clientId,
      "NotificationTime": parseInt(formValue.notification),
      "NotificationType": notificationType,
      "ReminderType": reminder,
      "Site": this.siteId,
      "Employee": this.employeeId,
      "ContactName": formValue.contactName ? formValue.contactName.ObjectID : null,
      "Contact": this.contactId,
      "ContactNameStr": formValue.contactName ? formValue.contactName.FullName : null,
    }

    return activity;
  }

  updateTimeline(formValue) {
    // Update Object Address and Activity
    let activity = this.generateData(formValue);
    let params = {
      update: {
      }
    }
    if(this.objectAddress){
      params.update[this.objectAddress.ObjectID] = Object.assign({}, this.nobjectAddress, {
        ObjectID: this.objectAddress.ObjectID
      });
    }
    if(this.objectGoogleAddress){
      params.update[this.objectGoogleAddress.ObjectID] = Object.assign({}, this.nobjectGoogleAddress, {
        ObjectID: this.objectGoogleAddress.ObjectID
      });
    }

    params.update[this.currentActivity.ObjectID] = activity;

    this.apiService.saveService(params).subscribe(res => {
      this.helperService.hideLoading();
      if (res.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveSuccess();
      this.hide();
    }, err => {
      this.helperService.hideLoading();
    })
  }

  closeTimeline(formValue) {
    let activity = this.generateData(formValue);
    activity.ActivityStatus = "CLOSED";
    activity["ClosedDateTime"] = moment();
    let params = {
      update: {
      }
    }
    params.update[this.currentActivity.ObjectID] = activity;

    this.apiService.saveService(params).subscribe(res => {
      this.helperService.hideLoading();
      if (res.result !== this.configService.successStatus) {
        throw Error('error');
      }
      this.saveSuccess();
      this.hide();
    }, err => {
      this.helperService.hideLoading();
    })
  }

  addTimeline(formValue) {
    // Create object Address
    let createObjectGoogleAddress = () => {
      if (!this.nobjectGoogleAddress) {
        return new Observable(obs => {
          obs.next();
        });
      }
      let obsObj = new Observable(obs => {
        let newObj = this.nobjectGoogleAddress;
        let params = {
          create: {
            "NEW:1": newObj
          }
        }
        this.apiService.saveService(params).subscribe(res => {
          if (res.result !== this.configService.successStatus) {
            obs.error('Create object google address fail');
          } else {
            obs.next(res.created['NEW:1']);
          }
        }, err => {
          obs.error(err);
        })
      });

      return obsObj;
    };

    let createObjectAddress = (idGoogleAddress) => {
      if (!idGoogleAddress) {
        return new Observable(obs => {
          obs.next();
        });
      }
      let obsObj = new Observable(obs => {
        let newObj = Object.assign({}, this.nobjectAddress, {
          GoogleAddress: idGoogleAddress
        });

        let params = {
          create: {
            "NEW:1": newObj
          }
        }
        this.apiService.saveService(params).subscribe(res => {
          if (res.result !== this.configService.successStatus) {
            obs.error('Create object address fail');
          } else {
            obs.next(res.created['NEW:1']);
          }
        }, err => {
          obs.error(err);
        })
      });

      return obsObj;
    };

    let createObjectTimeline = (idAddress) => {
      let obsObj = new Observable(obs => {
        this.objectAddress.ObjectID = idAddress;
        let activity = this.generateData(formValue);
        let params = {
          create: {
            "NEW:1": activity
          }
        }
        this.apiService.saveService(params).subscribe(res => {
          if (res.result !== this.configService.successStatus) {
            obs.error('Create object timeline fail');
          } else {
            obs.next();
          }
        }, err => {
          obs.error(err);
        })
      });

      return obsObj;
    };

    createObjectGoogleAddress()
      .flatMap(idGoogleAddress => createObjectAddress(idGoogleAddress))
      .flatMap(createObjectTimeline)
      .subscribe(resp => {
        this.helperService.hideLoading();
        this.saveSuccess();
        this.hide();
      }, err => {
        this.helperService.hideLoading();
      })
  }

  saveSuccess() {
    this.saveTimelineSuccessed.emit(true);
  }

  enableFollowTaskActivity() {
    this.disableForm = false;
    this.timelineForm.patchValue({ dueDate: null });
    this.enableFollowUp = true;
    let activity = this.currentActivity;
    activity.ClosedDateTime = moment();
    this.listParentActivity.push(activity);
    this.listParentActivity=_.sortBy(this.listParentActivity,"ClosedDateTime");
    this.listParentActivity=_.reverse(this.listParentActivity);
  }

  async saveFollowTaskActivity() {
    let params = {
      update: {},
      create: {}
    }

    // Check form value
    if (this.timelineForm.valid === false) {
      return;
    }

    try {
      // Create child activity
      let activity = this.generateDataFollowUp(this.timelineForm.value, this.currentActivity.ObjectID);

      params.create['NEW:1'] = activity;

      // Close this current activity
      let closeTarget = {
        "ObjectClass": "prosek.orm.Activity",
        "ObjectID": this.currentActivity.ObjectID,
        "ActivityStatus": "CLOSED",
        "ClosedDateTime": moment()
      }
      params.update[closeTarget.ObjectID] = closeTarget;

      let updateActivity = await this.apiService.saveService(params).toPromise();
      this.helperService.hideLoading();
      if (updateActivity.result !== this.configService.successStatus) {
        throw Error('error');
      }

      this.saveSuccess();
      this.hide();
    } catch (error) {
    }
  }

  async getParentActivity(parentId) {
    if (!parentId) {
      return;
    }
    let data = await this.commonService.queryById('/Activities', parentId);

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }

    let activity = _.get(data.references, data.results[0]);
    this.listParentActivity.push(activity);
    if (!activity.ParentActivity) {
      return;
    }
    await this.getParentActivity(activity.ParentActivity);
  }

  //#endregion

  //#region modal actions
  show() {
    this.addOrEditTimelineModal.show();
  }

  hide() {
    this.addOrEditTimelineModal.hide();
    this.initForm();
  }
  //#endregion

  googleAddressModel: any;
  addressModel: any;

  autoCompleteAddressCallback(selectedData: any) {
    let addressDetail = null;
    if (selectedData.response) {
      let addressDetail = this.commonService.getAddressDetail(selectedData.data.address_components);
    }

    this.nobjectGoogleAddress = {
      ObjectClass: 'prosek.orm.GoogleAddress',
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      City: addressDetail && addressDetail.City ? addressDetail.City.long_name : null,
      Country: addressDetail && addressDetail.Country ? addressDetail.Country.long_name : null,
      State: addressDetail && addressDetail.State ? addressDetail.State.long_name : null,
      StreetAddress: addressDetail && addressDetail.StreetAddress ? addressDetail.StreetAddress.long_name : null,
      StreetNumber: addressDetail && addressDetail.StreetNumber ? addressDetail.StreetNumber.long_name : null,
      ZipCode: addressDetail && addressDetail.ZipCode ? addressDetail.ZipCode.long_name : null,
      GoogleAddressText: selectedData && selectedData.response && selectedData.data.description,
      Latitude: selectedData && selectedData.response && selectedData.data.geometry.location.lat,
      Longitude: selectedData && selectedData.response && selectedData.data.geometry.location.lng,
    }

    this.nobjectAddress = {
      GoogleAddress: null,
      ObjectClass: 'prosek.orm.Address',
      ObjectID: null,
      ObjectCreated: null,
      ObjectLastModified: null,
      PostcodeSuburb: null,
      Street: selectedData && selectedData.response && selectedData.data.description
    }
  }

  createGoogleAddress() {
    this.commonService.createGoogleAddress(this.googleAddressModel);
    this.createAddress();
  }

  createAddress() {
    this.addressModel.ObjectClass = 'prosek.orm.Address';
    this.addressModel.ObjectCreated = null;
    this.addressModel.ObjectID = null;
    this.addressModel.ObjectLastModified = null;
    this.addressModel.Street = this.googleAddressModel.GoogleAddressText;
    this.addressModel.GoogleAddress = this.googleAddressModel.ObjectID;
    this.commonService.createAddress(this.googleAddressModel);
  }
}
