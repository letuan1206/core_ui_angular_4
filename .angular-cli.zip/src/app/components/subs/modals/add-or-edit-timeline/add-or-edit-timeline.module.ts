// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';
import { CalendarModule } from 'primeng/calendar';
import { ModalModule } from 'ng2-bootstrap';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng4GeoautocompleteModule } from 'ng4-gmap-autocomplete';

// Components
import { AddOrEditTimelineComponent } from './add-or-edit-timeline.component';


@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    CalendarModule,
    AutoCompleteModule,
    FormsModule,
    ReactiveFormsModule,
    Ng4GeoautocompleteModule.forRoot(),
    ModalModule.forRoot()
  ],
  declarations: [
    AddOrEditTimelineComponent
  ],
  bootstrap: [
    AddOrEditTimelineComponent
  ],
  exports: [
    AddOrEditTimelineComponent
  ]
})
export class AddOrEditTimelineModule { }
