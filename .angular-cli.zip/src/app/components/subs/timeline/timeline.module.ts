import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MomentModule } from 'angular2-moment';

// Components
import { TimelineComponent } from './timeline.component';
import { AddOrEditTimelineModule } from '../modals/add-or-edit-timeline/add-or-edit-timeline.module';
import { AddNoteModalModule } from '../modals/add-note-modal/add-note-modal.module';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule,
    AddOrEditTimelineModule,
    AddNoteModalModule,
    DropdownModule,
    FormsModule,
    DateTimePickerModule,
    AutoCompleteModule,
    MomentModule
  ],
  declarations: [
    TimelineComponent
  ],
  bootstrap: [
    TimelineComponent
  ],
  exports: [
    TimelineComponent
  ],
  providers: [

  ]
})
export class TimelineModule { }
