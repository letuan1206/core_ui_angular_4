import { Component, OnInit, Input, ViewChild } from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import get = require('lodash/get');
import concat = require('lodash/concat');


// Services
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';

// Redux
import { NgRedux, select } from 'ng2-redux';
import {
  STORE_SUB_TIMELINE_CLIENTS_NOTES,
  STORE_SUB_TIMELINE_CLIENTS_TASK,
  STORE_SUB_NOTES_CLIENTS
} from '../../common/common-actions';
import { AddNoteModalComponent } from '../modals/add-note-modal/add-note-modal.component';
import { AddOrEditTimelineComponent } from '../modals/add-or-edit-timeline/add-or-edit-timeline.component';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {

  @Input() type: string;
  @Input() clientId: string;
  @Input() contactId: string;
  @Input() siteId: string;
  @Input() employeeId: string;

  getClientsData: any;
  client: any = {};

  subTimelineClientsData: any = [];
  rootData: any = [];
  filteredSecUsers: any = [];
  allocateds: any = [];
  filterData: any = {};
  filterType: any = [
    {
      type: null,
      name: "All"
    }, {
      type: "Activity",
      name: "Tasks/Activities"
    }, {
      type: "Notes",
      name: "Notes"
    }];

  filterNotes: any = {};
  filterActivityType: any = [];
  filterAllocatedTo: any = [];
  activityTypes: any = [];
  private filteredServiceMultiple: any[];

  // Redux store
  @select(s => s.common.subTimelineClientsNotes) subTimelineClientsNotes;
  @select(s => s.common.clientsData) clientsData;
  @ViewChild('addOrEditTimelineModal') addOrEditTimelineModal: AddOrEditTimelineComponent;
  @ViewChild('addNotesModal') public addNotesModal: AddNoteModalComponent;

  constructor(
    private configService: ConfigService,
    private commonService: CommonService,
    private helperService: HelperService
  ) {
    this.subTimelineClientsNotes.subscribe(data => {

    });
    this.clientsData.subscribe(data => {
      this.getClientsData = data;
    });
  }

  //#region init

  async ngOnInit() {
    this.filterData.type = this.filterType[0];
    this.filterData.activityType = this.filterActivityType[0];
    await this.getNotes();
    await this.getTasks();
    this.getActivityTypes();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  
  async getNotes() {
    switch (this.type) {
      case this.configService.get('menuType')['sites']: {
      }
      case this.configService.get('menuType')['contacts']: {
      }
      case this.configService.get('menuType')['clients']: {
        try {
          let dataNotesClient = this.commonService.query('/Notes', {
            "Client": this.clientId,
            "Contact": this.contactId,
            "Site": this.siteId,
            "Employee": this.employeeId
          }, [
              "AllocatedTo"
            ]
          );
          let dataNotes = await dataNotesClient;
          if (dataNotes.result !== this.configService.successStatus) {
            throw Error('error');
          }

          if (!dataNotes.results || !dataNotes.results.length) {
            return;
          }
          let arr = [];
          for (var i = 0; i < dataNotes.results.length; i++) {
            let note = get(dataNotes.references, dataNotes.results[i]);
            let allocatedTo;
            this.filterNotes.listAssignTo = [];
            if (note.AllocatedTo) {
              let itemAllocated = get(dataNotes.references, note.AllocatedTo);
              allocatedTo = {
                ObjectID: note.AllocatedTo,
                Name: `${itemAllocated.FirstName} ${itemAllocated.LastName}`
              }
              if (_.find(this.allocateds, { ObjectID: note.AllocatedTo }) == null) {
                this.allocateds.push(allocatedTo);
              }
            }
            arr.push({
              objectId: note.ObjectID,
              subject: note.Subject,
              description: note.Description,
              allocatedTo: allocatedTo ? allocatedTo.Name : "",
              modifiedTime: note.ObjectLastModified !== null ? moment.utc(note.ObjectLastModified) : null,
              assignTo: note.AllocatedTo,
              createdTime: note.ObjectCreated !== null ? moment(note.ObjectCreated).format('MM-DD-YYYY').toString() : null,
              type: 'Notes'
            });
          }
          this.subTimelineClientsData = concat(this.subTimelineClientsData, arr);
          this.subTimelineClientsData = _.sortBy(this.subTimelineClientsData, 'modifiedTime');
          this.subTimelineClientsData = _.reverse(this.subTimelineClientsData);
          this.rootData = this.subTimelineClientsData;
        } catch (e) {
          this.helperService.handleError(e);
        }
        break;
      }

      default: {
        break;
      }
    }
  }

  async getTasks() {
    switch (this.type) {
      case this.configService.get('menuType')['sites']: {
      }
      case this.configService.get('menuType')['contacts']: {
      }
      case this.configService.get('menuType')['clients']: {
        try {
          let dataTaskClient = this.commonService.query('/Activities', {
            "Client": this.clientId,
            "Contact": this.contactId,
            "Site": this.siteId,
            "Employee": this.employeeId
          });
          let dataTask = await dataTaskClient;
          if (dataTask.result !== this.configService.successStatus) {
            throw Error('error');
          }

          if (!dataTask.results || !dataTask.results.length) {
            return;
          }
          let arr = [];
          for (var i = 0; i < dataTask.results.length; i++) {
            let task = get(dataTask.references, dataTask.results[i]);

            // Init Filter Data
            if (task.AssignedTo && _.find(this.allocateds, { ObjectID: task.AssignedTo }) == null) {
              this.allocateds.push({
                Name: task.AssignedToStr,
                ObjectID: task.AssignedTo
              });
            }
            // end Filter Data

            arr.push({
              objectId: task.ObjectID,
              subject: task.Subject,
              description: task.Description,
              allocatedTo: task.AssignedToStr,
              activityType: task.ActivityType,
              modifiedTime: task.ObjectLastModified !== null ? moment.utc(task.ObjectLastModified) : null,
              type: task.ActivityType ? task.ActivityType.Description : 'Task/Activities',
              dueDate: task.DueDate !== null ? moment(task.DueDate).format('MM-DD-YYYY').toString() : null,
              assignTo: task.AssignedToStr
            });
            arr = _.sortBy(arr, "modifiedTime");
          }

          this.subTimelineClientsData = concat(this.subTimelineClientsData, arr);
          this.subTimelineClientsData = _.sortBy(this.subTimelineClientsData, 'modifiedTime');
          this.subTimelineClientsData = _.reverse(this.subTimelineClientsData);
          this.rootData = this.subTimelineClientsData;
        } catch (e) {
          this.helperService.handleError(e);
        }
        break;
      }
      default: {
        break;
      }
    }
  }
  //#endregion

  //#region filter

  private checkAutoCompleteAllocatedTo(event, secUsers: any[]) {
    let inputText = event.query;
    this.filterAllocatedTo = _.filter(secUsers, item => {
      return item.Name.toLowerCase().indexOf(inputText.toLowerCase()) == 0;
    })
  }

  async getActivityTypes() {
    let data = await this.commonService.queryAllData('/ActivityTypes');

    if (data.result !== this.configService.successStatus) {
      throw Error('error');
    }

    if (!data.results || !data.results.length) {
      return;
    }
    this.activityTypes.push({
      label: "All",
      value: null
    })
    _.forEach(data.results, item => {
      this.activityTypes.push(
        { label: item.Description, value: item.Value }
      );
    })
  }

  chooseType() {
    this.subTimelineClientsData = this.rootData;
    let types;
    if (this.filterData.type.type === 'Notes') {
      types = ['Notes'];
    } else {
      types = _.map(this.activityTypes, ('label'));
      if (!this.filterData.type.type) {
        types.push("Notes");
      }
    }
    let dataFilter = {
      types: types,
      allocatedTo: this.filterData.allocatedTo ? this.filterData.allocatedTo.Name : null,
      subject: this.filterData.subject ? this.filterData.subject.toLowerCase() : '',
      activityType: this.filterData.activityType ? this.filterData.activityType.value : null,
      dueDate: this.filterData.dueDate ? moment(this.filterData.dueDate).format('MM-DD-YYYY') : null,
      createdTime: this.filterData.createdDate ? moment(this.filterData.createdDate).format('MM-DD-YYYY') : null,
      dateFrom: this.filterData.dateFrom ? moment(this.filterData.dateFrom).format('MM-DD-YYYY') : null,
      dateTo: this.filterData.dateTo ? (moment(this.filterData.dateTo).format('MM-DD-YYYY') + ' 23:59:59') : null
    }
    
    this.subTimelineClientsData = _.filter(this.rootData, (item: any) => {
      return (dataFilter.types.indexOf(item.type) > -1)
        && (!dataFilter.allocatedTo || item.allocatedTo == dataFilter.allocatedTo)
        && (!dataFilter.activityType || item.type.toLowerCase() == dataFilter.activityType.toLowerCase())
        && (!dataFilter.dueDate || item.dueDate >= moment.utc(dataFilter.dueDate))
        && (!dataFilter.subject || (item.subject && item.subject.toLowerCase().indexOf(dataFilter.subject) > -1))
        && (!dataFilter.createdTime || item.createdTime >= moment.utc(dataFilter.createdTime))
        && (!dataFilter.dateFrom || item.modifiedTime >= moment.utc(dataFilter.dateFrom))
        && (!dataFilter.dateTo || item.modifiedTime <= moment.utc(dataFilter.dateTo));
    });
  }

  applyReset() {
    this.filterData = {};
    this.filterData.type = this.filterType[0];
    this.filterData.activityType = this.filterActivityType[0];
    this.subTimelineClientsData = this.rootData;
  }
  //#endregion
  //#region add/edit
  showAddOrEditTimelineModal() {
    this.addOrEditTimelineModal.initParams(this.clientId, null, null, this.contactId, this.siteId, this.employeeId);
    this.addOrEditTimelineModal.show();
  }

  showAddNotesModal() {
    this.addNotesModal.initParams(this.clientId, null, this.contactId, this.siteId, this.employeeId);
    this.addNotesModal.show();
  }
  showDetail(event) {
    if (event.data.type === 'Notes') {
      this.addNotesModal.initParams(this.clientId, event.data.objectId, this.contactId, this.siteId, this.employeeId);
      this.addNotesModal.show();
    } else {
      this.addOrEditTimelineModal.initParams(this.clientId, null, event.data.objectId, this.contactId, this.siteId, this.employeeId);
      this.addOrEditTimelineModal.show();
    }
  }
  saveTimelineSuccessed(event) {
    if (event) {
      this.subTimelineClientsData = _.filter(this.subTimelineClientsData, item => {
        return item.type === 'Notes';
      })
      this.getTasks();
    }
  }

  saveNoteSuccessed(event) {
    if (event) {
      this.subTimelineClientsData = _.filter(this.subTimelineClientsData, item => {
        return item.type !== 'Notes';
      })
      this.getNotes();
    }
  }
  //#endregion
}