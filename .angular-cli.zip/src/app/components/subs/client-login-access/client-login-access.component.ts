import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-login-access',
  templateUrl: './client-login-access.component.html',
  styleUrls: ['./client-login-access.component.scss']
})
export class ClientLoginAccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
