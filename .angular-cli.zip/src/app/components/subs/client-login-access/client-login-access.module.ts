import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components
import { ClientLoginAccessComponent } from './client-login-access.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ClientLoginAccessComponent
  ],
  bootstrap: [
    ClientLoginAccessComponent
  ],
  exports: [
    ClientLoginAccessComponent
  ]
})
export class ClientLoginAccessModule { }
