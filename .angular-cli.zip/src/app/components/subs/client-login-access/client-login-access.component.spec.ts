import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientLoginAccessComponent } from './client-login-access.component';

describe('ClientLoginAccessComponent', () => {
  let component: ClientLoginAccessComponent;
  let fixture: ComponentFixture<ClientLoginAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientLoginAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientLoginAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
