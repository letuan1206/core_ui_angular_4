import { Component, OnInit, Input } from '@angular/core';
import get = require('lodash/get');

// Services
import { HelperService } from '../../../services/helper.service';
import { ConfigService } from '../../../services/config.service';
import { CommonService } from '../../../services/common.service';

// Redux
import { NgRedux, select } from 'ng2-redux';
import { STORE_SUB_CONTACTS_CLIENTS } from '../../common/common-actions';

// Services
import { EmailsService } from './emails.service';

@Component({
  selector: 'app-emails',
  templateUrl: './emails.component.html',
  styleUrls: ['./emails.component.scss']
})
export class EmailsComponent implements OnInit {

  @Input() type: string;
  @Input() objectId: string;

  subEmailClientsData: any;
  
  // Redux store
  @select(s => s.common.subContactsClients) subContactsClients;
  
  constructor(
    private emailsService: EmailsService,
    private helperService: HelperService,
    private configService: ConfigService,
    private commonService: CommonService
  ) { 

  }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.getEmails('/Emails', 'ID:215606');
        break;
      }
      case this.configService.get('menuType')['sites']: {
        
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        
        break;
      }
      default: {
        break;
      }
    }
  }

  async getEmails(url, objectId) {
    
    try {

      let dataContacts = await this.commonService.queryById(url, objectId);

      if (dataContacts.result === this.configService.successStatus) {

        // let result = get(dataContacts.references, objectId);

        // switch (this.type) {
        //   case this.configService.get('menuType')['clients']: {
        //     let arr = [];
        //     arr.push({
        //       name: result.ContactStatus.Name !== null ? result.ContactStatus.Name : '',
        //       position: result.Position !== null ? await this.getPositionDescription(result.Position) : '',
        //       phone: result.Phone !== null ? result.Phone : '',
        //       fax: result.Fax !== null ? result.Fax : '',
        //       mobile: result.Mobile !== null ? result.Mobile : '',
        //       email: result.Email !== null ? result.Email : '',
        //       status: result.Active ? 'Active' : 'Inactive'
        //     });
        //     this.helperService.dispatchToRedux(STORE_SUB_CONTACTS_CLIENTS, arr);
        //     break;
        //   }
        //   case this.configService.get('menuType')['sites']: {
            
        //     break;
        //   }
        //   case this.configService.get('menuType')['contacts']: {
            
        //     break;
        //   }
        //   default: {
        //     break;
        //   }
        // }

      } else {
        throw Error('error');
      }

    } catch (e) {
      this.helperService.handleError(e);
    }

  }

  async getPositionDescription(objectId) {
    let data = await this.helperService.getPositionDetailById(objectId);
    return data.Description !== null ? data.Description : '';
  }

}
