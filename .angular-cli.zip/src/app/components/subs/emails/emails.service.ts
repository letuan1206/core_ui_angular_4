import { Injectable } from '@angular/core';

// Services
import { ApiService } from '../../../services/api.service';
import { ConfigService } from '../../../services/config.service';
import { ISubscription } from "rxjs/Subscription";

// Interfaces
import { Params } from '../../../interfaces/common-interface';

@Injectable()
export class EmailsService {

  constructor(
    private apiService: ApiService,
    private configService: ConfigService
  ) { 

  }

  // getEmail(objectId): Promise<any> {
  //   return new Promise((resolve, reject) => {
  //     let params: Params = {
  //       environment: this.configService.get('environment'),
  //       queryType: 'All',
  //       queryParams: {
  //         "Client": objectId
  //       }
  //     };
  //     this.getContactsOfClientsSub = this.apiService.post(`/Contact`, params).subscribe(res => { 
  //       resolve(res); 
  //     }, err => {
  //       reject(err);
  //     });
  //   });
  // }

}
