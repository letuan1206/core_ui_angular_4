import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';

// Components
import { EmailsComponent } from './emails.component';

// Services
import { EmailsService } from './emails.service';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule
  ],
  declarations: [
    EmailsComponent
  ],
  bootstrap: [
    EmailsComponent
  ],
  exports: [
    EmailsComponent
  ],
  providers: [
    EmailsService
  ]
})
export class EmailsModule { }
