import { SitesService } from './../../sites/sites.service';
import { Contact } from './../../../models/configuration';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfigService } from './../../../services/config.service';
import { ClientsService } from './../../clients/clients.service';
import { ConfigurationService } from './../../configuration/configuration.service';
import { ContactService } from './../../contact/contact.service';
import { HelperService } from './../../../services/helper.service';
import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import * as _ from 'lodash';

@Component({
  selector: 'app-sites',
  templateUrl: './sites.component.html',
  styleUrls: ['./sites.component.scss']
})
export class SitesComponent implements OnInit, AfterViewInit {

  @Input() type: string;
  @Input() objectId: string;
  sitesData: any;

  constructor(
    private helperService: HelperService,
    private contactService: ContactService,
    private configuarationService: ConfigurationService,
    private clientService: ClientsService,
    private configService: ConfigService,
    private siteService: SitesService,
    private ngRedux: NgRedux<any>,
    private router: Router,
    private _activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['contacts']: {
        this.getAllSiteByContacts();
        break;
      }
      case this.configService.get('menuType')['clients']: {
        this.getAllSiteByClients();
        break;
      }
      default: {
        break;
      }
    }
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  addNewSite() {
    this.router.navigate(['/sites/add'], { queryParams: { clientId: this.objectId } });
  }

  handleRowClick(event) {
    this.router.navigate(['/sites/detail/', event.data.ObjectID]);
  }

  getAllSiteByContacts() {
    let sites = [];
    this.siteService.getAllSites({}).then(res => {
      res.results.forEach(element => {
        let site = _.get(res.references, element);
        if (site.Contacts) {
          if (site.Contacts.indexOf(this.objectId) !== -1) {
            site.InformationDetail = _.get(res.references, site.Information);
            site.Address = _.get(res.references, site.InformationDetail.Address);
            site.GoogleAddress = _.get(res.references, site.Address.GoogleAddress);
            site.Division = _.get(res.references, site.InformationDetail.Division);
            site.State = _.get(res.references, site.InformationDetail.State);
            sites.push(site);
          }
        }
      });

      this.sitesData = sites;
    });
  }

  getAllSiteByClients() {
    let sites = [];
    this.siteService.getAllSites({}).then(res => {
      res.results.forEach(element => {
        let site = _.get(res.references, element);
        if (site.Client && site.Client === this.objectId) {
          site.InformationDetail = _.get(res.references, site.Information);
          site.Address = _.get(res.references, site.InformationDetail.Address);
          site.GoogleAddress = _.get(res.references, site.Address.GoogleAddress);
          site.Division = _.get(res.references, site.InformationDetail.Division);
          site.State = _.get(res.references, site.InformationDetail.State);
          sites.push(site);
        }
      });

      this.sitesData = sites;
    });
  }

}
