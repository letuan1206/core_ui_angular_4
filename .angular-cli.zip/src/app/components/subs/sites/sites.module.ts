import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';
// Components
import { SitesComponent } from './sites.component';

@NgModule({
  imports: [
    CommonModule,
    DataTableModule
  ],
  declarations: [
    SitesComponent
  ],
  bootstrap: [
    SitesComponent
  ],
  exports: [
    SitesComponent
  ]
})
export class SitesSubModule { }
