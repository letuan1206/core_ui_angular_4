export const textMask: any = {
    maskTaxFileNumber: [/[0-9]/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/, /\d/],
    maskPhoneNumber: [/[0-9]/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/],
    maskFaxNumber: [/[0-9]/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/],
    maskBSBNumber: [/[0-9]/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/],
    maskAccountNumber: [/[0-9]/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/],
    maskFundABN: [/[0-9]/, /\d/, ' ', /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/],
    maskTimeFormat: [/[0-2]/, /\d/, ':', /[0-5]/, /\d/],
    maskOnlyNumber: [/[1-9]/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/],
};

export const textMaskUserInformation: any = {
    maskMobileNumber: [/[0-9]/, /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/, ' ', /\d/, /\d/, /\d/],
};

export const themeColorActions: any = {
    MENU_BAR: 1,
    MENU_TEXT: 2,
    HEADING_BAR: 3,
    HEADING_TEXT: 4
}

export const LOCALSTORE_KEY: any = {
    THEME_SETTING: 'THEME_SETTING',
    COUNTRY_ID: 'COUNTRY_ID'
}

export const PRIVILEGES: any = {
    previewArticle: "previewArticle",
    prosekSecurityOfficerPriv: "Prosek_Security_Officer_Priv",
    securityEditUserDetails: "securityEditUserDetails",
    createArticle: "createArticle",
    viewArticle: "viewArticle",
    editDBenums: "edit_DBenums",
    admin: "admin",
    editArticle: "editArticle",
    editContent: "editContent",
    prosekPatrolOfficerPriv: "Prosek_Patrol_OfficerPriv",
    securityGrantAll: "securityGrantAll"
}

export const ROSTERING_SELECT_TYPE: any = {
    DAY: 0,
    WEEK: 1,
    MONTH: 2
}

export const ROSTER_TEMPLATE_TYPE: any = {
    AD_HOC_SHIFT: 'AD_HOC_SHIFT',
    PERMANENT_SHIFT: 'PERMANENT_SHIFT',
    ADD_SHIFT: 'Add Shift',
    EDIT_SHIFT: 'Edit Shift',
    ADD_TEMPLATE: 'Add Template',
}

export const GEOLOCATION_TYPE: any = {
    ZIP_CODE: "postal_code",
    STREET_NUMBER: "street_number",
    STREET_ADDRESS: "route",
    CITY: "locality",
    COUNTRY: "country",
    STATE: "administrative_area_level_1"
}