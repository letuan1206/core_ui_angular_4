import { FormGroup } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'app-time-picker',
  templateUrl: './time-picker.component.html',
  styleUrls: ['./time-picker.component.scss']
})
export class TimePickerComponent implements OnInit {
  @Input() typeInput = 'formGroup';
  @Input() groupForm: FormGroup;
  @Input() formCtrlName: string;
  @Input() timeValue: string;

  @Input() step = 30;
  @Output('checkedChange') change = new EventEmitter<any>();

  optionArr = [];

  constructor() { }

  ngOnInit() {
    this.initSelectOption();
  }

  initSelectOption() {
    let startArr = moment().format('YYYY-MM-DD 00:00');
    let numbStep = 1440 / this.step;
    this.optionArr = [];
    for (let i = 0; i < numbStep; i++) {
      this.optionArr.push(moment(startArr).format('HH:mm'));
      startArr = moment(startArr).add(this.step, 'minutes').format('YYYY-MM-DD HH:mm');
    }
    this.optionArr = _.uniq(this.optionArr);
  }

  emitChangeValue() {
    this.change.emit();
  }

  onChangeParent() {
    this.change.emit(this.timeValue);
  }

  removeValue(typeOption) {
    if (typeOption === 'model') {
      this.timeValue = null;
      this.onChangeParent();
    } else {
      this.groupForm.controls[this.formCtrlName].setValue(null);
      this.emitChangeValue();
    }
  }
}
