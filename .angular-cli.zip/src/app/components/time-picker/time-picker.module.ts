import { TimePickerComponent } from './time-picker.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    TimePickerComponent
  ],
  exports: [
    TimePickerComponent
  ]
})
export class TimePickerModule { }
