import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DropdownModule } from 'primeng/dropdown';
import { CalendarModule } from 'primeng/calendar';
import { AutoCompleteModule } from 'primeng/autocomplete';
// Components
import { FilterComponent } from './filter.component';

@NgModule({
  imports: [
    CommonModule,
    DropdownModule,
    FormsModule,
    CalendarModule,
    AutoCompleteModule
  ],
  declarations: [
    FilterComponent
  ],
  bootstrap: [
    FilterComponent
  ],
  exports: [
    FilterComponent
  ]
})
export class FilterModule { }
