import { ContactService } from './../contact/contact.service';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import filter = require('lodash/filter');

// Services
import { ConfigService } from '../../services/config.service';
import { HelperService } from '../../services/helper.service';
import { ClientsService } from '../clients/clients.service';
import { SitesService } from '../sites/sites.service';

// Interfaces
import { QueryParams } from '../../interfaces/filter-interface';
import { ClientsParam, DataOfTableClient } from '../../interfaces/clients-interface';
import { SitesParam, DataOfTableSite } from '../../interfaces/sites-interface';
import { StatusOptions, ServiceOptions, StateOptions, DivisionOptions, PositionOptions } from '../../interfaces/common-interface';
import { DashboardService } from '../dashboard/dashboard.service';
import * as _ from 'lodash';
import { EmployeesService } from '../employees/employees.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  @Input() type: string;

  stateChoose: any = null;
  divisionChoose: any = null;
  serviceChoose: any = null;
  positionChoose: any = null;
  statusChoose: any = null;
  typeChoose: any = null;
  reportStatusesChoose: any = null;
  categoryChoose: StatusOptions = null;
  siteChoose: StatusOptions = null;
  searchChoose: any = null;
  searchFrom: any = null;
  searchTo: any = null;

  filterStateData: any;
  filterStatusData: any;
  filterTypeData: any = [];
  filterRepostStatusesData: any = [];
  filterCategoryData: any = [];
  filterSiteData: any = [];
  autoCompletedSite: StatusOptions[] = [];
  autoCompletedCategory: StatusOptions[] = [];
  filterServiceData: any;
  filterDivisionData: any;
  filterPositionData: any;
  getClientsData: any;
  getSitesData: any;
  getEmployeesData: any;

  searchVisible: boolean = true;
  stateVisible: boolean = true;
  divisionVisible: boolean = true;
  serviceVisible: boolean = true;
  positionVisible: boolean = true;
  statusVisible: boolean = true;
  typeVisible: boolean = false;
  reportStatusesVisible: boolean = false;
  siteVisible: boolean = false;
  categoryVisible: boolean = false;
  fromVisible: boolean = false;
  toVisible: boolean = false;

  statusOptions: StatusOptions[] = [
    {
      Description: "Active Only",
      Value: "ACTIVE"
    },
    {
      Description: "Include Inactive",
      Value: "INACTIVE"
    }
  ];
  serviceOptions: ServiceOptions[] = [
    {
      Active: null,
      Description: 'Choose Service',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  stateOptions: StateOptions[] = [
    {
      Active: null,
      Country: null,
      Name: 'Choose State',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];
  divisionOptions: DivisionOptions[] = [
    {
      Active: null,
      Description: 'Choose Division',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      State: null
    }
  ];

  positionsOptions: PositionOptions[] = [
    {
      Active: null,
      Description: 'Choose Division',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
    }
  ];

  queryClientParams: ClientsParam = {
    ActiveStatus: null,
    Service: null,
    Division: null,
    Rating: null,
    State: null
  }

  // Redux store
  @select(s => s.common.filterState) filterState;
  @select(s => s.common.filterStatus) filterStatus;
  @select(s => s.common.filterType) filterType;
  @select(s => s.common.filterReportStatuses) filterRepostStatuses;
  @select(s => s.common.filterSite) filterSite;
  @select(s => s.common.filterCategory) filterCategory;
  @select(s => s.common.filterService) filterService;
  @select(s => s.common.filterDivision) filterDivision;
  @select(s => s.common.filterPosition) filterPosition;
  @select(s => s.common.clientsData) clientsData;
  @select(s => s.common.sitesData) sitesData;
  @select(s => s.common.employeesData) employeesData;

  constructor(
    public configService: ConfigService,
    public helperService: HelperService,
    public clientsService: ClientsService,
    public sitesService: SitesService,
    private contactService: ContactService,
    private employeesService: EmployeesService,
    private ngRedux: NgRedux<any>,
    private dashboardService: DashboardService,
  ) {
    this.filterState.subscribe(data => {
      this.filterStateData = data;
    });

    this.filterStatus.subscribe(data => {
      this.filterStatusData = data;
      this.statusChoose = this.filterStatusData[0];
    });

    this.filterService.subscribe(data => {
      this.filterServiceData = data;
    });

    this.filterDivision.subscribe(data => {
      this.filterDivisionData = data;
    });

    this.filterPosition.subscribe(data => {
      this.filterPositionData = data;
    });

    this.filterType.subscribe(data => {
      this.filterTypeData = data;
    });

    this.filterRepostStatuses.subscribe(data => {
      this.filterRepostStatusesData = data;
    });

    this.clientsData.subscribe(data => {
      this.getClientsData = data;
    });

    this.sitesData.subscribe(data => {
      this.getSitesData = data;
    });

    this.employeesData.subscribe(data => {
      this.getEmployeesData = data;
    });
    this.filterSite.subscribe(data => {
      this.filterSiteData = data;
    });

    this.filterCategory.subscribe(data => {
      this.filterCategoryData = data;
    });
  }

  ngOnInit() {
    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.positionVisible = false;
        break;
      }
      case this.configService.get('menuType')['sites']: {
        this.positionVisible = false;
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        this.stateVisible = true;
        this.serviceVisible = false;
        this.positionVisible = true;
        break;
      }
      case this.configService.get('menuType')['employees']: {
        this.searchVisible = true;
        this.stateVisible = true;
        this.serviceVisible = false;
        this.positionVisible = true;
        this.divisionVisible = true;
        this.statusVisible = false;
        this.typeVisible = false;
        this.categoryVisible = false;
        this.siteVisible = false;
        this.reportStatusesVisible = false;
        this.fromVisible = false;
        this.toVisible = false;
        break;
      }
      case this.configService.get('menuType')['report']: {
        this.stateVisible = false;
        this.serviceVisible = false;
        this.positionVisible = false;
        this.divisionVisible = false;
        this.statusVisible = false;
        this.typeVisible = true;
        this.categoryVisible = true;
        this.siteVisible = true;
        this.reportStatusesVisible = true;
        this.fromVisible = true;
        this.toVisible = true;
        break;
      }
      default: {
        break;
      }
    }
  }

  async autoCompleteSite(event) {
    try {
      this.autoCompletedSite = [];
      _.find(this.filterSiteData, s => {
        if (s.Description.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
          this.autoCompletedSite.push(s);
        }
      });
    } catch (e) {
      console.log(e);
    }
  }

  textSiteEmpty() {
    this.siteChoose.Description = "";
    this.siteChoose.Value = "";
  }

  textCategoryEmpty() {
    this.categoryChoose.Description = "";
    this.categoryChoose.Value = "";
  }

  async autoCompleteCategory(event) {
    try {
      this.autoCompletedCategory = [];
      _.find(this.filterCategoryData, s => {
        if (s.Description.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
          this.autoCompletedCategory.push(s);
        }
      });
    } catch (e) {
      console.log(e);
    }
  }

  applyFilter() {
    let queryParam = this.createQueryParams();

    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        queryParam.Details = this.searchChoose !== null ? this.searchChoose : null;
        queryParam.State = this.stateChoose !== null ? this.stateChoose.ObjectID : null;
        queryParam.Division = this.divisionChoose !== null ? this.divisionChoose.ObjectID : null;
        queryParam.Service = this.serviceChoose !== null ? this.serviceChoose.ObjectID : null;
        queryParam.ActiveStatus = this.statusChoose !== null ? this.statusChoose.Value : null;

        this.clientsService.loadDataClients(this.configService.get('menuType')['clients'], this.helperService.convertQueryParams(queryParam), this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
        break;
      }
      case this.configService.get('menuType')['sites']: {
        queryParam.Details = this.searchChoose !== null ? this.searchChoose : null;
        queryParam.State = this.stateChoose !== null ? this.stateChoose.ObjectID : null;
        queryParam.Division = this.divisionChoose !== null ? this.divisionChoose.ObjectID : null;
        queryParam.Service = this.serviceChoose !== null ? this.serviceChoose.ObjectID : null;
        this.sitesService.loadDataSites(this.configService.get('menuType')['sites'], this.helperService.convertQueryParams(queryParam), this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        queryParam.Details = this.searchChoose ? this.searchChoose : null;
        queryParam.State = this.stateChoose ? this.stateChoose.ObjectID : null;
        queryParam.Division = this.divisionChoose ? this.divisionChoose.ObjectID : null;
        queryParam.Position = this.positionChoose ? this.positionChoose.ObjectID : null;
        queryParam.ActiveStatus = this.statusChoose ? this.statusChoose.Value : null;

        this.contactService.loadDataContact(this.helperService.convertQueryParams(queryParam), false);
        break;
      }
      case this.configService.get('menuType')['employees']: {
        queryParam.Details = this.searchChoose ? this.searchChoose : null;
        queryParam.State = this.stateChoose ? this.stateChoose.ObjectID : null;
        queryParam.Division = this.divisionChoose ? this.divisionChoose.ObjectID : null;
        queryParam.Position = this.positionChoose ? this.positionChoose.ObjectID : null;

        this.employeesService.loadDataEmployees(this.configService.get('menuType')['employees'], this.helperService.convertQueryParams(queryParam), this.positionsOptions, this.stateOptions, this.divisionOptions);
      }
      case this.configService.get('menuType')['report']: {
        queryParam.Details = this.searchChoose ? this.searchChoose : null;
        queryParam.Site = this.siteChoose ? this.siteChoose.Value : null;
        queryParam.Category = this.categoryChoose ? this.categoryChoose.Value : null;
        queryParam.Type = this.typeChoose ? this.typeChoose.ObjectID : null;
        queryParam.ReportStatus = this.reportStatusesChoose ? this.reportStatusesChoose.Name : null;
        queryParam.From = this.searchFrom ? this.searchFrom : null;
        queryParam.To = this.searchTo ? this.searchTo : null;
        this.dashboardService.loadReport(this.helperService.convertQueryParams(queryParam));
        break;
      }
      default: {
        break;
      }
    }
  }

  createQueryParams(): QueryParams {
    let params: QueryParams = {
      Details: null,
      ActiveStatus: null,
      NoService: null,
      NoIndustry: null,
      NoRating: null,
      NoPosition: null,
      Service: null,
      Division: null,
      Rating: null,
      Industry: null,
      State: null,
      Position: null,
      Site: null,
      Category: null,
      From: null,
      To: null,
      Type: null,
      ReportStatus: null
    }

    return params;
  }

  applyReset() {
    let queryParam = this.createQueryParams();

    switch (this.type) {
      case this.configService.get('menuType')['clients']: {
        this.clientsService.loadDataClients(this.configService.get('menuType')['clients'], this.helperService.convertQueryParams(queryParam), this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
        this.searchChoose = null;
        this.stateChoose = this.filterStateData[0];
        this.divisionChoose = this.filterDivisionData[0];
        this.serviceChoose = this.filterServiceData[0];
        this.statusChoose = this.filterStatusData[0];
        break;
      }
      case this.configService.get('menuType')['sites']: {
        this.sitesService.loadDataSites(this.configService.get('menuType')['sites'], this.helperService.convertQueryParams(queryParam), this.stateOptions, this.serviceOptions, this.divisionOptions, this.statusOptions);
        this.searchChoose = null;
        this.stateChoose = this.filterStateData[0];
        this.divisionChoose = this.filterDivisionData[0];
        this.serviceChoose = this.filterServiceData[0];
        this.statusChoose = this.filterStatusData[0];
        break;
      }
      case this.configService.get('menuType')['contacts']: {
        this.contactService.loadDataContact(this.helperService.convertQueryParams(queryParam), false);
        this.searchChoose = null;
        this.stateChoose = this.filterStateData[0];
        this.divisionChoose = this.filterDivisionData[0];
        this.positionChoose = this.filterPositionData[0];
        this.statusChoose = this.filterStatusData[0];
        break;
      }
      case this.configService.get('menuType')['employees']: {
        this.searchChoose = null;
        this.stateChoose = this.filterStateData[0];
        this.divisionChoose = this.filterDivisionData[0];
        this.positionChoose = this.filterPositionData[0];
        this.employeesService.loadDataEmployees(this.configService.get('menuType')['employees'], this.helperService.convertQueryParams(queryParam), this.positionsOptions, this.stateOptions, this.divisionOptions);
      }
      case this.configService.get('menuType')['report']: {
        this.dashboardService.loadReport(this.helperService.convertQueryParams(queryParam));
        this.searchChoose = null;
        this.siteChoose = null;
        this.categoryChoose = null;
        this.typeChoose = null;
        this.reportStatusesChoose = null;
        this.searchFrom = null;
        this.searchTo = null;
        break;
      }
      default: {
        break;
      }
    }
  }

  onKey(event) {
    if (event.keyCode == 13) {
      // Enter Key
      this.applyFilter();
    }
  }

}
