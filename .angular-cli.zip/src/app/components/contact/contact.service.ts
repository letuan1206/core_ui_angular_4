import { STORE_CONTACTS_DATA, STORE_FILTER_DIVISION, STORE_FILTER_POSITION, STORE_FILTER_STATE, STORE_FILTER_STATUS } from './../common/common-actions';
import { ClientsService } from './../clients/clients.service';
import { Contact } from './../../models/configuration';
import { HelperService } from './../../services/helper.service';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';
import { FormBuilder, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { NgRedux } from 'ng2-redux';
import { Params } from '../../interfaces/common-interface';
import * as _ from 'lodash';
import { GEOLOCATION_TYPE } from '../common/constants';

@Injectable()
export class ContactService {

  constructor(
    private http: Http,
    private fb: FormBuilder,
    public configService: ConfigService,
    private api: ApiService,
    private helperService: HelperService,
    private clientService: ClientsService,
    private ngRedux: NgRedux<any>
  ) { }

  renderFormContactDetail(contact: Contact) {
    return this.fb.group({
      FirstName: [contact.FirstName, [Validators.required]],
      LastName: [contact.LastName, [Validators.required]],
      Position: [contact.Position],
      CompanyName: [contact.CompanyDetail],
      Phone: [contact.Phone],
      Fax: [contact.Fax],
      Mobile: [contact.Mobile],
      Email: [contact.Email, [Validators.email]],
      EmailOther: [contact.EmailOther, [Validators.email]],
      Address: [contact.GoogleAddress ? contact.GoogleAddress.GoogleAddressText : null],
      ContactStatus: [contact.ContactStatus ? contact.ContactStatus.Value : null],
      ClientManager: [contact.ClientManager],
      Services: [contact.ContactServices],
      Rating: [contact.Rating],
      State: [contact.State],
      Division: [contact.Division],
      Industry: [contact.Industry],
      PostalAddress: [contact.PostalAddressDetail ? contact.PostalAddressDetail.Street : null]
    });
  }

  filterClientManager(query, data: any[]): any[] {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    for (let i = 0; i < data.length; i++) {
      let item = data[i];
      if (item.UserName.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    return filtered;
  }

  filterSitesSingle(query, data: any[]): any[] {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    for (let i = 0; i < data.length; i++) {
      let item = data[i];
      if (item.SiteName.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    return filtered;
  }

  filterServicesMulti(query, data: any[]): any[] {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    for (let i = 0; i < data.length; i++) {
      let item = data[i];
      if (item.Description.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    return filtered;
  }

  filterContactSingle(query, data: any[]): any[] {
    //in a real application, make a request to a remote url with the query and return filtered results, for demo we filter at client side
    let filtered: any[] = [];
    for (let i = 0; i < data.length; i++) {
      let item = data[i];
      item.fullName = item.FirstName + ' ' + item.LastName;

      if (item.fullName.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    return filtered;
  }

  getBannedPeriods(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.api.post(`/BannedPeriods`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getReminderTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.api.post(`/ReminderTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getNotificationTypes(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.api.post(`/NotificationTypes`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getActiveStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All'
      }

      this.api.post(`/ActiveStatuses`, params)
        .subscribe(res => {
          this.helperService.dispatchToRedux(STORE_FILTER_STATUS, res.results);
          resolve(res);
        }, reject);
    });
  }

  getContacts(data): Promise<any> {
    return new Promise((resolve, reject) => {
      const params = {
        queryType: 'All',
        queryParams: data,
        assocs: ['Position', 'Division', 'State']
      }

      this.api.post(`/Contact`, params)
        .subscribe(res => {
          resolve(res);
        }, reject);
    });
  }

  getContactStatuses(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
      };
      this.api.post(`/ContactStatuses`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getClientManager(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
      };
      this.api.post(`/Users`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getContactCompanyNames(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        assocs: [
          'Site.Client',
          'Site'
        ]
      };
      this.api.post(`/ContactCompanyNames`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getContactById(id): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: id
        },
        assocs: ['Position', 'Division', 'State', 'Address', 'PostalAddress', 'Address.GoogleAddress', 'TransCompanyName', 'Services', 'Services.Service', 'TransCompanyName']
      };
      this.api.post(`/Contact`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  downnloadPDF(bannedId) {
    let params = {
      queryType: 'ByID',
      queryParams: {
        id: bannedId
      },
      generateDocument: "BannedEmployeePDF"
    };
    return new Promise((resolve, reject) => {
      this.api.post(`/BannedEmployees`, params, 'blob').subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getReferencesData(res) {
    let result = [];
    res.results.forEach(element => {
      result.push(_.get(res.references, element));
    });

    return result;
  }



  loadDataContact(queryParams, loadData = false) {
    this.helperService.showLoading();
    if (loadData) {
      this.getActiveStatuses();
    }

    this.getContacts(queryParams).then(res => {

      if (loadData) {
        let stateOptions = _.filter(res.references, s => s.ObjectClass === 'prosek.orm.CountryState');
        let divisionOptions = _.filter(res.references, s => s.ObjectClass === 'prosek.orm.types.Division');
        let positionOptions = _.filter(res.references, s => s.ObjectClass === 'prosek.orm.types.Position');

        let state = {
          Active: null,
          Country: null,
          Name: 'Choose State',
          ObjectClass: null,
          ObjectCreated: null,
          ObjectID: null,
          ObjectLastModified: null
        }

        let division = {
          Active: null,
          Description: 'Choose Division',
          ObjectClass: null,
          ObjectCreated: null,
          ObjectID: null,
          ObjectLastModified: null,
          State: null
        }

        let position = {
          Active: null,
          Description: 'Choose Position',
          ObjectClass: null,
          ObjectCreated: null,
          ObjectID: null,
          ObjectLastModified: null,
          State: null
        }

        stateOptions.unshift(state);
        divisionOptions.unshift(division);
        positionOptions.unshift(position);

        this.helperService.dispatchToRedux(STORE_FILTER_STATE, stateOptions);
        this.helperService.dispatchToRedux(STORE_FILTER_DIVISION, divisionOptions);
        this.helperService.dispatchToRedux(STORE_FILTER_POSITION, positionOptions);
      }

      let contactArr = [];
      res.results.forEach(element => {
        let contactDetail: Contact;
        contactDetail = _.get(res.references, element);
        contactDetail.FullName = contactDetail.FirstName + ' ' + contactDetail.LastName;
        contactDetail.PositionDetails = _.get(res.references, contactDetail.Position);
        contactDetail.ActiveString = 'Active';
        if (!contactDetail.Active) {
          contactDetail.ActiveString = 'Deactive';
        }
        contactArr.push(contactDetail);
      });

      this.helperService.dispatchToRedux(STORE_CONTACTS_DATA, contactArr);
      this.helperService.hideLoading();
    }).catch(e => {
      console.error(e);
    });
  }

  getAddressDetail(addressComponent) {
    return {
      Country: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.COUNTRY) !== -1) {
          return s;
        }
      }),
      ZipCode: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.ZIP_CODE) !== -1) {
          return s;
        }
      }),
      City: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.CITY) !== -1) {
          return s;
        }
      }),
      StreetNumber: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_NUMBER) !== -1) {
          return s;
        }
      }),
      StreetAddress: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_ADDRESS) !== -1) {
          return s;
        }
      }),
      State: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STATE) !== -1) {
          return s;
        }
      })
    }
  }

  changeStatusButton(btnEdit = false, btnAdd = false, btnSaveEdit = false, btnClear = false) {
    return {
      btnEdit: btnEdit,
      btnAdd: btnAdd,
      btnSaveEdit: btnSaveEdit,
      btnClear: btnClear,
    }
  }

  getBannedEmployees(queryParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params = {
        queryType: 'All',
        queryParams: queryParams,
        assocs: ['BannedEmployee', 'BannedBy', 'Site', 'Contact', 'ActionedBy'],
      };
      this.api.post(`/BannedEmployees`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }
}
