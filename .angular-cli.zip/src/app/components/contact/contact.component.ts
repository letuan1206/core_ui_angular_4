import { DivisionOptions, StateOptions, ServiceOptions } from './../../interfaces/common-interface';
import { ConfigService } from './../../services/config.service';
import { ClientsService } from './../clients/clients.service';
import { ConfigurationService } from './../configuration/configuration.service';
import {
  STORE_FILTER_STATE,
  STORE_FILTER_DIVISION,
  STORE_FILTER_POSITION,
  STORE_CONTACTS_DATA
} from './../common/common-actions';
import { Contact } from './../../models/configuration';
import { ContactService } from './contact.service';
import { Router, ActivatedRoute } from '@angular/router';
import { HelperService } from './../../services/helper.service';
import { Component, OnInit, AfterViewInit } from '@angular/core';
import { NgRedux, select } from 'ng2-redux';
import * as _ from 'lodash';
declare var $: any;

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit, AfterViewInit {

  stateOptions = [];
  divisionOptions = [];
  positionOptions = [];
  contacts = [];
  typeFilter: string;

  @select(s => s.common.contactsData) contactsData;

  constructor(
    private helperService: HelperService,
    private contactService: ContactService,
    private configuarationService: ConfigurationService,
    private clientService: ClientsService,
    private configService: ConfigService,
    private ngRedux: NgRedux<any>,
    private router: Router,
    private _activatedRoute: ActivatedRoute
  ) {
    this.contactsData.subscribe(data => {
      this.contacts = data;
    });
  }

  ngOnInit() {
    this.typeFilter = this.configService.get('menuType')['contacts'];
    this.contactService.loadDataContact({}, true);
    window.scrollTo(0, 0);
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  handleRowClick(event) {
    this.router.navigate(['/contact', event.data.ObjectID]);
  }


}
