import { BannedEmployeesModule } from './../subs/banned-employees/banned-employees.module';
import { AttachmentsModule } from './../subs/attachments/attachments.module';
import { SitesSubModule } from './../subs/sites/sites.module';
import { SitesComponent } from './../subs/sites/sites.component';
import { FilterModule } from './../filter/filter.module';
import { Routes, RouterModule } from '@angular/router';
import { ContactService } from './contact.service';
import { ContactComponent } from './contact.component';
import { ContactDetailComponent } from './contact-detail/contact-detail.component';
import { ModalModule } from 'ngx-bootstrap';
import { MomentModule } from 'angular2-moment';
import { ShContextMenuModule } from 'ng2-right-click-menu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './../../app.routing';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTableModule } from 'primeng/datatable';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { Ng4GeoautocompleteModule } from 'ng4-gmap-autocomplete';
import { AddOrEditTimelineModule } from '../subs/modals/add-or-edit-timeline/add-or-edit-timeline.module';
import { AddNoteModalComponent } from '../subs/modals/add-note-modal/add-note-modal.component';
import { AddNoteModalModule } from '../subs/modals/add-note-modal/add-note-modal.module';
import { ContactFocusInputDirective } from './contact.focus.input.directive'
import { TimelineModule } from '../subs/timeline/timeline.module';
const routing: Routes = [
  { path: '', component: ContactComponent }
];

const Routing: ModuleWithProviders = RouterModule.forChild(routing);

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    MultiselectDropdownModule,
    DateTimePickerModule,
    BrowserAnimationsModule,
    ShContextMenuModule,
    MomentModule,
    DataTableModule,
    AutoCompleteModule,
    SitesSubModule,
    AttachmentsModule,
    BannedEmployeesModule,
    FilterModule,
  
    AddNoteModalModule,
    AddOrEditTimelineModule,
    ModalModule.forRoot(),
    Ng4GeoautocompleteModule.forRoot(),
    TimelineModule
  ],
  declarations: [
    ContactComponent,
    ContactDetailComponent,
    ContactFocusInputDirective,
  ],
  providers: [
    ContactService
  ]
})
export class ContactModule { }
