import { ModalDirective } from 'ng2-bootstrap';
import { ConfigService } from './../../../services/config.service';
import { AddNoteModalComponent } from './../../subs/modals/add-note-modal/add-note-modal.component';
import { AddOrEditTimelineComponent } from './../../subs/modals/add-or-edit-timeline/add-or-edit-timeline.component';
import { ApiService } from './../../../services/api.service';
import { ConfigurationService } from './../../configuration/configuration.service';
import { ClientsService } from './../../clients/clients.service';
import { FormGroup } from '@angular/forms';
import { Contact, GoogleAddress, Address } from './../../../models/configuration';
import { ContactService } from './../contact.service';
import { HelperService } from './../../../services/helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import * as _ from 'lodash';
declare var $: any;
import { select } from 'ng2-redux';
import 'rxjs/add/operator/toPromise';
import { textMask, textMaskUserInformation } from '../../common/constants';
import { TimelineComponent } from '../../subs/timeline/timeline.component';

@Component({
  selector: 'app-contact-detail',
  templateUrl: './contact-detail.component.html',
  styleUrls: ['./contact-detail.component.scss']
})
export class ContactDetailComponent implements OnInit, AfterViewInit {
  @ViewChild('addOrEditTimelineModal') addOrEditTimelineModal: AddOrEditTimelineComponent;
  @ViewChild('addNotesModal') public addNotesModal: AddNoteModalComponent;
  @ViewChild('timelineTable') public timelineTable: TimelineComponent;
  @ViewChild('modalDeactiveContact') public modalDeactiveContact: ModalDirective;

  public maskPhoneFormat = textMask.maskPhoneNumber;
  public maskFaxNumber = textMask.maskFaxNumber;
  public maskMobileFormat = textMaskUserInformation.maskMobileNumber;

  isContactDetail = false;
  enableBtnEdit = true;
  showActive = false;
  textActive = 'Deactive';

  // Client page send
  cantEditClient = false;
  clientData: any;
  clientId: null;
  siteId: null;

  contactId: string;
  contactModel: Contact;
  googleAddressModel: GoogleAddress;
  postalAddressModel: Address;

  formContactDetail: FormGroup;
  statesData = [];
  positionsData = [];
  divisionsData = [];
  industriesData = [];
  contactStatusesData = [];
  ratingsData = [];
  clientsManager = [];
  servicesData = [];
  companiesData = [];
  contactCompanys = [];
  errorMessages: any;

  filteredClientManagerSingle: any[];
  filteredCompaniesSingle: any[];

  filteredServiceMultiple: any[];

  public geolocationSetting: any = {
    showCurrentLocation: false,
    showSearchButton: false
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private contactService: ContactService,
    private clientService: ClientsService,
    private configuarationService: ConfigurationService,
    private apiService: ApiService,
    private configService: ConfigService,
  ) {
    this.contactModel = new Contact();
    this.googleAddressModel = new GoogleAddress();
    this.postalAddressModel = new Address();
    this.customFormContactDetail();

    this.route.params.subscribe(param => {
      this.contactId = param['id'];
    });

    this.route.queryParams.subscribe(res => {
      this.clientId = res.clientId;
      this.siteId = res.siteId;

      if (res.clientId || res.siteId) {
        this.cantEditClient = true;
      } else {
        this.cantEditClient = false;
      }
    });
  }

  ngOnInit() {
    this.loadData();
    window.scrollTo(0, 0);
    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-contact ul li').each(function () {
        if ($('#contact-details').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr('href-anchor'));
          if (refElement.position() && refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-contact ul li a').removeClass('active-menu');
            currLink.addClass('active-menu');
          } else {
            currLink.removeClass('active-menu');
          }
        }
      });
    }

    if ($('#contact-details').length) {
      $(document).on('scroll', onScroll);
    }

    $('.ancho-contact ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-contact ul li a').removeClass('active-menu');
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }

  clearTextBox() {
    this.customFormContactDetail();
    this.changeStatusEdit();
  }

  filterClientManagerSingle(event) {
    let query = event.query;
    this.filteredClientManagerSingle = this.contactService.filterClientManager(query, this.clientsManager);

  }

  filterCompaniesNameSingle(event) {
    let query = event.query;

    let filtered: any[] = [];
    for (let i = 0; i < this.contactCompanys.length; i++) {
      let item = this.contactCompanys[i];
      if (item.Name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
        filtered.push(item);
      }
    }
    this.filteredCompaniesSingle = filtered;
  }

  filterServiceMultiple(event) {
    let query = event.query;
    this.filteredServiceMultiple = this.contactService.filterServicesMulti(query, this.servicesData);
  }

  changeStatusEdit() {
    this.enableBtnEdit = !this.enableBtnEdit;

    if (!this.enableBtnEdit) {
      setTimeout(() => {
        this.showActive = false;
        this.formContactDetail.disable();
      });
    } else {
      setTimeout(() => {
        this.formContactDetail.enable();
        this.textActive = 'Deactive';
        if (!this.contactModel.Active) {
          this.textActive = 'Active';
        }
        this.showActive = false;
        if (this.isContactDetail) {
          this.showActive = true;
        }
      });
    }
  }

  checkActiveDeactiveContact() {
    if (this.contactModel.Active) {
      this.modalDeactiveContact.show();
    } else {
      this.saveActiveContact();
    }
  }

  showAddOrEditTimelineModal(type) {
    this.addOrEditTimelineModal.initParams(null, type, null, this.contactId);
    this.addOrEditTimelineModal.show();
  }

  showAddNotesModal() {
    this.addNotesModal.initParams(null, null, this.contactId);
    this.addNotesModal.show();
  }

  saveTimelineSuccessed(event) {
    this.timelineTable.saveTimelineSuccessed(event);
  }

  saveNoteSuccessed(event) {
    this.timelineTable.saveNoteSuccessed(event);
  }

  customFormContactDetail() {
    this.formContactDetail = this.contactService.renderFormContactDetail(this.contactModel);
  }

  saveActiveContact() {
    this.contactModel.Active = !this.contactModel.Active;
    let contactUpdate = new Contact();
    contactUpdate.Active = this.contactModel.Active;
    contactUpdate.ObjectID = this.contactModel.ObjectID;

    delete this.contactModel.TransCompanyName;

    let params = {
      create: {},
      update: {
        'UPDATE:1': contactUpdate,
      },
      delete: {}
    };

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      this.modalDeactiveContact.hide();
      this.helperService.hideLoading();
      this.changeStatusEdit();
    }, error => {
      this.helperService.hideLoading();
    });
  }

  validateService(event) {
    if (!this.filteredServiceMultiple || (this.filteredServiceMultiple && this.filteredServiceMultiple.length == 0)) {
      event.target.value = "";
    }
  }

  removeAllSpace(formGroup: FormGroup) {
    this.helperService.removeAllSpace(formGroup);
  }

  testOpen(data: any) {
  }

  saveContactDetail() {
    this.errorMessages = null;
    console.log(this.formContactDetail);
    if (!this.formContactDetail.controls.FirstName.valid || !this.formContactDetail.controls.LastName.valid) {
      this.errorMessages = [];
      this.helperService.markFormGroupTouched(this.formContactDetail);
      return;
    }

    // Contact Model
    this.contactModel.FirstName = this.formContactDetail.value.FirstName;
    this.contactModel.LastName = this.formContactDetail.value.LastName;

    if (this.clientId) {
      this.contactModel.Client = this.clientId;
      this.contactModel.Company = this.clientId;
    } else {
      let clientID = null;

      if (this.formContactDetail.value.CompanyName) {
        // clientID = this.formContactDetail.value.CompanyName.Client ? this.formContactDetail.value.CompanyName.Client : this.formContactDetail.value.CompanyName.Site;
        this.contactModel.Client = this.formContactDetail.value.CompanyName.Client ? this.formContactDetail.value.CompanyName.Client : null;
        this.contactModel.Company = this.formContactDetail.value.CompanyName.Client ? this.formContactDetail.value.CompanyName.Client : null;
        this.contactModel.Site = this.formContactDetail.value.CompanyName.Site ? this.formContactDetail.value.CompanyName.Site : null;
      }
    }
    this.contactModel.TransCompanyName = this.formContactDetail.value.CompanyName ? this.formContactDetail.value.CompanyName.ObjectID : null;
    this.contactModel.ClientManager = this.formContactDetail.value.ClientManager ? this.formContactDetail.value.ClientManager.ObjectID : null;
    this.contactModel.Division = this.formContactDetail.value.Division;
    this.contactModel.Email = this.formContactDetail.value.Email;
    this.contactModel.EmailOther = this.formContactDetail.value.EmailOther;
    this.contactModel.Fax = this.formContactDetail.value.Fax;
    this.contactModel.Industry = this.formContactDetail.value.Industry;
    this.contactModel.Mobile = this.formContactDetail.value.Mobile;
    this.contactModel.Phone = this.formContactDetail.value.Phone;
    this.contactModel.Position = this.formContactDetail.value.Position;
    this.contactModel.Rating = this.formContactDetail.value.Rating;
    this.contactModel.State = this.formContactDetail.value.State;

    this.contactModel.ContactServices = [];
    if (this.formContactDetail.value.Services) {
      this.formContactDetail.value.Services.forEach(element => {
        this.contactModel.ContactServices.push(element.ObjectID);
      });
    }

    // Google Address Model
    let googleAddress = new GoogleAddress();
    let postalAddress = new Address();

    if (this.isContactDetail) {
      if (this.googleAddressModel.GoogleAddressText && this.googleAddressModel.GoogleAddressText !== this.contactModel.GoogleAddress.GoogleAddressText) {
        googleAddress = this.googleAddressModel;
        googleAddress.ObjectID = this.contactModel.GoogleAddress.ObjectID;
        this.contactModel.GoogleAddress = this.googleAddressModel;

      } else {
        googleAddress = this.contactModel.GoogleAddress;
      }

      postalAddress = this.contactModel.PostalAddressDetail;
      postalAddress.Street = this.formContactDetail.value.PostalAddress;

      let params = {
        create: {},
        update: {
          'UPDATE:1': this.contactModel,
          'UPDATE:2': googleAddress,
          'UPDATE:3': postalAddress
        },
        delete: {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        if (res.status === this.configService.errorStatus) {
          this.errorMessages = res.errorDetails;
          this.helperService.hideLoading();
          return;
        }
        this.errorMessages = null;

        this.helperService.hideLoading();
        this.changeStatusEdit();
      }, error => {
        this.errorMessages = error.error.errorDetails;
        this.helperService.hideLoading();
      });
    } else {
      if (this.googleAddressModel.GoogleAddressText) {
        googleAddress = this.googleAddressModel;
      }

      postalAddress.Street = this.formContactDetail.value.PostalAddress;
      let params = {
        create: {
          'NEW:1': googleAddress,
          'NEW:2': postalAddress,

        },
        update: {},
        delete: {}
      };

      this.helperService.showLoading();
      this.apiService.saveService(params).subscribe(res => {
        if (res.status === this.configService.errorStatus) {
          this.errorMessages = res.errorDetails;
          this.helperService.hideLoading();
          return;
        }
        this.errorMessages = null;

        this.contactModel.PostalAddress = _.get(res.created, 'NEW:2');

        let newAddress = new Address();
        newAddress.GoogleAddress = _.get(res.created, 'NEW:1');
        let params = {
          create: {
            'NEW:1': newAddress
          },
          update: {},
          delete: {}
        };

        this.apiService.saveService(params).subscribe(res => {
          if (res.status === this.configService.errorStatus) {
            this.errorMessages = res.errorDetails;
            this.helperService.hideLoading();
            return;
          }
          this.errorMessages = null;

          this.contactModel.Address = _.get(res.created, 'NEW:1');

          let params = {
            create: {
              'NEW:1': this.contactModel
            },
            update: {},
            delete: {}
          };

          this.apiService.saveService(params).subscribe(res => {
            if (res.status === this.configService.errorStatus) {
              this.errorMessages = res.errorDetails;
              this.helperService.hideLoading();
              return;
            }
            this.errorMessages = null;
            this.contactId = _.get(res.created, 'NEW:1')

            this.router.navigateByUrl("/contact/" + this.contactId, { skipLocationChange: false });

            this.loadContactDetail(this.contactId);
            this.isContactDetail = true;
            // this.router.navigate(['/contact', event.data.ObjectID]);

          }, error => {
            this.errorMessages = error.error.errorDetails;
            this.helperService.hideLoading();
          });

        }, error => {
          this.errorMessages = error.error.errorDetails;
          this.helperService.hideLoading();
        });

      }, error => {
        this.errorMessages = error.error.errorDetails;
        this.helperService.hideLoading();
      });
    }
  }

  autoCompleteAddressCallback(selectedData: any) {
    if (selectedData.response) {
      let addressDetail = this.contactService.getAddressDetail(selectedData.data.address_components);
      this.googleAddressModel.City = addressDetail.City ? addressDetail.City.long_name : null;
      this.googleAddressModel.Country = addressDetail.Country ? addressDetail.Country.long_name : null;
      this.googleAddressModel.State = addressDetail.State ? addressDetail.State.long_name : null;
      this.googleAddressModel.StreetAddress = addressDetail.StreetAddress ? addressDetail.StreetAddress.long_name : null;
      this.googleAddressModel.StreetNumber = addressDetail.StreetNumber ? addressDetail.StreetNumber.long_name : null;
      this.googleAddressModel.ZipCode = addressDetail.ZipCode ? addressDetail.ZipCode.long_name : null;

      this.googleAddressModel.GoogleAddressText = selectedData.data.description;
      this.googleAddressModel.Latitude = selectedData.data.geometry.location.lat;
      this.googleAddressModel.Longitude = selectedData.data.geometry.location.lng;
    }
  }

  redirectClientPage(clientId = null) {
    if (clientId === null) {
      if (this.siteId) {
        this.router.navigate(['/sites/detail/', this.siteId]);
      } else {
        this.router.navigate(['/clients/detail/', this.clientId]);
      }
    } else {
      this.router.navigate(['/clients/detail/', clientId]);
    }
  }

  loadContactDetail(id) {
    this.helperService.showLoading();
    this.contactService.getContactById(id).then(res => {
      this.contactModel = _.get(res.references, res.results[0]);
      this.contactModel.ClientManager = _.find(this.clientsManager, s => s.ObjectID === this.contactModel.ClientManager);
      // this.contactModel.Company = _.find(this.companiesData, s => s.ObjectID === this.contactModel.Company);
      if (this.contactModel.TransCompanyName) {
        let transCompany = _.get(res.references, this.contactModel.TransCompanyName);
        this.contactModel.CompanyDetail = _.find(this.contactCompanys, s => s.Name === transCompany.Name && s.Client === transCompany.Client && s.Site === transCompany.Site);
      }

      if (this.clientId) {
        this.clientData = _.find(this.contactCompanys, s => s.Client === this.clientId);
      }

      if (this.siteId) {
        this.clientData = _.find(this.contactCompanys, s => s.Site === this.siteId);
      }

      this.contactModel.AddressDetail = _.get(res.references, this.contactModel.Address);
      this.contactModel.GoogleAddress = _.get(res.references, this.contactModel.AddressDetail.GoogleAddress);
      this.contactModel.PostalAddressDetail = _.get(res.references, this.contactModel.PostalAddress);
      let contactService = [];
      this.contactModel.ContactServices.forEach(element => {
        contactService.push(_.get(res.references, element));
      });

      this.contactModel.ContactServices = contactService;

      this.geolocationSetting = {
        showCurrentLocation: false,
        showSearchButton: false,
        inputString: this.contactModel.GoogleAddress.GoogleAddressText
      };

      this.customFormContactDetail();
      this.changeStatusEdit();
      this.helperService.hideLoading();
    }).catch(e => {
      this.helperService.hideLoading();
    })
  }

  cancelContact() {
    if (this.siteId) {
      this.router.navigate(['/sites/detail/', this.siteId]);
    } else {
      this.router.navigate(['/contact']);
    }
  }

  loadData() {
    this.helperService.showLoading();
    new Promise((resolve, reject) => {
      Promise.all([
        this.clientService.getAllStates(),
        this.configuarationService.getAllPosition().toPromise(),
        this.configuarationService.getAllDivisionByState().toPromise(),
        this.configuarationService.getAllIndustry().toPromise(),
        this.contactService.getContactStatuses(),
        this.configuarationService.getAllRating().toPromise(),
        this.contactService.getClientManager(),
        this.configuarationService.getAllService().toPromise(),
        this.configuarationService.getAllClient().toPromise(),
        this.contactService.getContactCompanyNames()
      ]).then(
        ([states, positions, divisions, industries, contactStatuses, ratings, clients, services, companies, contactCompanys]) => {
          this.statesData = this.contactService.getReferencesData(states);
          this.contactStatusesData = contactStatuses.results;
          this.positionsData = this.contactService.getReferencesData(positions);
          this.divisionsData = this.contactService.getReferencesData(divisions);
          this.industriesData = this.contactService.getReferencesData(industries);
          this.ratingsData = this.contactService.getReferencesData(ratings);
          this.servicesData = this.contactService.getReferencesData(services);
          this.clientsManager = this.contactService.getReferencesData(clients);
          this.companiesData = this.contactService.getReferencesData(companies);
          // this.contactCompanys = this.contactService.getReferencesData(contactCompanys);

          contactCompanys.results.forEach(element => {
            let item = _.get(contactCompanys.references, element);
            // item.ClientDetail = _.get(contactCompanys.references, item.Client);
            item.SiteDetail = _.get(contactCompanys.references, item.Site);
            if (item.SiteDetail) {
              item.SiteDetail.ClientDetail = _.get(contactCompanys.references, item.SiteDetail.Client);
            }
            this.contactCompanys.push(item);
          });

          if (this.clientId) {
            this.clientData = _.find(this.contactCompanys, s => s.Client === this.clientId);
          }

          if (this.siteId) {
            this.clientData = _.find(this.contactCompanys, s => s.Site === this.siteId);
            this.contactModel.CompanyDetail = this.clientData
          }

          if (this.contactId !== 'add') {
            this.isContactDetail = true;
            this.loadContactDetail(this.contactId);
          } else {
            this.isContactDetail = false;
            this.customFormContactDetail();
            this.helperService.hideLoading();
          }
        }).catch(e => {
        })
    });
  }

}
