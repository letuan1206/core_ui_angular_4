import { Directive, AfterViewChecked, ElementRef, AfterViewInit, HostListener, Renderer } from '@angular/core';
declare var jquery: any;
declare var $: any;
@Directive({
  selector: '[appContactFocusInput]'
})
export class ContactFocusInputDirective implements AfterViewChecked, AfterViewInit{

  constructor(private el:ElementRef,  private renderer: Renderer) {      
  }
    ngAfterViewChecked(){

    }
    ngAfterViewInit() {
        
    }
    @HostListener('click', ['$event'])
    onClick() {                
        this.renderer.invokeElementMethod(this.el.nativeElement.querySelector('.ui-inputtext'), 'focus');
    }
      
    
}
