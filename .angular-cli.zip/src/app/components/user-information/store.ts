import { tassign } from 'tassign';
import * as constant from './actions';

export interface UserInformationState {
    age: number;
}

export const USER_INFORMATION_INITAL_STATE: UserInformationState = {
    age: 0
};


export function organisationReducer(state = USER_INFORMATION_INITAL_STATE, action): UserInformationState {
    switch (action.type) {
    }

    return state;
}
