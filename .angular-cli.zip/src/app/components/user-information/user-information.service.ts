import { matchingPasswords } from './../../validators/validators';
import { User } from './../../models/user';
import { ApiService } from './../../services/api.service';
import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ConfigService } from '../../services/config.service';
import { HelperService } from '../../services/helper.service';
import { NgRedux } from 'ng2-redux';
import { UserInformation } from '../../models/user';
import * as _ from 'lodash';
import { FormGroup } from '@angular/forms/src/model';

@Injectable()
export class UserInformationService {

  constructor(
    private http: Http,
    private fb: FormBuilder,
    public configService: ConfigService,
    private api: ApiService,
    private helperService: HelperService,
    private ngRedux: NgRedux<any>
  ) {

  }

  listColor() {
    return [
      '#660000',
      '#990000',
      '#d24143',
      '#de4f5d',
      '#ea4c88',
      '#993399',
      '#663399',
      '#07385d',
      '#1e5598',
      '#2d72d9',
      '#018ee0',
      '#0099cc',
      '#37a5a5',
      '#439454',
      '#439454',
      '#336600',
      '#165151',
      '#999900',
      '#e9a23f',
      '#996633',
      '#553a48',
      '#313949',
    ];
  }

  renderFormUserInformation(userInfo: UserInformation, user: User, editUserInforStatus) {
    return this.fb.group({
      UserName: [{ value: user.FirstName || '' + ' ' + (user.LastName || ''), disabled: editUserInforStatus }, [Validators.required]],
      Position: [{ value: userInfo.Position, disabled: editUserInforStatus }, [Validators.required]],
      Phone: [{ value: userInfo.Phone, disabled: editUserInforStatus }],
      Mobile: [{ value: userInfo.Mobile, disabled: editUserInforStatus }],
      Email: [{ value: user.Email, disabled: editUserInforStatus }, [Validators.required]],
      RolePermission: [{ value: userInfo.Role, disabled: editUserInforStatus }, [Validators.required]],
      TimeFormat: [{ value: userInfo.TimeFormatValue, disabled: editUserInforStatus }, [Validators.required]],
      TimeZone: [{ value: userInfo.TimeZoneValue, disabled: editUserInforStatus }, [Validators.required]],
      Status: [{ value: user.Enabled, disabled: editUserInforStatus }],
      Password: [{ value: '', disabled: editUserInforStatus }],
      ConfirmPassword: [{ value: '', disabled: editUserInforStatus }],
      EnforcePassword: [{ value: userInfo.EnforcePassword || false, disabled: editUserInforStatus }],
      Country: [{ value: userInfo.Country, disabled: editUserInforStatus }, [Validators.required]],
      Language: [{ value: userInfo.LanguageValue, disabled: editUserInforStatus }, [Validators.required]],
    }, { validator: matchingPasswords('Password', 'ConfirmPassword') });
  }

  renderSelectOptionValue(formUserInformation: FormGroup, userInfo: UserInformation) {
    return formUserInformation.controls['TimeZone'].setValue(userInfo.TimeZone);
  }

  getTimeZone(): Promise<any> {
    let params = {
      queryType: 'All',
      assocs: []
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/Timezones`, params).subscribe(res => {
        resolve(res.results);
      }, reject);
    });
  }

  getTimeFormat(): Promise<any> {
    let params = {
      queryType: 'All',
      assocs: []
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/TimeFormats`, params).subscribe(res => {
        resolve(res.results);
      }, reject);
    });
  }

  getLanguage(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params = {
        queryType: 'All',
        assocs: []
      }

      this.api.post(`/Languages`, params)
        .subscribe(res => {
          resolve(res.results);
        }, reject);
    });
  }

  getRoles(queryParams): Promise<any> {
    let params = {
      queryType: 'All',
      queryParams: queryParams,
      assocs: []
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/Roles`, params).subscribe(res => {
        let roles = [];

        res.results.forEach(element => {
          roles.push(_.get(res.references, element));
        });

        resolve(roles);
      }, reject);
    });
  }

  getEnvironmentInformation(): Promise<any> {
    let params = {
      queryType: 'All',
      assocs: []
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/EnvironmentInformation`, params).subscribe(res => {
        resolve(res);
      }, reject);
    });
  }

  getProsekUserInformation(): Promise<any> {
    let params = {
      queryType: 'All',
      queryParams: {},
      assocs: ['User']
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/ProsekUserInformation`, params).subscribe(res => {
        resolve(res);
      }, reject);
    });
  }

  getProsekUserInformationByUser(userID): Promise<any> {
    let params = {
      queryType: 'All',
      queryParams: {
        User: userID
      },
      assocs: ['User']
    }

    return new Promise((resolve, reject) => {
      this.api.post(`/ProsekUserInformation`, params).subscribe(res => {
        resolve(res);
      }, reject);
    });
  }

}
