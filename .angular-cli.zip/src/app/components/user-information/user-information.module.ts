import { SafeHtmlPipe } from './../../pipes/safe-html.pipe';
import { UserInformationComponent } from './user-information.component';

import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { TextMaskModule } from 'angular2-text-mask';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../../app.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FileUploadModule } from 'ng2-file-upload/file-upload/file-upload.module';
import { ModalModule } from 'ngx-bootstrap/modal/modal.module';
import { CKEditorModule } from 'ng2-ckeditor';
import { UserInformationService } from './user-information.service';
import { ColorPickerModule } from 'ngx-color-picker';

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    FileUploadModule,
    TextMaskModule,
    MultiselectDropdownModule,
    CKEditorModule,
    ColorPickerModule,
    ModalModule.forRoot()
  ],
  declarations: [
    UserInformationComponent,
    SafeHtmlPipe
  ],
  providers: [
    UserInformationService,
  ]
})
export class UserInformationModule { }
