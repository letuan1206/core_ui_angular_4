import { ActivatedRoute } from '@angular/router';
import { ConfigService } from './../../services/config.service';
import { element } from 'protractor';
import { Division, CountryState } from './../../models/configuration';
import { ApiService } from './../../services/api.service';
import { ConfigurationService } from './../configuration/configuration.service';
import { textMaskUserInformation, themeColorActions, LOCALSTORE_KEY, PRIVILEGES } from './../common/constants';
import { FormGroup } from '@angular/forms';
import { UserInformation, User, ProsekAdminUserDivisionLink } from './../../models/user';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { UserInformationService } from './user-information.service';
import * as _ from 'lodash';
import { HelperService } from '../../services/helper.service';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-user-information',
  templateUrl: './user-information.component.html',
  styleUrls: ['./user-information.component.scss']
})
export class UserInformationComponent implements OnInit, OnDestroy {

  user: User;
  userInformation: UserInformation;
  countryStates: CountryState[] = [];
  countryStatesOrigin: CountryState[] = [];
  adminUserDivisionLink: ProsekAdminUserDivisionLink[] = [];
  countries = [];
  roles = [];
  timeZones = [];
  languages = [];

  menuBarColors = [];
  menuTextColors = [];
  headingBarColors = [];
  headingTextColors = [];

  colorSelects: any;

  // Use this array to bind color array in theme option
  colorArray = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
  colorArraySelect = {
    menuBar: -1,
    menuText: -1,
    headingBar: -1,
    headingText: -1
  };

  timeFormat = [];

  statusActive = [
    {
      enable: true,
      description: 'Active'
    }, {
      enable: false,
      description: 'Deactive'
    }
  ];

  formUserInformation: FormGroup;

  editUserInformationStatus = false;
  editThemeStatus = false;
  editEmailStatus = false;
  editDivisionStatus = false;
  canEditRole = false;

  emailContent: string;
  responseStatus: any;
  errorMessages: any;

  public maskPhoneNumber = textMaskUserInformation.maskMobileNumber;
  private idAnchor: any;
  ckeConfig: any;
  @ViewChild("ckeditor") ckeditor: any;

  constructor(
    private configurationService: ConfigurationService,
    private userInfoService: UserInformationService,
    private apiService: ApiService,
    private helperService: HelperService,
    private configService: ConfigService,
    private _activatedRoute: ActivatedRoute
  ) {
    this.user = new User();
    this.userInformation = new UserInformation();
    this.responseStatus = this.configService.get('status');
  }

  ngOnInit() {
    this.loadData();
    this.customFormUserInformation();

    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-3 ul li').each(function () {
        if ($('#user-information').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr('href-anchor'));
          if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-3 ul li a').removeClass('active-menu');
            currLink.addClass('active-menu');
          } else {
            currLink.removeClass('active-menu');
          }
        }
      });
    }

    if ($('#user-information').length) {
      $(document).on('scroll', onScroll);
    }

    $('.ancho-3 ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-3 ul li a').removeClass('active-menu');
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });

    this.ckeConfig = {
      height: 400,
      language: "en",
      allowedContent: true,
      toolbar: [
        { name: "clipboard", items: ["Cut", "Copy", "Paste", "PasteText", "PasteFromWord", "-", "Undo", "Redo"] },
        { name: "links", items: ["Link", "Unlink", "Anchor"] },
        { name: "insert", items: ["Image", "Table", "HorizontalRule", "SpecialChar", "Iframe", "imageExplorer"] }
      ]
    };
  }

  customFormUserInformation() {
    this.formUserInformation = this.userInfoService.renderFormUserInformation(this.userInformation, this.user, !this.editUserInformationStatus);
  }

  changeStatusEditUserInfor() {
    this.editUserInformationStatus = !this.editUserInformationStatus;

    if (this.editUserInformationStatus) {
      this.formUserInformation.enable();
      if (!this.canEditRole) {
        this.formUserInformation.get('RolePermission').disable();
      }
    } else {
      this.formUserInformation.disable();
    }
  }

  saveUserInformation() {
    if (this.formUserInformation.hasError('mismatchedPasswords')) {
      this.errorMessages = [];

      if (this.formUserInformation.value.ConfirmPassword) {
        this.errorMessages.push('Password and Verify Password do not match.');
      } else {
        this.errorMessages.push('Verify Password field is invalid.');
      }
      return;
    }

    if (!this.formUserInformation.valid) {
      this.errorMessages = [];
      this.helperService.markFormGroupTouched(this.formUserInformation);
      return;
    }

    this.userInformation.Mobile = this.formUserInformation.value.Mobile;
    this.userInformation.Phone = this.formUserInformation.value.Phone;
    this.userInformation.TimeZone = this.formUserInformation.value.TimeZone;
    this.userInformation.Language = this.formUserInformation.value.Language;
    this.userInformation.Role = this.formUserInformation.value.RolePermission;
    this.userInformation.EnforcePassword = this.formUserInformation.value.EnforcePassword;
    this.userInformation.Position = this.formUserInformation.value.Position;
    this.userInformation.TimeFormat = this.formUserInformation.value.TimeFormat;
    this.userInformation.Country = this.formUserInformation.value.Country;

    this.userInformation.TimeFormatValue = this.formUserInformation.value.TimeFormat;
    this.userInformation.LanguageValue = this.formUserInformation.value.Language;
    this.userInformation.TimeZoneValue = this.formUserInformation.value.TimeZone;

    //delete this.userInformation.Divisions;

    //this.userInformation.Divisions = ["ID:295533"];

    this.user.Email = this.formUserInformation.value.Email;
    this.user.Enabled = this.formUserInformation.value.Status;
    var fullName = this.formUserInformation.value.UserName.split(' ');
    this.user.FirstName = fullName.shift();
    this.user.LastName = _.join(fullName, ' ').trim();

    if (this.formUserInformation.value.Password) {
      this.user.NewPassword = this.formUserInformation.value.Password;
    } else {
      delete this.user.NewPassword;
    }

    var params = {};

    if (this.userInformation.ObjectID) {
      params = {
        create: {
          'NEW:1': {
            ObjectClass: "prosek.orm.ProsekAdminUserDivisionLink",
            Division: "ID:292312",
            AdminUser: "ID:223744"
          }
        },
        update: {
          'ID:1': this.userInformation,
          'ID:2': this.user
        },
        delete: {},
      };
    } else {
      this.userInformation.User = this.user.ObjectID;
      params = {
        create: { 'NEW:1': this.userInformation },
        update: { 'ID:2': this.user },
        delete: {},
      };
    }

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if (res.status === this.responseStatus.error) {
        this.errorMessages = res.errorDetails;
        this.helperService.hideLoading();
        return;
      }
      this.errorMessages = null;

      if (!this.userInformation.ObjectID) {
        this.userInformation.ObjectID = _.get(res.created, 'NEW:1');
      }

      this.changeStatusEditUserInfor();
      this.customFormUserInformation();
      this.helperService.hideLoading();
    });
  }

  cancelSaveUserInfo() {
    this.errorMessages = null;
    this.changeStatusEditUserInfor();
    this.customFormUserInformation();
  }

  changeStatusEditTheme() {
    this.editThemeStatus = !this.editThemeStatus;
  }

  onChangeThemeColor(actionType, color, index) {
    switch (actionType) {
      case themeColorActions.MENU_BAR:
        $('.app-header.navbar').css('background-color', color);
        this.colorSelects.menuBar = color;
        if (index) {
          this.colorArraySelect.menuBar = index;
        }
        break;
      case themeColorActions.MENU_TEXT:
        $('.app-header.navbar .nav-item .nav-link').css('color', color);
        this.colorSelects.menuText = color;
        if (index) {
          this.colorArraySelect.menuText = index;
        }
        break;
      case themeColorActions.HEADING_BAR:
        $('.card-header').css('background-color', color);
        this.colorSelects.headingBar = color;
        if (index) {
          this.colorArraySelect.headingBar = index;
        }
        break;
      case themeColorActions.HEADING_TEXT:
        $('.card-header').css('color', color);
        $('.sheet-right-edit .fake-link').css('color', color);
        this.colorSelects.headingText = color;
        if (index) {
          this.colorArraySelect.headingText = index;
        }
        break;
    }
  }

  initThemColor() {
    return {
      menuBar: this.userInformation.MenuBarColour,
      menuText: this.userInformation.MenuTextColour,
      headingBar: this.userInformation.HeadingBarColour,
      headingText: this.userInformation.HeadingTextColour
    };
  }

  initColorSelect() {
    return {
      menuBar: -1,
      menuText: -1,
      headingBar: -1,
      headingText: -1
    };
  }

  saveThemeColor() {
    this.userInformation.MenuBarColour = this.colorSelects.menuBar;
    this.userInformation.MenuTextColour = this.colorSelects.menuText;
    this.userInformation.HeadingBarColour = this.colorSelects.headingBar;
    this.userInformation.HeadingTextColour = this.colorSelects.headingText;

    //delete this.userInformation.Divisions;

    var params = {};

    if (this.userInformation.ObjectID) {
      params = {
        create: {},
        update: {
          'ID:1': this.userInformation,
        },
        delete: {},
      };
    } else {
      this.userInformation.User = this.user.ObjectID;
      params = {
        create: { 'NEW:1': this.userInformation },
        update: {},
        delete: {},
      };
    }

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if (!this.userInformation.ObjectID) {
        this.userInformation.ObjectID = _.get(res.created, 'NEW:1');
      }

      this.changeStatusEditTheme();
      localStorage.setItem(LOCALSTORE_KEY.THEME_SETTING, JSON.stringify(this.colorSelects));
      this.helperService.hideLoading();
    });
  }

  cancelSaveThemColor() {
    this.colorSelects = this.initThemColor();
    this.colorArraySelect = this.initColorSelect();

    this.menuBarColors = _.cloneDeep(this.userInfoService.listColor());
    this.menuTextColors = _.cloneDeep(this.userInfoService.listColor());
    this.headingBarColors = _.cloneDeep(this.userInfoService.listColor());
    this.headingTextColors = _.cloneDeep(this.userInfoService.listColor());

    this.setThemeDefault();

    this.changeStatusEditTheme();
  }

  setThemeDefault() {
    $('.app-header.navbar').css('background-color', this.userInformation.MenuBarColour || '');
    $('.app-header.navbar .nav-item .nav-link').css('color', this.userInformation.MenuTextColour || '');

    $('.card-header').css('background-color', this.userInformation.HeadingBarColour || '');
    $('.card-header').css('color', this.userInformation.HeadingTextColour || '');
    $('.sheet-right-edit .fake-link').css('color', this.userInformation.HeadingTextColour || '');
  }

  changeStatusEmail() {
    this.editEmailStatus = !this.editEmailStatus;
  }

  cancelSaveEmailTemplate() {
    this.emailContent = _.cloneDeep(this.userInformation.EmailSignature);
    this.changeStatusEmail();
  }
  saveEmailTemplate() {
    this.userInformation.EmailSignature = this.emailContent;

    //delete this.userInformation.Divisions;

    var params = {};

    if (this.userInformation.ObjectID) {
      params = {
        create: {},
        update: {
          'ID:1': this.userInformation,
        },
        delete: {},
      };
    } else {
      this.userInformation.User = this.user.ObjectID;
      params = {
        create: { 'NEW:1': this.userInformation },
        update: {},
        delete: {},
      };
    }

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {

      if (!this.userInformation.ObjectID) {
        this.userInformation.ObjectID = _.get(res.created, 'NEW:1');
      }

      this.changeStatusEmail();
      this.helperService.hideLoading();
    });
  }

  collapseAll(data) {
    if (data) {
      _.map(this.countryStates, state => {
        state.Collapse = true;
      });
    } else {
      _.map(this.countryStates, state => {
        state.Collapse = false;
      });
    }
  }

  setValueUserInformation() {
    if (this.userInformation.TimeFormat.Value) {
      this.userInformation.TimeFormatValue = (_.find(this.timeFormat, item => item.Value === this.userInformation.TimeFormat.Value)).Value;
    }

    if (this.userInformation.Language.Value) {
      this.userInformation.LanguageValue = (_.find(this.languages, item => item.Value === this.userInformation.Language.Value)).Value;
    }
    if (this.userInformation.TimeZone.Value) {
      this.userInformation.TimeZoneValue = (_.find(this.timeZones, item => item.Value === this.userInformation.TimeZone.Value)).Value;
    }
  }

  changeStatusDivision() {
    this.editDivisionStatus = !this.editDivisionStatus;
  }

  cancelSaveDivision() {
    this.countryStates = _.cloneDeep(this.countryStatesOrigin);
    this.changeStatusDivision();
  }

  saveDivision() {
    let divisionUpdate = [];
    this.countryStates.forEach(state => {
      state.Divisions.forEach(division => {
        if (division.Active) {
          divisionUpdate.push(division.ObjectID);
        }
      });
    });

    this.userInformation.Divisions = divisionUpdate;

    const params = {
      create: {},
      update: {
        'ID:1': this.userInformation,
      },
      delete: {},
    };

    this.helperService.showLoading();
    this.apiService.saveService(params).subscribe(res => {
      this.changeStatusDivision();
      this.countryStatesOrigin = _.cloneDeep(this.countryStates);
      this.helperService.hideLoading();
    });
  }

  loadData() {
    $('body').removeClass('sidebar-minimized brand-minimized');
    setTimeout(() => {
      this.helperService.showLoading();
      new Promise((resolve, reject) => {
        Promise.all([
          this.userInfoService.getLanguage(),
          this.userInfoService.getEnvironmentInformation(),
          this.userInfoService.getRoles(null),
          this.userInfoService.getTimeZone(),
          this.userInfoService.listColor(),
          this.configurationService.getAllCountry(),
          this.userInfoService.getTimeFormat(),
          this.configurationService.getAllState(),
          this.configurationService.getAllDivisionByState(),
        ]).then(
          ([languages, user, roles, timezones, colors, country, timeformats, states, divisions]) => {
            this.languages = languages;
            this.timeZones = timezones;
            this.timeFormat = timeformats;

            this.roles = roles;
            this.menuBarColors = _.cloneDeep(colors);
            this.menuTextColors = _.cloneDeep(colors);
            this.headingBarColors = _.cloneDeep(colors);
            this.headingTextColors = _.cloneDeep(colors);
            this.emailContent = '';

            country.subscribe(res => {
              this.countries = [];
              if (res.results) {
                res.results.forEach(element => {
                  this.countries.push(_.clone(_.get(res.references, element)));
                });
              }
            });

            this.colorArraySelect = this.initColorSelect();

            this.countryStates = [];

            states.subscribe(res => {
              res.results.forEach(element => {
                this.countryStates.push(_.get(res.references, element));
              });
            });


            if (user.UserID !== 'noprivauthtoken') {
              //this.user = _.toArray(user.references)[0];
              user.Privileges.filter(element => {
                if (element === PRIVILEGES.securityEditUserDetails) {
                  this.canEditRole = true;
                }
              });
            } else {
              console.error('User not found');
              alert('User not found');
              this.helperService.hideLoading();
              return;
            }

            // Call API Get UserInformation
            this.userInfoService.getProsekUserInformationByUser(user.UserID).then(res => {
              if (!res.results.length) {
                console.error('User not found');
                alert('User not found');
                this.helperService.hideLoading();
              }

              let userInformationTmp = _.find(_.toArray(res.references), item => {
                return item.User === user.UserID;
              });

              this.user = _.get(res.references, user.UserID);

              if (userInformationTmp) {
                this.userInformation = userInformationTmp;

                this.colorSelects = this.initThemColor();
                localStorage.setItem(LOCALSTORE_KEY.THEME_SETTING, JSON.stringify(this.colorSelects));
                this.setThemeDefault();

                if (this.userInformation.EmailSignature) {
                  this.emailContent = _.cloneDeep(this.userInformation.EmailSignature);
                }

                this.setValueUserInformation();

                let divisionIds = [];

                // this.userInformation.Divisions.forEach(element => {
                //   let divisionLink = _.get(res.references, element);
                //   this.adminUserDivisionLink.push(divisionLink);
                //   divisionIds.push(divisionLink.Division);
                // });

                divisions.subscribe(res => {
                  var divisions = _.toArray(res.references);

                  divisions.forEach(element => {
                    element.Active = false;
                    let dIndex = this.userInformation.Divisions.indexOf(element.ObjectID);
                    if (dIndex !== -1) {
                      element.Active = true;
                    }
                  });

                  // this.userInformation.Divisions.forEach(element => {
                  //   let aDivision = _.get(res.references, element);
                  //   if (aDivision) {
                  //     divisions.push(aDivision);
                  //   }
                  // });

                  _.map(this.countryStates, state => {
                    let data: Division[] = [];

                    data = _.filter(divisions, obj => {
                      return obj.State === state.ObjectID;
                    });

                    state.Collapse = false;
                    state.Divisions = _.orderBy(data, [function (division) {
                      return division.Description.toLowerCase();
                    }], ['asc']);;
                  });

                  this.customFormUserInformation();
                  this.countryStatesOrigin = _.cloneDeep(this.countryStates);
                });

                this.helperService.hideLoading();
              } else {
                this.userInformation = new UserInformation();
                this.userInformation.User = this.user.ObjectID;
                this.helperService.hideLoading();
              }
            })

            this._activatedRoute.params.subscribe(params => {
              this.idAnchor = params.idAnchor;
            });

            var anchoTemp = this.idAnchor;
            var scollToPos = $('#' + anchoTemp).offset().top;
            if (scollToPos != null) {
              setTimeout(() => {
                $('html, body').stop().animate({
                  'scrollTop': scollToPos - 121
                });
              }, 1500);
            }

            resolve();
          }, () => {
            reject();
          });
      });
    });
  }

  ngOnDestroy() {

  }
}
