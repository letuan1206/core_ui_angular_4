import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ISubscription } from "rxjs/Subscription";
import * as _ from 'lodash';
import { GEOLOCATION_TYPE } from '../common/constants';

// Services
import { HelperService } from './../../services/helper.service';
import { ApiService } from './../../services/api.service';
import { ConfigService } from './../../services/config.service';

// Interfaces
import { Params } from '../../interfaces/common-interface';
import { EmployeesTransformParam } from '../../interfaces/employees-interface';

// Redux 
import {
  STORE_FILTER_STATE,
  STORE_FILTER_STATUS,
  STORE_FILTER_SERVICE,
  STORE_FILTER_DIVISION,
  STORE_CLIENTS_DATA,
  STORE_FILTER_POSITION,
  STORE_EMPLOYEES_DATA
} from '../common/common-actions';

@Injectable()
export class EmployeesService {

  getAllEmployeesSub: ISubscription;
  getAllPositionSub: ISubscription;
  getAllClientsSub: ISubscription;
  getAllServicesSub: ISubscription;
  getAllStatesSub: ISubscription;
  getAllDivisionByStateSub: ISubscription;
  getAllDivisionSub: ISubscription;
  getAllIndustrySub: ISubscription;

  constructor(
    public configService: ConfigService,
    private apiService: ApiService,
    private helperService: HelperService
  ) {

  }

  getAllEmployees(employeesParams): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All',
        environment: this.configService.get('environment'),
        queryParams: employeesParams,
        assocs: ['User', 'Division', 'Position', 'State']
      };
      this.getAllEmployeesSub = this.apiService.post(`/ProsekEmployees`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllRating(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        environment: this.configService.get('environment'),
        queryType: 'All',
        assocs: []
      };
      this.getAllServicesSub = this.apiService.post(`/Ratings`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllStates(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_COUNTRY',
        queryParams: {},
        assocs: []
      };
      this.getAllStatesSub = this.apiService.post(`/CountryState`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllDivision(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'BY_DETAILS',
        queryParams: {},
        assocs: []
      };
      this.getAllDivisionSub = this.apiService.post(`/Division`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAddressDetail(addressComponent) {
    return {
      Country: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.COUNTRY) !== -1) {
          return s;
        }
      }),
      ZipCode: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.ZIP_CODE) !== -1) {
          return s;
        }
      }),
      City: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.CITY) !== -1) {
          return s;
        }
      }),
      StreetNumber: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_NUMBER) !== -1) {
          return s;
        }
      }),
      StreetAddress: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STREET_ADDRESS) !== -1) {
          return s;
        }
      }),
      State: _.find(addressComponent, s => {
        if (s.types.indexOf(GEOLOCATION_TYPE.STATE) !== -1) {
          return s;
        }
      })
    }
  }

  getAllIndustry(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.getAllIndustrySub = this.apiService.post(`/Industries`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllPosition(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.getAllIndustrySub = this.apiService.post(`/Positions`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getAllGender(): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'All'
      };
      this.getAllIndustrySub = this.apiService.post(`/Genders`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  getEmployeeDetail(Id: string): Promise<any> {
    return new Promise((resolve, reject) => {
      let params: Params = {
        queryType: 'ByID',
        queryParams: {
          id: Id
        },
        assocs: ['User', 'Division', 'Position', 'State', 'Rating', 'Industry', 'PostalAddress', 'Information.Address']
      };
      this.getAllEmployeesSub = this.apiService.post(`/ProsekEmployees`, params).subscribe(res => {
        resolve(res);
      }, err => {
        reject(err);
      });
    });
  }

  /**
   * Function load data of clients
   */
  async loadDataEmployees(type, queryParams, positionOptions, stateOptions, divisionOptions) {

    this.helperService.showLoading();

    try {

      let asyncDataEmployees = this.getAllEmployees(queryParams);
      let dataEmployee = await asyncDataEmployees;
      if (dataEmployee.result === this.configService.successStatus) {
        let transformParam: EmployeesTransformParam = new EmployeesTransformParam();
        transformParam.dataEmployee = dataEmployee;
        transformParam.positionOptions = positionOptions;
        transformParam.stateOptions = stateOptions;
        transformParam.divisionOptions = divisionOptions;
        let resultOfEmployees: any = this.helperService.transformData(transformParam);

        let datas = resultOfEmployees.datas;
        positionOptions = resultOfEmployees.positionOptions;
        stateOptions = resultOfEmployees.stateOptions;
        divisionOptions = resultOfEmployees.divisionOptions;

        this.helperService.dispatchToRedux(STORE_EMPLOYEES_DATA, datas);
        if (type && type === this.configService.get('typeLoad')) {
          this.helperService.dispatchToRedux(STORE_FILTER_STATE, stateOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_DIVISION, divisionOptions);
          this.helperService.dispatchToRedux(STORE_FILTER_POSITION, positionOptions);
        }
      } else {
        throw Error('error');
      }
      this.helperService.hideLoading();
    } catch (e) {
      this.helperService.hideLoading();
      this.helperService.handleError(e);
    }
  }

}
