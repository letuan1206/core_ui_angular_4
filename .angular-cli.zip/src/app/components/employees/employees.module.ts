import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule } from './../../app.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTableModule } from 'primeng/datatable';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { CheckboxModule } from 'primeng/checkbox';
import { FileUploadModule } from 'ng2-file-upload';
import { CalendarModule } from 'primeng/calendar';
import { DateTimePickerModule } from 'ng-pick-datetime';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { FilterModule } from '../filter/filter.module';
import { ContactsModule } from '../subs/contacts/contacts.module';
import { EmailsModule } from '../subs/emails/emails.module';
import { NotesModule } from '../subs/notes/notes.module';
import { TimelineModule } from '../subs/timeline/timeline.module';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { Ng4GeoautocompleteModule } from 'ng4-gmap-autocomplete';
import { ModalModule } from 'ng2-bootstrap';
import { AttachmentsModule } from './../subs/attachments/attachments.module';

// Components
import { EmployeesComponent } from './employees.component';

// Services
import { EmployeesService } from './employees.service';

// Modals
import { AddOrEditTimelineModule } from '../subs/modals/add-or-edit-timeline/add-or-edit-timeline.module';
import { AddNoteModalComponent } from '../subs/modals/add-note-modal/add-note-modal.component';
import { AddNoteModalModule } from '../subs/modals/add-note-modal/add-note-modal.module';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';

@NgModule({
    imports: [
        AppRoutingModule,
        CommonModule,
        DataTableModule,
        MultiSelectModule,
        DateTimePickerModule,
        MultiselectDropdownModule,
        FormsModule,
        ReactiveFormsModule,
        DropdownModule,
        CheckboxModule,
        FilterModule,
        ContactsModule,
        FileUploadModule,
        CalendarModule,
        EmailsModule,
        NotesModule,
        TimelineModule,
        AutoCompleteModule,
        AddOrEditTimelineModule,
        AddNoteModalModule,
        AttachmentsModule,
        Ng4GeoautocompleteModule.forRoot(),
        ModalModule.forRoot()
    ],
    declarations: [
        EmployeesComponent,
        EmployeeDetailComponent
    ],
    providers: [
        EmployeesService
    ]
})
export class EmployeesModule { }
