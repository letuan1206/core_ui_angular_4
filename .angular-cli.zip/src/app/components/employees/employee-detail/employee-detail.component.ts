import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, ActivationEnd } from '@angular/router';
import { FormGroup, FormControl, Validators, AbstractControl, ValidationErrors, Form } from '@angular/forms';
import { FileUploader } from 'ng2-file-upload';
import { Observable } from 'rxjs/Observable'
import * as _ from 'lodash';

// Interface
import { ObjectAddress, ObjectGoogleAddress, ObjectInformation } from '../../../interfaces/clients-interface';
import { ObjectEmployee, ObjectUser } from '../../../interfaces/employees-interface';
declare var $: any;

// Service
import { EmployeesService } from '../employees.service';
import { HelperService } from './../../../services/helper.service';
import { ApiService } from './../../../services/api.service';
import { ConfigService } from './../../../services/config.service';
import { TimelineComponent } from '../../subs/timeline/timeline.component';
import { AddNoteModalComponent } from '../../subs/modals/add-note-modal/add-note-modal.component';
import { AddOrEditTimelineComponent } from '../../subs/modals/add-or-edit-timeline/add-or-edit-timeline.component';


interface EmployeeDetailOverview {
  firstName: string | null;
  lastName: string | null;
  position: string | null;
  phone: string | null;
  phone2: string | null;
  email: string | null;
  email2: string | null;
  address: string | null;
  postalAddress: string | null;
  rating: string | null;
  dateOfBirth: string | null;
  gender: string | null;
  nationality: string | null;
  state: string | null;
  division: string | null;
  industry: string | null;
  startDate: string | null;
  terDate: string | null;
  reason: string | null;
}

enum Action {
  Edit = 1,
  Add
}

enum AddressAction {
  Add = 1,
  Update,
  Delete
}

enum SectionData {
  Rating,
  State,
  Division,
  Industry,
  Position,
  Gender
}

@Component({
  selector: 'app-employee-detail',
  templateUrl: './employee-detail.component.html',
  styleUrls: ['./employee-detail.component.scss']
})
export class EmployeeDetailComponent implements OnInit {
  @ViewChild('addOrEditTimelineModal') addOrEditTimelineModal: AddOrEditTimelineComponent;
  @ViewChild('addNotesModal') public addNotesModal: AddNoteModalComponent;
  @ViewChild('timelineTable') public timelineTable: TimelineComponent;
  // Variable for action (edit/add) site
  private action: Action = null;
  private employeeId: string = null;

  // Variable for FormGroup
  private employeeDetailForm: FormGroup = null;
  private formDisabled: boolean = null;

  // Variable for autocomplete
  private listRatingOption: any[];
  private listPositionOption: any[];
  private listStateOption: any[];
  private listIndustryOption: any[];
  private listDivisionOption: any[];
  private listGenderOption: any[];

  // Auto complete
  private addressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };
  private postalAddressGeolocationSetting = {
    showCurrentLocation: false,
    showSearchButton: false,
    inputString: ''
  };

  // Logo
  private uploader: FileUploader;
  private logoImg: any;
  private logoToken: any;
  private oldLogo: string;

  // Object data from API
  private objectEmployee: ObjectEmployee;
  private objectUser: ObjectUser;
  private listRefEmployee: any[];

  private address: string;
  private postalAddress: string;

  // Variable for summary error
  private enableErrorSummary: boolean;
  private msgErrorSummary: string;

  constructor(
    private employeeService: EmployeesService,
    private route: ActivatedRoute,
    private router: Router,
    private helperService: HelperService,
    private apiService: ApiService,
    private configService: ConfigService
  ) { }

  async ngOnInit() {
    // this.helperService.showLoading();

    this.formDisabled = true;

    this.setDataForm(null);
    this.hideSummaryError();

    // Init file upload
    this.uploader = new FileUploader({ url: this.configService.get('uploadUrl') });
    this.uploader.onAfterAddingFile = (file) => { file.withCredentials = true; };

    // Set action (edit/add)
    await this.setAction();

    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      actionObs = this.initAddAction();
    }
    this.helperService.showLoading();

    this.initDataRef()
      .flatMap(() => actionObs)
      .subscribe(res => {
        this.helperService.hideLoading();
        window.scroll(0, 0);
      }, err => {
        this.helperService.hideLoading();
      })

    window.scrollTo(0, 0);
    function onScroll(event) {
      var scrollPos = $(document).scrollTop();

      $('.ancho-employee ul li').each(function () {
        if ($('#employee-information').length) {
          var currLink = $(this).find('a');
          var refElement = $(currLink.attr('href-anchor'));
          if (refElement.position() && (refElement.position().top - 100) <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
            $('.ancho-employee ul li a').removeClass('active-menu');
            currLink.addClass('active-menu');
          } else {
            currLink.removeClass('active-menu');
          }
        }
      });
    }

    if ($('#employee-information').length) {
      $(document).on('scroll', onScroll);
    }

    $('.ancho-employee ul li a').on('click', function (e) {
      var href_link = $(this).attr('href-anchor');
      var pos1 = $(href_link).offset().top;
      $('.ancho-employee ul li a').removeClass('active-menu');
      $(this).addClass('active-menu');

      $('html, body').stop().animate({
        'scrollTop': pos1 - 101
      });
      return false;
    });
  }

  private resetIfNotANumber(controlName: string, val: string) {
    if (val == null) {
      return;
    }

    let isValid = /^[0-9]*$/.test(val);
    if (!isValid) {
      this.employeeDetailForm.get(controlName).setValue(val.slice(0, val.length - 1))
    }
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
  // Get Employee data
  private getEmployeeDetail() {
    let obsObj = new Observable(obs => {
      this.route.params.first()
        .subscribe(params => {
          this.employeeService.getEmployeeDetail(params.id)
            .then(res => {
              obs.next(res);
              obs.complete();
            }, err => {
              obs.error(err);
            })
        }, err => {
          obs.error('Get site id fail!')
        })
    })

    return obsObj;
  }

  // // Set action of this request
  private async setAction() {
    let params = await this.route.params.first().toPromise();
    this.action = params.id && params.id !== 'add' ? Action.Edit : Action.Add;
    this.employeeId = params.id && params.id !== 'add' ? params.id : null;
  }

  private initAddAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.enableEditForm();

      obs.next();
      obs.complete();
    })

    return obsObj;
  }

  private initEditAction(): Observable<any> {
    let obsObj = new Observable(obs => {
      this.formDisabled = true;
      this.employeeDetailForm.disable();
      this.getEmployeeDetail().toPromise()
        .then((res: any) => {
          console.log(res);
          // Assign Object Employee
          this.listRefEmployee = res.references;

          this.objectEmployee = _.get(this.listRefEmployee, res.results[0]);
          this.objectUser = this.objectEmployee && this.objectEmployee.User ? _.get(this.listRefEmployee, this.objectEmployee.User) : null;

          this.address = this.objectEmployee && this.objectEmployee.Address ? this.objectEmployee.Address : '';
          this.postalAddress = this.objectEmployee && this.objectEmployee.PostalAddress ? this.objectEmployee.PostalAddress : '';

          this.addressGeolocationSetting = Object.assign({}, this.addressGeolocationSetting, { inputString: this.objectEmployee ? this.objectEmployee.Address : '' });
          this.postalAddressGeolocationSetting = Object.assign({}, this.postalAddressGeolocationSetting, { inputString: this.objectEmployee ? this.objectEmployee.PostalAddress : '' });

          this.logoImg = this.objectEmployee && this.objectEmployee.EmployeePicture ? `${this.configService.get('webRoot')}/${this.objectEmployee.EmployeePicture.URI}` : null;
          this.oldLogo = this.logoImg;

          let objState = this.objectEmployee && this.objectEmployee.State ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.State) : null;
          let objRating = this.objectEmployee && this.objectEmployee.Rating ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Rating) : null;
          let objIndustry = this.objectEmployee && this.objectEmployee.Industry ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Industry) : null;
          let objDivision = this.objectEmployee && this.objectEmployee.Division ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Division) : null;
          let objPosition = this.objectEmployee && this.objectEmployee.Position ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Position) : null;
          let objGender = this.objectEmployee && this.objectEmployee.Gender ? this.objectEmployee.Gender : null;

          let dataForm = {
            position: objPosition,
            firstName: this.objectUser && this.objectUser.FirstName ? this.objectUser.FirstName : null,
            lastName: this.objectUser && this.objectUser.LastName ? this.objectUser.LastName : null,
            phone: this.objectEmployee && this.objectEmployee.Phone ? this.objectEmployee.Phone : null,
            phone2: this.objectEmployee && this.objectEmployee.Mobile ? this.objectEmployee.Mobile : null,
            email: this.objectUser && this.objectUser.UserName ? this.objectUser.UserName : null,
            email2: this.objectEmployee && this.objectEmployee.EmailOther ? this.objectEmployee.EmailOther : null,
            address: null,
            postalAddress: null,
            rating: objRating,
            gender: objGender,
            nationality: this.objectEmployee && this.objectEmployee.Nationality ? this.objectEmployee.Nationality : null,
            dateOfBirth: this.objectEmployee && this.objectEmployee.DOB ? this.objectEmployee.DOB : null,
            state: objState,
            division: objDivision,
            industry: objIndustry,
            startDate: this.objectEmployee && this.objectEmployee.StartDate ? this.objectEmployee.StartDate : null,
            terDate: this.objectEmployee && this.objectEmployee.TerminationDate ? this.objectEmployee.TerminationDate : null,
            reason: this.objectEmployee && this.objectEmployee.Reason ? this.objectEmployee.Reason : null
          }
          this.setDataForm(dataForm);

          // Complete init
          obs.next(null)
          obs.complete();
        }, err => {
          console.log(err);
          obs.error(err);
        })
    })

    return obsObj;
  }

  private enableEditForm() {
    this.formDisabled = false;
    this.employeeDetailForm.enable();
  }

  private disableEditForm() {
    this.formDisabled = true;
    this.employeeDetailForm.disable();
  }

  private showSummaryError(msg: string) {
    this.enableErrorSummary = true;
    this.msgErrorSummary = msg;
  }

  private hideSummaryError() {
    this.enableErrorSummary = false;
    this.msgErrorSummary = '';
  }

  private initDataRef() {
    let obsObj = new Observable(obs => {
      Promise.all([
        this.getDataSection(SectionData.Rating).toPromise(),
        this.getDataSection(SectionData.State).toPromise(),
        this.getDataSection(SectionData.Division).toPromise(),
        this.getDataSection(SectionData.Industry).toPromise(),
        this.getDataSection(SectionData.Position).toPromise(),
        this.getDataSection(SectionData.Gender).toPromise(),
      ]).then(res => {
        // Assign autoComplete
        let [dataRating, dataState, dataDivision, dataIndustry, dataPosition, dataGender] = res;

        this.listRatingOption = _.filter(dataRating.references, x => dataRating.results.indexOf(x.ObjectID) !== -1);
        this.listStateOption = _.filter(dataState.references, x => dataState.results.indexOf(x.ObjectID) !== -1);
        this.listIndustryOption = _.filter(dataIndustry.references, x => dataIndustry.results.indexOf(x.ObjectID) !== -1);
        this.listDivisionOption = _.filter(dataDivision.references, x => dataDivision.results.indexOf(x.ObjectID) !== -1);
        this.listPositionOption = _.filter(dataPosition.references, x => dataPosition.results.indexOf(x.ObjectID) !== -1);
        this.listGenderOption = dataGender.results;

        obs.next();
        // obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private getDataSection(section: SectionData): Observable<any> {
    let obsObj = new Observable(obs => {
      let o = null;
      switch (section) {
        case SectionData.Rating: {
          o = this.employeeService.getAllRating();
          break;
        }
        case SectionData.State: {
          o = this.employeeService.getAllStates();
          break;
        }
        case SectionData.Division: {
          o = this.employeeService.getAllDivision();
          break;
        }
        case SectionData.Industry: {
          o = this.employeeService.getAllIndustry();
          break;
        }
        case SectionData.Position: {
          o = this.employeeService.getAllPosition();
          break;
        }
        case SectionData.Gender: {
          o = this.employeeService.getAllGender();
          break;
        }
      }

      o.then(res => {
        obs.next(res);
        obs.complete();
      }, err => {
        obs.error(err);
      })
    })

    return obsObj;
  }

  private setDataForm(data: EmployeeDetailOverview) {
    if (!data) {
      // reset data
      data = {
        position: null,
        firstName: null,
        lastName: null,
        phone: null,
        phone2: null,
        email: null,
        email2: null,
        address: null,
        postalAddress: null,
        rating: null,
        gender: null,
        nationality: null,
        dateOfBirth: null,
        state: null,
        division: null,
        industry: null,
        startDate: null,
        terDate: null,
        reason: null
      }
    }

    if (this.employeeDetailForm) {
      this.employeeDetailForm.setValue(data);
    } else {
      this.employeeDetailForm = new FormGroup({
        position: new FormControl(data.position),
        firstName: new FormControl(data.firstName, Validators.required),
        lastName: new FormControl(data.lastName, Validators.required),
        phone: new FormControl(data.phone),
        phone2: new FormControl(data.phone2),
        email: new FormControl(data.email, [this.helperService.customEmailValidator, Validators.required]),
        email2: new FormControl(data.email2, this.helperService.customEmailValidator),
        address: new FormControl(data.address),
        postalAddress: new FormControl(data.postalAddress),
        rating: new FormControl(data.rating),
        gender: new FormControl(data.gender),
        nationality: new FormControl(data.nationality),
        dateOfBirth: new FormControl(data.dateOfBirth),
        state: new FormControl(data.state),
        division: new FormControl(data.division),
        industry: new FormControl(data.industry),
        startDate: new FormControl(data.startDate),
        terDate: new FormControl(data.terDate),
        reason: new FormControl(data.reason),
      })

      this.employeeDetailForm.get('phone').valueChanges.subscribe((val: string) => this.resetIfNotANumber('phone', val));
      this.employeeDetailForm.get('phone2').valueChanges.subscribe((val: string) => this.resetIfNotANumber('phone2', val));
    }
  }

  private resetDataForm() {
    if (this.action == Action.Edit) {
      let objState = this.objectEmployee && this.objectEmployee.State ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.State) : null;
      let objRating = this.objectEmployee && this.objectEmployee.Rating ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Rating) : null;
      let objIndustry = this.objectEmployee && this.objectEmployee.Industry ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Industry) : null;
      let objDivision = this.objectEmployee && this.objectEmployee.Division ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Division) : null;
      let objPosition = this.objectEmployee && this.objectEmployee.Position ? _.get<any, string>(this.listRefEmployee, this.objectEmployee.Position) : null;
      let objGender = this.objectEmployee && this.objectEmployee.Gender ? this.objectEmployee.Gender : null;

      this.logoImg = this.objectEmployee && this.objectEmployee.EmployeePicture ? `${this.configService.get('webRoot')}/${this.objectEmployee.EmployeePicture.URI}` : null;
      this.oldLogo = this.logoImg;

      let dataForm = {
        position: objPosition,
        firstName: this.objectUser && this.objectUser.FirstName ? this.objectUser.FirstName : null,
        lastName: this.objectUser && this.objectUser.LastName ? this.objectUser.LastName : null,
        phone: this.objectEmployee && this.objectEmployee.Phone ? this.objectEmployee.Phone : null,
        phone2: this.objectEmployee && this.objectEmployee.Mobile ? this.objectEmployee.Mobile : null,
        email: this.objectEmployee && this.objectEmployee.GmailAddress ? this.objectEmployee.GmailAddress : null,
        email2: this.objectEmployee && this.objectEmployee.GmailAddress ? this.objectEmployee.GmailAddress : null,
        address: this.objectEmployee && this.objectEmployee.Address ? this.objectEmployee.Address : '',
        postalAddress: this.objectEmployee && this.objectEmployee.PostalAddress ? this.objectEmployee.PostalAddress : '',
        rating: objRating,
        gender: objGender,
        nationality: this.objectEmployee && this.objectEmployee.Nationality ? this.objectEmployee.Nationality : null,
        dateOfBirth: this.objectEmployee && this.objectEmployee.DOB ? this.objectEmployee.DOB : null,
        state: objState,
        division: objDivision,
        industry: objIndustry,
        startDate: this.objectEmployee && this.objectEmployee.StartDate ? this.objectEmployee.StartDate : null,
        terDate: this.objectEmployee && this.objectEmployee.TerminationDate ? this.objectEmployee.TerminationDate : null,
        reason: this.objectEmployee && this.objectEmployee.Reason ? this.objectEmployee.Reason : null
      }
      this.setDataForm(dataForm);

    } else if (this.action == Action.Add) {
      this.setDataForm(null);
    }

    this.disableEditForm();
  }

  private autoCompleteAddressCallback(selectedData: any, type) {
    // Init Object GoogleAddress and Address

    /**
    /* Update object
    */
    if (type === 'Address') {
      /**
      /* Update for input Address
      */

      if (selectedData.response) {
        this.address = selectedData.data.description;
      }

    } else if (type === 'PostalAddress') {
      /**
      /* Update for input PostalAddress
      */

      if (selectedData.response) {
        this.postalAddress = selectedData.data.description;
      }
    }

  }

  private addEmployee() {
    if (!this.employeeDetailForm.valid) {
      this.employeeDetailForm.get('firstName').markAsTouched();
      this.employeeDetailForm.get('lastName').markAsTouched();
      this.employeeDetailForm.get('phone').markAsTouched();
      this.employeeDetailForm.get('phone2').markAsTouched();
      this.employeeDetailForm.get('email').markAsTouched();
      this.employeeDetailForm.get('email2').markAsTouched();

      this.employeeDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    let createObjectUser = (...res) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.employeeDetailForm.value;

        let objInfo: ObjectUser = {
          ResetPassword: null,
          NewPassword: this.generateRandomString(),
          ObjectClass: 'oneit.security.SecUser',
          UserName: valueOfForm.email,
          Email: null,
          ObjectID: null,
          FirstName: valueOfForm.firstName,
          SupportUser: null,
          PrivsOverrides: null,
          Enabled: true,
          RolesOverrides: null,
          SupportKey: null,
          ObjectCreated: null,
          ObjectLastModified: null,
          PasswordExpiryDate: null,
          UserDescription: null,
          GroupsOverrides: null,
          LastName: valueOfForm.lastName
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next(res.created[0])
            } else {
              obs.error('Create object User fail');
            }
          }, err => {
            obs.error(err);
          }
          )
      })

      return objObs;
    }

    let createObjectEmployee = (idUser) => {
      let objObs = new Observable(obs => {
        let valueOfForm = this.employeeDetailForm.value;

        let objInfo: ObjectEmployee = {
          User: idUser ? idUser : null,
          Address: this.address ? this.address : null,
          GoogleRefreshToken: null,
          ObjectID: null,
          EmployeePicture: logoCreated,
          GoogleAccessToken: null,
          Rating: valueOfForm.rating ? valueOfForm.rating.ObjectID : null,
          ObjectLastModified: null,
          Gender: valueOfForm.gender,
          Reason: valueOfForm.terDate && valueOfForm.reason ? valueOfForm.reason : null,
          GmailAddress: null,
          StartDate: null,
          Industry: valueOfForm.industry ? valueOfForm.industry.ObjectID : null,
          DOB: valueOfForm.dateOfBirth,
          Phone: valueOfForm.phone ? valueOfForm.phone : null,
          Division: valueOfForm.division ? valueOfForm.division.ObjectID : null,
          GoogleExpiresInSeconds: null,
          ObjectClass: 'prosek.orm.ProsekEmployeeSecUserExtenson',
          UserName: valueOfForm.email ? valueOfForm.email : null,
          GoogleAuthCode: null,
          Position: valueOfForm.position ? valueOfForm.position.ObjectID : null,
          TerminationDate: valueOfForm.terDate,
          ObjectCreated: null,
          GoogleTokenRequestedDate: null,
          Mobile: valueOfForm.phone2 ? valueOfForm.phone2 : null,
          Nationality: valueOfForm.nationality ? valueOfForm.nationality : null,
          PostalAddress: this.postalAddress ? this.postalAddress : null,
          State: valueOfForm.state ? valueOfForm.state.ObjectID : null,
          EmailOther: valueOfForm.email2 ? valueOfForm.email2 : null
        }

        this.accessObject([objInfo], [], [])
          .subscribe(res => {
            if (res.created && res.created.length > 0) {
              obs.next(res.created[0])
            } else {
              obs.error('Create object User fail');
            }
          }, err => {
            obs.error(err);
          })
      })

      return objObs;
    }

    let logoCreated = null;

    this.helperService.showLoading();
    Observable.forkJoin([
      this.uploadLogo()
    ])
      .flatMap((resp: any) => {
        if (resp.length > 0 && resp[0]) {
          logoCreated = { FileToken: resp[0].token }
        }
        return createObjectUser();
      })
      .flatMap((idUser) => createObjectEmployee(idUser))
      .subscribe(res => {
        this.uploader.clearQueue();
        this.helperService.hideLoading();
        this.hideSummaryError();

        this.router.navigate(['/employees/detail/', res])
      }, err => {
        this.helperService.hideLoading();
      });
  }

  private updateEmployee() {
    if (!this.employeeDetailForm.valid) {
      this.employeeDetailForm.get('firstName').markAsTouched();
      this.employeeDetailForm.get('lastName').markAsTouched();
      this.employeeDetailForm.get('phone').markAsTouched();
      this.employeeDetailForm.get('phone2').markAsTouched();
      this.employeeDetailForm.get('email').markAsTouched();
      this.employeeDetailForm.get('email2').markAsTouched();

      this.employeeDetailForm.markAsTouched();
      this.showSummaryError('Errors occurred, please correct them before continuing !');
      return;
    }

    this.helperService.showLoading();
    Observable.forkJoin([
      // this.updateAddress(this.objectEmployeeAddress, this.objectEmployeeGoogleAddress, this.objectEmployeeNewAddress, this.objectEmployeeNewGoogleAddress),
      // this.updateAddress(this.objectEmployeePostalAddress, this.objectEmployeeGooglePostalAddress, this.objectEmployeeNewPostalAddress, this.objectEmployeeNewGooglePostalAddress),
      this.uploadLogo()
    ])
      .flatMap(resp => this.updateObjectEmployee(resp))
      .flatMap(() => this.reloadData())
      .subscribe(res => {
        this.uploader.clearQueue();
        this.helperService.hideLoading();
        this.hideSummaryError();

      }, err => {
        this.helperService.hideLoading();
      });
  }

  private reloadData(): Observable<any> {
    let actionObs = null;
    if (this.action == Action.Edit) {
      actionObs = this.initEditAction();
    } else if (this.action == Action.Add) {
      actionObs = this.initAddAction();
    }

    return actionObs;
  }

  private updateObjectEmployee(resp): Observable<any> {
    let valueOfForm = this.employeeDetailForm.value;

    if (!this.logoImg) {
      this.objectEmployee.EmployeePicture = null;
    } else {
      if (resp.length > 0 && resp[0]) {
        this.objectEmployee.EmployeePicture = { FileToken: resp[0].token }
      }
    }

    this.objectUser.FirstName = valueOfForm.firstName;
    this.objectUser.LastName = valueOfForm.lastName;
    this.objectUser.UserName = valueOfForm.email;

    this.objectEmployee.Position = valueOfForm.position ? valueOfForm.position.ObjectID : null;
    this.objectEmployee.Phone = valueOfForm.phone;
    this.objectEmployee.Mobile = valueOfForm.phone2;
    this.objectEmployee.EmailOther = valueOfForm.email2;
    this.objectEmployee.Address = this.address ? this.address : null;
    this.objectEmployee.PostalAddress = this.postalAddress ? this.postalAddress : null;
    this.objectEmployee.Rating = valueOfForm.rating ? valueOfForm.rating.ObjectID : null;
    this.objectEmployee.DOB = valueOfForm.dateOfBirth;
    this.objectEmployee.Gender = valueOfForm.gender;
    this.objectEmployee.Nationality = valueOfForm.nationality;
    this.objectEmployee.State = valueOfForm.state ? valueOfForm.state.ObjectID : null;
    this.objectEmployee.Division = valueOfForm.division ? valueOfForm.division.ObjectID : null;
    this.objectEmployee.Industry = valueOfForm.industry ? valueOfForm.industry.ObjectID : null;
    this.objectEmployee.StartDate = valueOfForm.startDate;
    this.objectEmployee.TerminationDate = valueOfForm.terDate;
    this.objectEmployee.Reason = valueOfForm.terDate && valueOfForm.reason ? valueOfForm.reason : null;

    return this.accessObject([], [this.objectUser, this.objectEmployee], []);
  }

  private accessObject(paramCreate: any[], paramUpdate: any[], paramDelete: any[] = []): Observable<any> {
    let params = {
      create: {},
      update: {},
      delete: {}
    }

    for (var i = 0; i < paramCreate.length; ++i) {
      params.create[`NEW:${i}`] = paramCreate[i];
    }

    for (var i = 0; i < paramUpdate.length; ++i) {
      params.update[paramUpdate[i].ObjectID] = paramUpdate[i];
    }

    for (var i = 0; i < paramDelete.length; ++i) {
      params.delete[paramDelete[i].ObjectID] = paramDelete[i];
    }

    let returnObject = {
      created: [],
      updated: [],
      deleted: []
    }

    let obsObj = new Observable(obs => {
      this.apiService.saveService(params)
        .subscribe(res => {
          if (res.result) {
            // Push created object
            Object.keys(res.created).map(function (key, index) {
              returnObject.created.push(res.created[key]);
            });

            // Push updated object
            returnObject.updated = res.updated;

            // Push deleted object
            returnObject.deleted = res.deleted;

            obs.next(returnObject);
            obs.complete();
          } else {
            obs.error("Create object Address fail")
          }
        }, err => {
          obs.error(err);
        })

    })

    return obsObj;
  }

  private loadLogo(event: any): any {
    var reader = new FileReader();
    reader.onload = () => {
      var dataURL = reader.result;
      this.logoImg = dataURL;
    };
    reader.readAsDataURL(event[0]);
  }

  private uploadLogo() {
    let objObs = new Observable(obs => {
      if (this.uploader.queue.length == 0) {
        obs.next(null);
        obs.complete();
      } else {
        this.uploader.queue.forEach(item => {
          item.upload();
        });
      }

      this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        if (response) {
          let resp = JSON.parse(response);
          if (resp.files && resp.files.length > 0) {
            obs.next(resp.files[0]);
            obs.complete();
          } else {
            obs.error('Upload photo fail');
          }
        } else {
          obs.error('Upload photo fail');
        }
      };

    })

    return objObs;
  }

  private clearLogoSelected() {
    this.uploader.clearQueue();
    this.logoImg = this.oldLogo;
  }

  private removeLogo() {
    this.logoImg = null;
    this.oldLogo = null;
  }

  showAddOrEditTimelineModal(type) {
    this.addOrEditTimelineModal.initParams(null, type, null, null, null, this.employeeId);
    this.addOrEditTimelineModal.show();
  }

  showAddNotesModal() {
    this.addNotesModal.initParams(null, null, null, null, this.employeeId);
    this.addNotesModal.show();
  }

  saveTimelineSuccessed(event) {
    this.timelineTable.saveTimelineSuccessed(event);
  }

  saveNoteSuccessed(event) {
    this.timelineTable.saveNoteSuccessed(event);
  }

  generateRandomString() {
    let text = "";
    let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 10; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    return text;
  }

}
