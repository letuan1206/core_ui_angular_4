import { Component, OnInit } from '@angular/core';
import { EmployeesParam } from '../../interfaces/employees-interface';
import { StateOptions, DivisionOptions } from '../../interfaces/common-interface';

// Service
import { EmployeesService } from './employees.service';
import { ConfigService } from '../../services/config.service';
import { HelperService } from '../../services/helper.service';
import { Router } from '@angular/router';
import { NgRedux, select } from 'ng2-redux';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})
export class EmployeesComponent implements OnInit {

  typeFilter: string;

  employeesArr: any = [];

  queryEmployeesParams: EmployeesParam = {
    Position: null,
    Division: null,
    State: null
  }

  stateOptions: StateOptions[] = [
    {
      Active: null,
      Country: null,
      Name: 'Choose State',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null
    }
  ];

  divisionOptions: DivisionOptions[] = [
    {
      Active: null,
      Description: 'Choose Division',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      State: null
    }
  ];

  positionOptions: any = [
    {
      Description: 'Choose Position',
      ObjectClass: null,
      ObjectCreated: null,
      ObjectID: null,
      ObjectLastModified: null,
      State: null
    }
  ];

  @select(s => s.common.employeesData) employeesData;

  constructor(
    private employeesService: EmployeesService,
    private configService: ConfigService,
    private helperService: HelperService,
    private router: Router,
    private ngRedux: NgRedux<any>
  ) {
    this.employeesData.subscribe(data => {
      this.employeesArr = data;
    });
  }

  ngOnInit() {
    this.typeFilter = this.configService.get('menuType')['employees'];
    this.employeesService.loadDataEmployees(this.configService.get('typeLoad'), this.queryEmployeesParams, this.positionOptions, this.stateOptions, this.divisionOptions);
  }

  handleRowClick(event) {
    this.router.navigate(['/employees/detail', event.data.objectID]);
  }

  ngOnDestroy() {
    this.employeesService.getAllEmployeesSub.unsubscribe();
  }

  ngAfterViewInit() {
    this.helperService.setThemeDefault();
  }
}
