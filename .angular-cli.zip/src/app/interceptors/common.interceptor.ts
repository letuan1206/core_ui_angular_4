import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { ResponseContentType } from '@angular/http';

@Injectable()
export class CommonInterceptor implements HttpInterceptor {

  constructor () {
    
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let headers = new HttpHeaders().set('Content-Type', 'application/json');
    headers.set('Accept', 'application/pdf');
    return next.handle(req.clone({
        headers: headers,
        withCredentials: true
    }));
  }

}